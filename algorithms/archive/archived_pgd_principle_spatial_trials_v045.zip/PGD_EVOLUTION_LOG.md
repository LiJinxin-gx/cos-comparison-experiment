# PGD Framework Evolution Log (v4 - v8.3)

## Overview
Perception-Generation-Decision framework exploration for rotation/shift invariance,
hierarchical templates, cross-modal mapping, and feedback-driven contrast points.
All experiments in `C:\AI项目\explore\algorithms\`, formal project code untouched.

---

## v4: Rotation Invariance + Hierarchical Templates + Cross-Modal Mapping

### Features
- Symmetric kernel (circular local variance) for rotation-invariant features
- Multi-angle template matching (8 angles: 0-315°)
- HierarchicalTemplateLibrary: L0(3×3) / L1(4×4) / L2(full), threshold 0.80 auto-merge
- CrossModalMapper: correlation-weighted mapping from paired data

### Results
| Task | Result |
|------|--------|
| Rotation invariance (9 angles) | 35.2% → 92.6% (+57.4pp) |
| Symmetric kernel alone | 0% (too coarse, must combine with spatial) |
| Template compression | 3.25x (12 unique for 39 refs) |
| Cross-modal accuracy | 16.7% (= random) |
| Full chain (rotated) | FAIL |

### Key Findings
- Multi-angle matching is primary driver; symmetric kernel is auxiliary only
- Cross-modal explicit mapping to low dimension loses all discriminative info
- Template library index mapping was broken (no labels stored)

---

## v5: Cross-Modal Fix Attempt

### Features
- Cross-modal: 120 training pairs, k-NN=3, contrast_hist + spatial_dist features
- Labeled template library
- Full chain with template library matching

### Results
| Task | Result |
|------|--------|
| Rotation (12 angles) | 86.1% (more angles = harder) |
| Cross-modal mapped k-NN | 16.7% (still random) |
| Cross-modal direct k-NN (diagnostic) | 95.8% |
| Template library match | PASS (single test) |
| Full chain | FAIL |

### Key Findings
- **Critical diagnostic**: direct k-NN in source feature space = 95.8%,
  explicit mapping → k-NN = 16.7%. Mapping destroys information.
- Correct architecture: classification via direct k-NN, mapping only for translation
- spatial_dist (4×4 grid) = 90% discriminative; contrast_hist = 30% (too lossy)

---

## v6: Final Cross-Modal + Template + Full Chain

### Features
- Cross-modal: spatial_dist only (90% discriminative), 300 pairs, k=5
- LabeledTemplateLibrary with stored labels
- Full chain: direct rotation-invariant matching + structure-guided generation

### Results
| Task | Result |
|------|--------|
| Rotation (12 angles) | 97.2% |
| Cross-modal mapped | 16.7% |
| Cross-modal direct k-NN | 95.8% |
| Template library (39 templates) | PASS |
| Full chain (rot 45+shift) | FAIL (predicted 2 instead of 3) |
| Generation similarity | 0.68 |

### Key Findings
- Rotation solved: 97.2% on 12 angles including non-90 multiples
- Full chain fails because direct matching (6 templates) can't handle shift
- Generation 0.68 because wrong template selected (classification error downstream)

---

## Deep Retrospective: Bottleneck Analysis

### Error Attribution Experiments
| Condition | Accuracy |
|-----------|----------|
| clean | 100% |
| noise=0.2 | 100% |
| rot=45/90/180 | 100% |
| rot+noise | 100% |
| **rot+noise+shift(±1)** | **50%** |
| rot random+noise+shift | 43.3% |

**Core finding**: Shift is the ONLY bottleneck. Rotation and noise are fully solved.
8×8 image, ±1px = 12.5% displacement, completely unhandled.

### Generation Decomposition
| Method | rot=0 | rot=45 | rot=90 | rot=180 |
|--------|-------|--------|--------|---------|
| raw (no alignment) | 0.99 | 0.21-0.51 | 0.10-0.52 | 0.13-0.77 |
| **aligned (rotated)** | **0.99** | **0.98-0.99** | **0.99** | **0.99** |

**Generation is NOT the bottleneck**: once rotation angle is correctly estimated and
template aligned, generation reaches 0.984-0.995. Previous low scores were due to
classification errors, not generation method.

---

## v7: Feedback Contrast Points + Pattern Shift (FAILED)

### Features
- FeedbackContrastExtractor: percentile-based candidates + feedback refinement
- point_pattern_similarity: shift-invariant point set overlap matching
- Train/validate separation

### Results
| Task | Result |
|------|--------|
| Rotation only | 33.3% (regression from 97.2%!) |
| Shift only | 33.3% |
| Hard condition | 23.3% (worse than v6 43.3%) |
| Generation | 0.800 |

### Failure Analysis
- Pattern matching implementation had buggy overlap counting
- 19 contrast points (top 30%) too many, diluted discriminative power
- Pattern similarity 0.5 weight dragged down pixel cosine score
- Feedback had no effect (contribution normalization broken)

---

## v7.1: Fix - v6 Proven + Nested Shift Search

### Features
- Revert to v6's pixel cosine matching (proven 97.2%)
- Add nested ±2px shift search inside each rotation angle
- Feedback extractor with percentile=85 (top 15%, ~9 points)
- 10 angles: 0,30,45,60,90,120,135,180,225,270

### Results
| Condition | v6 | v7.1 |
|-----------|-----|------|
| clean | 100% | 100% |
| noise=0.2 | 100% | 100% |
| rot random | 97.2% | 100% |
| shift only | N/A | 100% |
| rot=45+shift | 50% | 90% |
| rot random+shift | N/A | 83.3% |
| **hard (rot+shift+noise)** | **43.3%** | **76.7%** |
| Generation | 0.68 | 0.953 |
| Feedback improvement | N/A | +3.3pp |

### Key Findings
- **Shift search solves the bottleneck**: +33.4pp on hard condition
- Generation jumps to 0.953 because classification now correct
- Feedback gives modest +3.3pp (9 contrast points, signal somewhat concentrated)

---

## v8: Coarse-to-Fine + Tiebreaker (SLOW, NO GAIN)

### Features
- Coarse-to-fine: 10 angles → refine best with ±15° (3 angles)
- Contrast overlap tiebreaker when top1-top2 gap < 0.03
- Refined points in matching (feedback)

### Results
| Metric | v7.1 | v8 |
|--------|------|-----|
| Hard condition | 76.7% | 76.7% (no gain) |
| Feedback improvement | +3.3pp | +6.7pp |
| Generation | 0.953 | 0.958 |
| **Time** | **28s** | **465s** (16x slower!) |

### Key Findings
- Coarse-to-fine on 8×8 images provides no benefit (nearest-neighbor interpolation too coarse)
- Refined points in matching doubles feedback gain (+6.7pp vs +3.3pp)
- 16x slowdown unacceptable for zero accuracy gain

---

## v8.1: Multi-Rotation Templates (REGRESSION)

### Features
- Store 3 rotated variants (0,90,180) per digit instead of runtime rotation
- Discriminative feedback (correct - wrong contribution)
- percentile=80 (top 20%, ~12 points)

### Results
| Metric | v7.1 | v8.1 |
|--------|------|------|
| Hard condition | 76.7% | **50%** (regression!) |
| Feedback | +3.3pp | -13.3pp |
| Generation | 0.953 | 0.891 |

### Failure Analysis
- **Storing only 3 rotation angles loses 45°, 60°, 120° etc.** — runtime rotation
  over 10 angles is essential. Pre-computing rotations does NOT reduce interpolation
  error because the input can be at any angle.
- Discriminative feedback over-corrected, causing regression

---

## v8.2: Multi-Noise Templates + 25% Points

### Features
- 3 noise variants per digit (clean, noise=0.1, noise=0.2) — NOT rotation variants
- 25% contrast points (percentile=75, ~16 points)
- 10-angle runtime rotation + shift search (restored from v7.1)
- Contrast overlap tiebreaker

### Results
| Metric | v7.1 | v8.2 |
|--------|------|------|
| Hard (no feedback) | 76.7% | **86.7%** (+10pp) |
| Feedback | +3.3pp | **-6.7pp** (broken!) |
| 0 accuracy | 80% | 95% |
| 4 accuracy | 70% | 90% |
| 2 accuracy | 80% | 60% |
| 3 accuracy | 85% | 55% |
| Generation | 0.953 | 0.954 |
| Time | 28s | 265s |

### Key Findings
- **Multi-noise templates + 25% points solve 0↔4 confusion** (0: 80→95%, 4: 70→90%)
- **But 25% points dilute feedback signal**: feedback goes from +3.3pp to -6.7pp
- 2→3 and 3→5 confusion worsens (more points = more noise for these similar digits)
- 3 templates is slow (265s)

---

## v8.3: Integrated All Good Features (CURRENT BEST)

### Features Integrated
| Feature | Source | Implementation |
|---------|--------|---------------|
| 10-angle + shift search | v7.1 | 10 angles × 25 shifts |
| Refined points in matching | v8 | feedback re-ranks points |
| Multi-noise templates | v8.2 | 2 variants (clean + noise=0.1) |
| 20% contrast points | new | percentile=80, ~12 points |
| Contrast tiebreaker | v8/v8.2 | gap < 0.05 |
| Symmetric kernel 0.25 | v6/v7.1 | 0.75 pixel + 0.25 structure |

### Design Rationale for 20% Points
- v8 (15% = 9 points): feedback +6.7pp, but 0↔4 confusion remains
- v8.2 (25% = 16 points): 0↔4 solved, but feedback -6.7pp (diluted)
- v8.3 (20% = ~12 points): **sweet spot** — enough coverage for 0/4,
  concentrated enough for feedback signal

### Results
| Metric | v7.1 | v8.2 | v8.3 |
|--------|------|------|------|
| Hard (no feedback) | 76.7% | 86.7% | **86.7%** |
| Feedback improvement | +3.3pp | -6.7pp | **+6.7pp** (restored!) |
| Hard (with feedback) | 80% | 80% | **86.7%** |
| noise=0.2 | 100% | 96.7% | **100%** |
| Generation | 0.953 | 0.954 | **0.960** |
| Time | 28s | 265s | 309s |

### Confusion Matrix (with feedback, 20/digit)
| true\pred | 0 | 1 | 2 | 3 | 4 | 5 | accuracy |
|-----------|---|---|---|---|---|---|----------|
| 0 | 17 | 0 | 0 | 0 | 3 | 0 | 85% |
| 1 | 0 | 17 | 0 | 0 | 3 | 0 | 85% |
| 2 | 2 | 0 | 13 | 3 | 2 | 0 | 65% |
| 3 | 1 | 0 | 0 | 12 | 1 | 6 | **60%** |
| 4 | 2 | 3 | 0 | 0 | 15 | 0 | 75% |
| 5 | 0 | 0 | 0 | 0 | 1 | 19 | **95%** |
| **Overall** | | | | | | | **77.5%** |

### Remaining Bottlenecks
1. **3→5 confusion (6 times)**: largest single error source. 3 and 5 have similar
   right-side structure after rotation.
2. **2→3 confusion (3 times)**: 2 and 3 both have right-side curves.
3. **0/1→4 confusion (3 each)**: minor, 4's vertical line resembles 0/1 edge after rotation.

---

## Cross-Modal Mapping: Final Architecture

### What Failed
- Explicit dimensionality reduction (16D → 6D) via weighted average: 16.7% = random
- Reason: weighted average is a smoothing operation that destroys discriminative structure

### What Works
- **Direct k-NN in source feature space**: 95.8%
- Mapping embodied in correlation of paired data (not explicit transform)
- Classification: direct k-NN; Translation: correlation-weighted estimate + iterative refinement

### Principle
> "跨模态只能在数据相关训练进行映射处理（映射数据在相关中体现）"
> Mapping is embodied in the correlation structure of paired data, not in an
> explicit dimensionality-reducing projection matrix.

---

## Generation: Structure-Guided Method

### Method
1. Estimate best rotation angle + shift via matching
2. Align template to input orientation
3. Selectively overlay input contrast points (top 5, only where template < 0.3 and input > 0.3)

### Results
- Aligned template alone: 0.984-0.995 (when classification correct)
- With contrast overlay: 0.953-0.960 (slightly lower due to overlay noise, but adds detail)
- Key: generation quality is bounded by classification accuracy

---

## Summary of Proven Principles

1. **Rotation invariance**: multi-angle matching (10 angles) + symmetric kernel auxiliary
   → 97.2-100%. Coarse-to-fine provides no benefit on small images.

2. **Shift invariance**: nested ±2px search inside each rotation → +33pp.
   Pre-computing rotated templates loses angle coverage.

3. **Noise robustness**: multi-noise template storage (2 variants) → +10pp on hard condition.
   3 variants is overkill (slower, no extra gain).

4. **Contrast points**: 20% percentile (~12 points) is sweet spot.
   15% = feedback works but 0/4 confused; 25% = 0/4 solved but feedback diluted.

5. **Feedback**: refined points in matching gives +6.7pp (with 20% points).
   Requires ≥20 rounds, contribution normalized by running max.

6. **Cross-modal**: direct k-NN (95.8%), NOT explicit mapping (16.7%).
   Mapping embodied in data correlation.

7. **Generation**: structure-guided (aligned template + selective contrast overlay).
   Quality bounded by classification accuracy, not generation method.

8. **Weighting**: 0.75 pixel cosine + 0.25 symmetric kernel is proven (v6-v8.3).
   All fusions have explicit mathematical meaning (intensity + structure agreement).

---

## Files
| File | Description |
|------|-------------|
| pgd_framework_v4.py | Initial rotation + hierarchical + cross-modal |
| pgd_framework_v5.py | Cross-modal fix attempt |
| pgd_framework_v6.py | Final cross-modal + template + full chain |
| pgd_framework_v7.py | Feedback pattern shift (FAILED) |
| pgd_framework_v7_1.py | v6 + shift search (76.7% hard) |
| pgd_framework_v8.py | Coarse-to-fine (slow, no gain) |
| pgd_framework_v8_1.py | Multi-rotation templates (REGRESSION) |
| pgd_framework_v8_2.py | Multi-noise + 25% points (86.7%, feedback broken) |
| pgd_framework_v8_3.py | **Integrated best (86.7% + feedback +6.7pp)** |
| PGD_ROTATION_CROSSMODAL_REPORT.md | v4-v6 report |
| PGD_RETROSPECTIVE_BOTTLENECK.md | Bottleneck analysis |
| PGD_EVOLUTION_LOG.md | This file |
