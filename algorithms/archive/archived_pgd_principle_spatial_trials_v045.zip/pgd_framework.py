"""
Perception-Generation-Decision (PGD) Full-Chain Framework v1
Based on cos-comparison core principles:
- Perception: passive feature extraction + active template matching
- Generation: selective template combination (no voting, no residual)
- Decision: similarity-based selection with confidence threshold

Iterative: run -> retrospective analysis -> targeted generalization -> rerun
"""
import os
import time
import math
import json
import random
from collections import Counter, defaultdict

from cos_comparison.core import (
    cos, cos_comparison_passive, cos_comparison_active,
    mean_local, local_variance,
)

random.seed(42)

# ============================================================
# LAYER 1: PERCEPTION - Feature extraction
# ============================================================
class Perception:
    """Extract hierarchical features from raw data using cos-comparison primitives."""

    @staticmethod
    def extract_1d(data, n_levels=3, window=5):
        """Hierarchical feature extraction for 1D data.
        Level 0: raw data
        Level 1: local variance (edge/change points)
        Level 2: local mean (smooth structure)
        Level 3: passive comparison features
        """
        features = {'raw': data[:]}
        # Level 1: local variance - captures change points / edges
        try:
            var = local_variance(data, local_size=(window,))
            features['variance'] = var
        except Exception:
            features['variance'] = [0.0] * max(0, len(data) - window + 1)
        # Level 2: local mean - captures smooth structure
        try:
            mn = mean_local(data, local_size=(window,))
            features['mean'] = mn
        except Exception:
            features['mean'] = [0.0] * max(0, len(data) - window + 1)
        # Level 3: passive mode - captures directional patterns
        try:
            passive = cos_comparison_passive(data, local_size=(window,))
            features['passive'] = passive
        except Exception:
            features['passive'] = []
        # Contrast points: high variance regions = information-rich
        if features['variance']:
            vmax = max(features['variance']) if features['variance'] else 1
            threshold = vmax * 0.3
            features['contrast_points'] = [i for i, v in enumerate(features['variance']) if v > threshold]
        else:
            features['contrast_points'] = []
        return features

    @staticmethod
    def extract_2d(matrix, n_levels=3, window=3):
        """Hierarchical feature extraction for 2D data."""
        h, w = len(matrix), len(matrix[0])
        flat = [x for row in matrix for x in row]
        features = {'raw': matrix, 'flat': flat, 'shape': (h, w)}
        # Row-wise variance
        row_vars = []
        for row in matrix:
            try:
                rv = local_variance(row, local_size=(window,))
                row_vars.append(rv)
            except Exception:
                row_vars.append([])
        features['row_variance'] = row_vars
        # Column-wise variance
        col_vars = []
        for j in range(w):
            col = [matrix[i][j] for i in range(h)]
            try:
                cv = local_variance(col, local_size=(window,))
                col_vars.append(cv)
            except Exception:
                col_vars.append([])
        features['col_variance'] = col_vars
        # Contrast map: union of high-variance positions
        contrast = set()
        for i, rvs in enumerate(row_vars):
            if rvs:
                vmax = max(rvs)
                for j, v in enumerate(rvs):
                    if v > vmax * 0.3:
                        contrast.add((i, min(j + window // 2, w - 1)))
        for j, cvs in enumerate(col_vars):
            if cvs:
                vmax = max(cvs)
                for i, v in enumerate(cvs):
                    if v > vmax * 0.3:
                        contrast.add((min(i + window // 2, h - 1), j))
        features['contrast_points'] = sorted(contrast)
        return features

    @staticmethod
    def spatiality_score_1d(data):
        """Detect if 1D data is spatial (high adjacent correlation)."""
        n = len(data)
        if n < 4:
            return 1.0
        m = sum(data) / n
        num = sum((data[i] - m) * (data[i + 1] - m) for i in range(n - 1))
        den = sum((x - m) ** 2 for x in data)
        corr = num / den if den > 1e-10 else 0.0
        return abs(corr) * 5 + 1.0


# ============================================================
# LAYER 2: GENERATION - Selective template combination
# ============================================================
class Generation:
    """Generate new data by selective combination of perceived templates.
    Principle: choose specific features from specific templates (not voting, not weighted average).
    """

    @staticmethod
    def combine_templates_1d(templates, selection, length=None):
        """Selectively combine 1D templates.
        selection: list of (template_idx, start, end) - which segment from which template
        """
        if length is None:
            length = max(end for _, _, end in selection)
        result = [0.0] * length
        for tpl_idx, start, end in selection:
            if tpl_idx < len(templates):
                tpl = templates[tpl_idx]
                for i in range(start, min(end, length)):
                    src_i = i - start
                    if src_i < len(tpl):
                        result[i] = tpl[src_i]
        return result

    @staticmethod
    def combine_templates_2d(templates, selection, shape=None):
        """Selectively combine 2D templates.
        selection: list of (template_idx, top, left, bottom, right)
        """
        if shape is None:
            h = max(b for _, _, _, b, _ in selection)
            w = max(r for _, _, _, _, r in selection)
            shape = (h, w)
        h, w = shape
        result = [[0.0] * w for _ in range(h)]
        for tpl_idx, top, left, bottom, right in selection:
            if tpl_idx < len(templates):
                tpl = templates[tpl_idx]
                for i in range(top, min(bottom, h)):
                    for j in range(left, min(right, w)):
                        src_i, src_j = i - top, j - left
                        if src_i < len(tpl) and src_j < len(tpl[0]):
                            result[i][j] = tpl[src_i][src_j]
        return result

    @staticmethod
    def generate_from_contrast(features, templates_2d, target_shape):
        """Generate by placing template patches at contrast point locations.
        High-level structure guides low-level template placement.
        """
        h, w = target_shape
        result = [[0.0] * w for _ in range(h)]
        contrast_pts = features.get('contrast_points', [])
        if not contrast_pts or not templates_2d:
            return result
        # For each contrast point, place the best-matching template patch
        tpl = templates_2d[0]  # use first template as base structure
        th, tw = len(tpl), len(tpl[0])
        for (ci, cj) in contrast_pts:
            # Place template centered at contrast point
            top = max(0, ci - th // 2)
            left = max(0, cj - tw // 2)
            for i in range(th):
                for j in range(tw):
                    ri, rj = top + i, left + j
                    if 0 <= ri < h and 0 <= rj < w:
                        # Only fill if currently empty (selective, not overwriting)
                        if result[ri][rj] == 0.0:
                            result[ri][rj] = tpl[i][j]
        return result

    @staticmethod
    def reconstruct_from_features_1d(features, length):
        """Reconstruct 1D data from hierarchical features (generation via inverse mapping)."""
        # Start from mean structure, add variance-based detail at contrast points
        result = [0.0] * length
        mn = features.get('mean', [])
        var = features.get('variance', [])
        contrast = features.get('contrast_points', [])
        if mn:
            for i in range(min(length, len(mn))):
                result[i] = mn[i]
        # Add detail at contrast points (variance as amplitude)
        for idx in contrast:
            if idx < length and idx < len(var):
                # Reconstruct detail: mean ± variance at contrast points
                detail = var[idx] * 0.5
                result[idx] = result[idx] + detail if random.random() > 0.5 else result[idx] - detail
        return result


# ============================================================
# LAYER 3: DECISION - Similarity-based selection
# ============================================================
class Decision:
    """Make decisions based on perception features and generation candidates."""

    @staticmethod
    def classify(input_features, templates_features, threshold=0.5):
        """Classify input by comparing features to template features.
        Returns (label, confidence, all_scores).
        """
        scores = {}
        input_raw = input_features.get('raw', [])
        # Flatten if 2D
        if input_raw and isinstance(input_raw[0], list):
            input_flat = [x for row in input_raw for x in row]
        else:
            input_flat = input_raw
        for label, tpl_feat in templates_features.items():
            tpl_raw = tpl_feat.get('raw', [])
            if tpl_raw and isinstance(tpl_raw[0], list):
                tpl_flat = [x for row in tpl_raw for x in row]
            else:
                tpl_flat = tpl_raw
            if len(input_flat) == len(tpl_flat) and len(input_flat) > 0:
                try:
                    raw_score = cos(input_flat, tpl_flat)
                except Exception:
                    raw_score = 0.0
            else:
                raw_score = 0.0
            # Also compare variance features (more robust to shift)
            input_var = input_features.get('variance', [])
            tpl_var = tpl_feat.get('variance', [])
            # For 2D, variance may be row_variance
            if not input_var and 'row_variance' in input_features:
                input_var = [x for row in input_features['row_variance'] for x in row]
            if not tpl_var and 'row_variance' in tpl_feat:
                tpl_var = [x for row in tpl_feat['row_variance'] for x in row]
            if input_var and tpl_var:
                min_len = min(len(input_var), len(tpl_var))
                try:
                    var_score = cos(input_var[:min_len], tpl_var[:min_len])
                except Exception:
                    var_score = 0.0
            else:
                var_score = 0.0
            # Combined: raw (spatial) + variance (structure)
            spatiality = Perception.spatiality_score_1d(input_flat)
            alpha = min(spatiality / 3.0, 1.0)
            combined = alpha * raw_score + (1 - alpha) * var_score
            scores[label] = combined
        if not scores:
            return None, 0.0, {}
        best_label = max(scores, key=scores.get)
        best_score = scores[best_label]
        confidence = best_score if best_score > threshold else 0.0
        return best_label, confidence, scores

    @staticmethod
    def select_generation(candidates, target_features, metric='cos'):
        """Select best generated candidate by similarity to target features."""
        best = None
        best_score = -1
        all_scores = []
        target_raw = target_features.get('raw', [])
        for i, cand in enumerate(candidates):
            if isinstance(cand, list) and cand and isinstance(cand[0], list):
                # 2D
                flat_cand = [x for row in cand for x in row]
                flat_target = [x for row in target_features.get('raw', cand) for x in row]
            else:
                flat_cand = cand if isinstance(cand, list) else [cand]
                flat_target = target_raw
            if len(flat_cand) == len(flat_target) and len(flat_cand) > 0:
                try:
                    score = cos(flat_cand, flat_target)
                except Exception:
                    score = 0.0
            else:
                score = 0.0
            all_scores.append(score)
            if score > best_score:
                best_score = score
                best = i
        return best, best_score, all_scores

    @staticmethod
    def feedback_loop(decision_result, ground_truth, adaptation_rate=0.1):
        """Generate feedback signal for adaptation.
        Returns adjustment parameters for next iteration.
        """
        predicted, confidence, scores = decision_result
        correct = (predicted == ground_truth)
        feedback = {
            'correct': correct,
            'confidence': confidence,
            'predicted': predicted,
            'actual': ground_truth,
            'adjustment': {},
        }
        if not correct and scores:
            # The correct template had lower score - need to adjust feature weighting
            actual_score = scores.get(ground_truth, 0)
            pred_score = scores.get(predicted, 0)
            feedback['adjustment']['feature_bias'] = (actual_score - pred_score) * adaptation_rate
        return feedback


# ============================================================
# FULL CHAIN: Perception -> Generation -> Decision
# ============================================================
def full_chain_perceive_decide(data, templates, task_type='1d'):
    """Full chain: perceive input, compare with templates, decide label."""
    # Perception
    if task_type == '2d':
        feat = Perception.extract_2d(data)
        tpl_feats = {label: Perception.extract_2d(tpl) for label, tpl in templates.items()}
    else:
        feat = Perception.extract_1d(data)
        tpl_feats = {label: Perception.extract_1d(tpl) for label, tpl in templates.items()}
    # Decision
    label, confidence, scores = Decision.classify(feat, tpl_feats)
    return label, confidence, scores, feat


def full_chain_generate_verify(source_data, templates, target_shape, task_type='2d'):
    """Full chain: perceive source, generate candidates, decide best by verification."""
    # Perception
    source_feat = Perception.extract_2d(source_data) if task_type == '2d' else Perception.extract_1d(source_data)
    # Generation: multiple candidates
    candidates = []
    # Candidate 1: contrast-guided generation
    tpl_list = list(templates.values()) if isinstance(templates, dict) else templates
    gen1 = Generation.generate_from_contrast(source_feat, tpl_list, target_shape)
    candidates.append(gen1)
    # Candidate 2: direct template copy
    if tpl_list:
        candidates.append(tpl_list[0])
    # Candidate 3: selective combination
    if len(tpl_list) >= 2:
        h, w = target_shape
        sel = [(0, 0, 0, h // 2, w), (1, h // 2, 0, h, w)]
        gen3 = Generation.combine_templates_2d(tpl_list, sel, shape=target_shape)
        candidates.append(gen3)
    # Decision: select best by self-similarity (how well does generated match source structure?)
    best_idx, best_score, all_scores = Decision.select_generation(candidates, source_feat)
    return candidates[best_idx] if candidates else None, best_score, all_scores, source_feat


# ============================================================
# TASK 1: Digit Recognition (Perception -> Decision)
# ============================================================
def make_digit(d, noise=0.15, shift=(0, 0)):
    grid = [[0.0] * 8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r + shift[0], c + shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8:
            grid[nr][nc] = 1.0
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

def match_2d_shifted(img1, img2, shifts=(-2, -1, 0, 1, 2)):
    best = -1
    h = min(len(img1), len(img2))
    w = min(len(img1[0]) if img1 else 0, len(img2[0]) if img2 else 0)
    for dy in shifts:
        for dx in shifts:
            f1, f2 = [], []
            for i in range(h):
                for j in range(w):
                    f1.append(img1[i][j])
                    ni, nj = i + dy, j + dx
                    f2.append(img2[ni][nj] if 0 <= ni < len(img2) and 0 <= nj < len(img2[0]) else 0.0)
            s = cos(f1, f2)
            if s > best:
                best = s
    return best

def task_digit_pgd():
    """Digit recognition: Perception (2D features) -> Decision (classification)."""
    templates = {d: make_digit(d, noise=0) for d in range(6)}
    tpl_feats = {d: Perception.extract_2d(tpl) for d, tpl in templates.items()}
    correct_pgd = 0
    correct_std = 0
    correct_shift = 0
    total = 0
    for true_d in range(6):
        for _ in range(10):
            test = make_digit(true_d, noise=random.uniform(0.1, 0.3),
                              shift=(random.randint(-2, 2), random.randint(-2, 2)))
            # Standard: flat cosine
            best_d, best_s = -1, -1
            for d, tpl in templates.items():
                s = cos([x for row in test for x in row], [x for row in tpl for x in row])
                if s > best_s: best_s, best_d = s, d
            if best_d == true_d: correct_std += 1
            # Shift search
            best_d, best_s = -1, -1
            for d, tpl in templates.items():
                s = match_2d_shifted(test, tpl)
                if s > best_s: best_s, best_d = s, d
            if best_d == true_d: correct_shift += 1
            # PGD: perception -> decision
            feat = Perception.extract_2d(test)
            label, conf, scores = Decision.classify(feat, tpl_feats)
            if label == true_d: correct_pgd += 1
            total += 1
    return {'standard': correct_std / total, 'shift': correct_shift / total,
            'pgd': correct_pgd / total, 'total': total}


# ============================================================
# TASK 2: Digit Generation (Perception -> Generation -> Decision)
# ============================================================
def task_digit_generation():
    """Generate new digit by combining templates, verify with perception-decision."""
    templates = {d: make_digit(d, noise=0) for d in range(6)}
    tpl_list = list(templates.values())
    # Generate: combine top half of digit A with bottom half of digit B
    results = []
    for a in range(6):
        for b in range(6):
            if a == b:
                continue
            # Perception: extract features from both
            feat_a = Perception.extract_2d(templates[a])
            feat_b = Perception.extract_2d(templates[b])
            # Generation: selective combination (top from A, bottom from B)
            sel = [(a, 0, 0, 4, 8), (b, 4, 0, 8, 8)]
            generated = Generation.combine_templates_2d(tpl_list, sel, shape=(8, 8))
            # Decision: does the generated look like a valid digit?
            gen_feat = Perception.extract_2d(generated)
            tpl_feats = {d: Perception.extract_2d(tpl) for d, tpl in templates.items()}
            label, conf, scores = Decision.classify(gen_feat, tpl_feats)
            # Quality: max similarity to any template
            flat_gen = [x for row in generated for x in row]
            max_sim = max(cos(flat_gen, [x for row in tpl for x in row]) for tpl in tpl_list)
            results.append({
                'source_a': a, 'source_b': b, 'classified_as': label,
                'confidence': conf, 'max_template_sim': max_sim,
                'n_contrast_points': len(gen_feat.get('contrast_points', [])),
            })
    # Statistics
    valid = sum(1 for r in results if r['max_template_sim'] > 0.5)
    high_quality = sum(1 for r in results if r['max_template_sim'] > 0.7)
    avg_sim = sum(r['max_template_sim'] for r in results) / len(results)
    return {'total_generated': len(results), 'valid': valid, 'high_quality': high_quality,
            'avg_similarity': avg_sim, 'samples': results[:5]}


# ============================================================
# TASK 3: Anomaly Detection (Perception -> Decision -> Feedback)
# ============================================================
def task_anomaly_pgd():
    """Anomaly detection: perceive normal pattern, decide anomaly, feedback adapt."""
    random.seed(123)
    n = 300
    baseline = [math.sin(i * 0.1) + 0.5 * math.sin(i * 0.3) for i in range(n)]
    test = baseline[:]
    anomaly_pos = [40, 100, 160, 220, 280]
    labels = [0] * n
    for pos in anomaly_pos:
        for off in range(-2, 3):
            idx = pos + off
            if 0 <= idx < n:
                test[idx] += random.choice([-1, 1]) * random.uniform(0.7, 1.2)
                labels[idx] = 1
    # Perception: extract features
    feat = Perception.extract_1d(test, window=5)
    baseline_feat = Perception.extract_1d(baseline, window=5)
    # Decision: variance-based with adaptive threshold
    var = feat['variance']
    var_sorted = sorted(var)
    threshold = var_sorted[int(len(var_sorted) * 0.90)]
    detections = [i + 2 for i in range(len(var)) if var[i] > threshold]
    # Also use difference feature
    diff = [abs(test[i] - test[i - 1]) for i in range(1, n)]
    diff_feat = Perception.extract_1d(diff, window=5)
    diff_var = diff_feat['variance']
    diff_thresh = sorted(diff_var)[int(len(diff_var) * 0.85)] if diff_var else 0
    for i in range(len(diff_var)):
        if diff_var[i] > diff_thresh:
            detections.append(i + 1)
    detections = sorted(set(detections))
    # Feedback: evaluate and adjust
    true_set = set(i for i, l in enumerate(labels) if l == 1)
    tp = sum(1 for d in detections if any(abs(d - t) <= 3 for t in true_set))
    fp = len(detections) - tp
    fn = sum(1 for t in true_set if not any(abs(d - t) <= 3 for d in detections))
    p = tp / (tp + fp) if tp + fp else 0
    r = tp / (tp + fn) if tp + fn else 0
    f1 = 2 * p * r / (p + r) if p + r else 0
    # Feedback adjustment: if precision low, raise threshold
    feedback = Decision.feedback_loop((None, 0, {}), None)
    feedback['threshold_used'] = threshold
    feedback['precision'] = p
    feedback['recall'] = r
    return {'precision': p, 'recall': r, 'f1': f1, 'detections': len(detections),
            'n_contrast_points': len(feat['contrast_points']), 'feedback': feedback}


# ============================================================
# TASK 4: Text Generation & Classification (Perception -> Gen -> Decision)
# ============================================================
def task_text_pgd():
    """Text: perceive frequency patterns, generate hybrid text, classify."""
    vocab = 26
    topics = {
        'tech': [3,1,3,2,5,1,2,3,3,1,2,3,2,3,3,2,1,2,2,3,2,1,1,1,2,1],
        'sports': [3,1,1,1,3,1,1,1,3,1,1,1,2,3,3,2,1,2,3,3,1,1,1,1,1,1],
        'food': [3,1,1,3,2,3,1,1,2,1,1,1,1,2,3,1,1,1,2,3,1,1,1,1,1,1],
        'nature': [2,1,2,1,3,2,1,2,1,3,2,1,2,1,3,1,2,1,2,1,3,2,1,2,1,2],
    }
    def make_doc(topic, length=150):
        w = topics[topic]
        total = sum(w)
        freq = [0.0] * vocab
        for _ in range(length):
            r = random.random()
            cum = 0
            for idx, p in enumerate([x / total for x in w]):
                cum += p
                if r <= cum:
                    freq[idx] += 1
                    break
        s = sum(freq)
        return [f / s for f in freq]
    # Perception: extract features from topic templates
    tpl_feats = {}
    for topic, weights in topics.items():
        doc = make_doc(topic, length=200)
        tpl_feats[topic] = Perception.extract_1d(doc, window=3)
    # Generation: hybrid topic (selective frequency combination)
    topic_list = list(topics.keys())
    hybrid_results = []
    for i, t1 in enumerate(topic_list):
        for t2 in topic_list[i + 1:]:
            # Selective combination: first half vocab from t1, second from t2
            w1 = topics[t1]
            w2 = topics[t2]
            hybrid_w = w1[:13] + w2[13:]
            # Generate document from hybrid weights
            total = sum(hybrid_w)
            freq = [0.0] * vocab
            for _ in range(150):
                r = random.random()
                cum = 0
                for idx, p in enumerate([x / total for x in hybrid_w]):
                    cum += p
                    if r <= cum:
                        freq[idx] += 1
                        break
            s = sum(freq)
            hybrid_doc = [f / s for f in freq]
            # Decision: classify hybrid
            feat = Perception.extract_1d(hybrid_doc, window=3)
            label, conf, scores = Decision.classify(feat, tpl_feats)
            # Which source is closer?
            sim_t1 = cos(hybrid_doc, make_doc(t1, 150))
            sim_t2 = cos(hybrid_doc, make_doc(t2, 150))
            hybrid_results.append({
                'sources': (t1, t2), 'classified_as': label,
                'confidence': conf, 'sim_t1': sim_t1, 'sim_t2': sim_t2,
            })
    # Classification accuracy on pure docs
    correct = 0
    total = 0
    for true_t in topics:
        for _ in range(10):
            doc = make_doc(true_t)
            feat = Perception.extract_1d(doc, window=3)
            label, _, _ = Decision.classify(feat, tpl_feats)
            if label == true_t:
                correct += 1
            total += 1
    return {'classification_acc': correct / total, 'hybrid_count': len(hybrid_results),
            'hybrid_samples': hybrid_results[:4]}


# ============================================================
# TASK 5: Image Reconstruction (Perception -> Generation -> Decision)
# ============================================================
def task_image_reconstruction():
    """Reconstruct image from perceived features, measure information loss."""
    random.seed(789)
    h, w = 16, 16
    # Generate structured image
    image = []
    for i in range(h):
        row = []
        for j in range(w):
            val = 128 + 40 * math.sin(i * 0.3) + 30 * math.cos(j * 0.25) + random.gauss(0, 3)
            row.append(max(0, min(255, val)))
        image.append(row)
    # Perception
    feat = Perception.extract_2d(image, window=3)
    # Generation: reconstruct from features
    # Method 1: mean-based reconstruction
    flat = [x for row in image for x in row]
    feat_1d = Perception.extract_1d(flat, window=5)
    reconstructed_1d = Generation.reconstruct_from_features_1d(feat_1d, len(flat))
    recon_2d = [reconstructed_1d[i * w:(i + 1) * w] for i in range(h)]
    # Decision: evaluate reconstruction quality
    flat_recon = [x for row in recon_2d for x in row]
    sim = cos(flat, flat_recon)
    mse = sum((a - b) ** 2 for a, b in zip(flat, flat_recon)) / len(flat)
    psnr = 10 * math.log10(255 ** 2 / mse) if mse > 0 else 100
    # Contrast point retention
    contrast_recon = Perception.extract_2d(recon_2d, window=3).get('contrast_points', [])
    retention = len(set(feat['contrast_points']) & set(contrast_recon)) / max(len(feat['contrast_points']), 1)
    return {'cosine_similarity': sim, 'psnr_db': psnr, 'mse': mse,
            'contrast_retention': retention, 'n_contrast_original': len(feat['contrast_points']),
            'n_contrast_reconstructed': len(contrast_recon)}


# ============================================================
# TASK 6: Multi-Armed Bandit Decision (Perception -> Decision -> Feedback)
# ============================================================
def task_bandit_decision():
    """Decision-making with feedback adaptation: multi-armed bandit."""
    random.seed(999)
    n_arms = 5
    n_rounds = 100
    # True reward probabilities (unknown to agent)
    true_probs = [0.2, 0.5, 0.8, 0.3, 0.6]
    # Agent perception: reward history as features
    arm_features = {i: [] for i in range(n_arms)}
    rewards = []
    selections = []
    for round_idx in range(n_rounds):
        # Perception: build feature vector from history
        features = []
        for arm in range(n_arms):
            history = arm_features[arm]
            if history:
                # Perceived features: mean reward, variance, recent trend
                m = sum(history) / len(history)
                v = sum((x - m) ** 2 for x in history) / len(history)
                recent = sum(history[-3:]) / min(3, len(history))
                features.extend([m, v, recent])
            else:
                features.extend([0.5, 0.25, 0.5])  # prior
        # Decision: choose arm with highest perceived value
        # Use cosine similarity to "ideal" feature [1, 0, 1] (high mean, low var, high recent)
        ideal = [1.0, 0.0, 1.0] * n_arms
        # But also explore: add randomness for first 20 rounds
        if round_idx < 20:
            chosen = random.randint(0, n_arms - 1)
        else:
            scores = []
            for arm in range(n_arms):
                arm_feat = features[arm * 3:(arm + 1) * 3]
                try:
                    s = cos(arm_feat, ideal[:3])
                except Exception:
                    s = 0
                scores.append(s)
            chosen = scores.index(max(scores))
        # Execute: get reward
        reward = 1 if random.random() < true_probs[chosen] else 0
        arm_features[chosen].append(reward)
        rewards.append(reward)
        selections.append(chosen)
    # Feedback analysis
    total_reward = sum(rewards)
    optimal_arm = true_probs.index(max(true_probs))
    optimal_pulls = selections.count(optimal_arm)
    # Regret
    optimal_reward = max(true_probs) * n_rounds
    regret = optimal_reward - total_reward
    return {'total_reward': total_reward, 'optimal_pulls': optimal_pulls,
            'regret': regret, 'true_probs': true_probs,
            'selection_dist': Counter(selections), 'avg_reward': total_reward / n_rounds}


# ============================================================
# MAIN: Run all tasks, retrospective, generalize
# ============================================================
def run_all_tasks():
    print("=" * 70)
    print("PGD FULL-CHAIN FRAMEWORK - Round 1")
    print("Perception -> Generation -> Decision")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[Task 1] Digit Recognition (Perception -> Decision)")
    r = task_digit_pgd()
    results['digit'] = r
    print(f"  Standard: {r['standard']:.1%}, Shift: {r['shift']:.1%}, PGD: {r['pgd']:.1%}")

    print("\n[Task 2] Digit Generation (Perception -> Generation -> Decision)")
    r = task_digit_generation()
    results['generation'] = r
    print(f"  Generated: {r['total_generated']}, Valid(>0.5): {r['valid']}, "
          f"HighQ(>0.7): {r['high_quality']}, AvgSim: {r['avg_similarity']:.3f}")

    print("\n[Task 3] Anomaly Detection (Perception -> Decision -> Feedback)")
    r = task_anomaly_pgd()
    results['anomaly'] = r
    print(f"  P={r['precision']:.3f}, R={r['recall']:.3f}, F1={r['f1']:.3f}, "
          f"ContrastPts: {r['n_contrast_points']}")

    print("\n[Task 4] Text Classification & Hybrid Generation")
    r = task_text_pgd()
    results['text'] = r
    print(f"  Classification: {r['classification_acc']:.1%}, Hybrids: {r['hybrid_count']}")

    print("\n[Task 5] Image Reconstruction (Perception -> Generation -> Decision)")
    r = task_image_reconstruction()
    results['reconstruction'] = r
    print(f"  CosSim: {r['cosine_similarity']:.4f}, PSNR: {r['psnr_db']:.2f}dB, "
          f"ContrastRetention: {r['contrast_retention']:.1%}")

    print("\n[Task 6] Multi-Armed Bandit (Perception -> Decision -> Feedback)")
    r = task_bandit_decision()
    results['bandit'] = r
    print(f"  AvgReward: {r['avg_reward']:.3f}, OptimalPulls: {r['optimal_pulls']}/100, "
          f"Regret: {r['regret']:.1f}")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal time: {elapsed:.2f}s")
    return results


def retrospective_analysis(results):
    print("\n" + "=" * 70)
    print("RETROSPECTIVE ANALYSIS - Round 1")
    print("=" * 70)
    findings = []

    # 1. Perception layer analysis
    print("\n[Perception Layer]")
    digit = results.get('digit', {})
    print(f"  Digit: standard={digit.get('standard',0):.1%}, shift={digit.get('shift',0):.1%}, "
          f"PGD={digit.get('pgd',0):.1%}")
    if digit.get('pgd', 0) < digit.get('shift', 0):
        findings.append("PGD classification underperforms pure shift search - "
                        "feature-based decision loses spatial alignment info")
    anomaly = results.get('anomaly', {})
    print(f"  Anomaly: F1={anomaly.get('f1',0):.3f}, contrast_pts={anomaly.get('n_contrast_points',0)}")
    findings.append(f"Contrast points capture {anomaly.get('n_contrast_points',0)} info-rich regions")

    # 2. Generation layer analysis
    print("\n[Generation Layer]")
    gen = results.get('generation', {})
    print(f"  Digit gen: valid={gen.get('valid',0)}/{gen.get('total_generated',0)}, "
          f"avg_sim={gen.get('avg_similarity',0):.3f}")
    if gen.get('avg_similarity', 0) < 0.6:
        findings.append("Selective top/bottom combination produces low similarity - "
                        "need high-level guidance for template placement")
    recon = results.get('reconstruction', {})
    print(f"  Reconstruction: cos={recon.get('cosine_similarity',0):.4f}, "
          f"PSNR={recon.get('psnr_db',0):.1f}dB, contrast_retention={recon.get('contrast_retention',0):.1%}")
    if recon.get('contrast_retention', 0) < 0.5:
        findings.append("Reconstruction loses contrast points - "
                        "feature inverse mapping needs better detail preservation")

    # 3. Decision layer analysis
    print("\n[Decision Layer]")
    text = results.get('text', {})
    print(f"  Text classification: {text.get('classification_acc',0):.1%}")
    bandit = results.get('bandit', {})
    print(f"  Bandit: avg_reward={bandit.get('avg_reward',0):.3f}, "
          f"optimal_pulls={bandit.get('optimal_pulls',0)}, regret={bandit.get('regret',0):.1f}")
    if bandit.get('avg_reward', 0) < 0.6:
        findings.append("Bandit exploration-exploitation balance needs tuning - "
                        "cosine similarity to ideal may not capture value properly")

    # 4. Cross-chain analysis
    print("\n[Cross-Chain Integration]")
    print(f"  Full chain works: perception feeds decision, generation verified by decision")
    findings.append("PGD chain is functional but each layer has independent weaknesses")

    print(f"\nKey findings ({len(findings)}):")
    for i, f in enumerate(findings, 1):
        print(f"  {i}. {f}")
    return findings


def targeted_generalization(findings):
    """Apply targeted improvements based on retrospective findings."""
    print("\n" + "=" * 70)
    print("TARGETED GENERALIZATION - Round 2")
    print("=" * 70)
    improvements = []
    for f in findings:
        if "feature-based decision loses spatial alignment" in f:
            improvements.append("Fix 1: Add shift search inside PGD classification "
                                "(perceive features + shift alignment before decision)")
        if "high-level guidance for template placement" in f:
            improvements.append("Fix 2: Generation uses contrast points from perception "
                                "to guide template placement (not arbitrary top/bottom split)")
        if "detail preservation" in f:
            improvements.append("Fix 3: Reconstruction preserves contrast point values "
                                "exactly, fills rest from mean")
        if "exploration-exploitation" in f:
            improvements.append("Fix 4: Bandit uses UCB-like bonus based on variance "
                                "(uncertainty = exploration value)")
    print(f"\nPlanned improvements ({len(improvements)}):")
    for imp in improvements:
        print(f"  - {imp}")
    return improvements


if __name__ == '__main__':
    # Round 1
    r1 = run_all_tasks()
    findings = retrospective_analysis(r1)
    improvements = targeted_generalization(findings)

    # Save round 1
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_round1_results.json")
    with open(out, 'w') as f:
        json.dump({'results': r1, 'findings': findings, 'improvements': improvements},
                  f, indent=2, default=str)
    print(f"\nRound 1 saved: {out}")
    print("\n✅ PGD Round 1 complete. Round 2 will apply targeted improvements.")
