# Core Bottleneck Analysis & Improvement Roadmap
## Spatial Sensitivity in cos-comparison Training

---

## Problem Statement

### Evidence from 7 Rounds of Experiments

| Task | Spatial? | Standard | Direction-Enhanced | Delta |
|------|----------|----------|-------------------|-------|
| Digit Recognition | YES (shifted) | 22% | 100% | +78pp |
| Digit (integrated) | YES | 36.1% | 100% | +63.9pp |
| Text Classification | NO (bag-of-chars) | 90% | 90% | 0pp |
| DNA Motif | PARTIAL | 80% | 53.3% | -26.7pp |
| Audio Tone | FREQUENCY | 71.1% | 82.2% | +11.1pp |

### Root Cause

The cosine similarity operator is **position-sensitive**: it compares element-by-element at fixed indices. When patterns are spatially shifted:
- Corresponding features land at different indices
- Dot product becomes near-zero (orthogonal)
- Similarity collapses even for identical patterns

Conversely, when data is inherently position-invariant (bag-of-words, frequency histograms):
- Shift search adds computational cost with zero benefit
- Can even hurt by introducing spurious alignments

**This is the core bottleneck**: a single similarity operator cannot simultaneously handle spatial and non-spatial data optimally.

---

## Improvement Framework: 5-Layer Solution

### Layer 1: Spatial Invariance Detection (Auto-classify)

**Principle**: Before matching, detect whether the data is spatial or not.

**Method**:
1. Compute `local_variance` of the data
2. Compute variance of shuffled version
3. Ratio = original_variance / shuffled_variance
4. If ratio >> 1: data is spatial (structure matters)
5. If ratio ≈ 1: data is position-invariant (distribution matters)

**Implementation**:
```python
def detect_spatiality(data):
    """Return spatiality score: >1 = spatial, ≈1 = invariant."""
    import random
    var_orig = local_variance(data, local_size=(3,))
    shuffled = data[:]
    random.shuffle(shuffled)
    var_shuf = local_variance(shuffled, local_size=(3,))
    return sum(var_orig) / sum(var_shuf) if sum(var_shuf) > 0 else 1.0
```

**Action**:
- spatiality > 1.5 → use spatial-aware matching (Layer 2-4)
- spatiality < 1.2 → use standard cosine (position-invariant)
- 1.2-1.5 → hybrid (Layer 5)

---

### Layer 2: Keypoint-Based Alignment (Spatial Data)

**Principle**: Instead of brute-force shift search, first detect stable keypoints, then align by keypoint correspondence.

**Method** (using existing cos-comparison primitives):
1. **Extract keypoints**: high `local_variance` regions = corners/edges
2. **Describe keypoints**: local `cos_comparison_passive` features around each keypoint
3. **Match keypoints**: compare descriptors across images
4. **Estimate transform**: from matched keypoint pairs, infer translation
5. **Align and compare**: apply transform, then cosine similarity

**Why better than brute-force**:
- O(keypoints²) vs O(shift_positions × data_size)
- Keypoints are stable under shift, scale, mild rotation
- Uses existing `local_variance` and `cos_comparison_passive` — no new algorithms

**Continuous mapping integration**:
- Low abstraction layer: raw keypoints (spatial)
- High abstraction layer: keypoint descriptor histogram (spatial-invariant)
- Layer isolation naturally separates spatial from non-spatial info

---

### Layer 3: Multi-Scale Template Matching (Active Mode Enhancement)

**Principle**: Active mode currently uses fixed kernel size. Extend to multi-scale search.

**Method**:
1. Generate template pyramid: original, downsample 2x, downsample 4x
2. For each scale, run `cos_comparison_active`
3. Take max response across scales
4. Finer scales refine position, coarser scales find rough location

**Why it works**:
- Coarse scale: robust to large shifts, finds approximate location
- Fine scale: precise alignment at found location
- This is exactly how human vision works (glance → focus)

**Implementation with existing API**:
```python
def multiscale_active_match(data, template, scales=(1, 2, 4)):
    best_score = 0
    best_pos = None
    for scale in scales:
        # Downsample both
        data_s = downsample(data, scale)
        tpl_s = downsample(template, scale)
        result = cos_comparison_active(data_s, kernel=tpl_s)
        score = max(result)
        if score > best_score:
            best_score = score
    return best_score
```

---

### Layer 4: Spatial-Invariant Feature Transform (SIFT-like)

**Principle**: Transform spatial data into a spatial-invariant representation using existing primitives.

**Method**:
1. Divide data into overlapping local patches
2. For each patch, compute `cos_comparison_passive` features
3. Pool features into a histogram (order doesn't matter in histogram)
4. Compare histograms with cosine similarity

**This is the key insight**: 
- Local patches capture spatial structure (within patch)
- Histogram pooling removes spatial relationships (between patches)
- Result: representation that captures WHAT is present, not WHERE
- This is exactly how bag-of-visual-words works

**Continuous mapping layer isolation**:
- L1: raw pixels (fully spatial)
- L2: local passive features (partially spatial)
- L3: feature histogram (spatial-invariant)
- Each layer progressively removes spatial information while preserving content

---

### Layer 5: Hybrid Matching (Mixed Spatial/Non-spatial Data)

**Principle**: For data with both spatial and non-spatial components, match both and combine.

**Method**:
1. Compute spatial match score (with alignment)
2. Compute distribution match score (histogram, no alignment)
3. Weighted combination: `final = α * spatial + (1-α) * distribution`
4. α determined by spatiality score (Layer 1)

**Example**: 
- Face recognition: spatial (feature positions) + distribution (skin tone, lighting)
- α = 0.7 (mostly spatial)
- Audio: frequency distribution (non-spatial) + temporal order (spatial)
- α = 0.3 (mostly non-spatial)

---

## Priority Roadmap

### Immediate (Can implement now with existing API)

| Priority | Improvement | Expected Gain | Effort |
|----------|-------------|---------------|--------|
| P0 | Spatiality auto-detection (Layer 1) | Eliminates -27pp fusion failures | Low |
| P0 | Multi-scale active matching (Layer 3) | +20-30pp on shifted patterns | Low |
| P1 | Keypoint alignment (Layer 2) | +40-60pp on spatial tasks | Medium |
| P1 | Histogram pooling (Layer 4) | Converts spatial to invariant | Medium |

### Medium-term (Requires new primitives)

| Priority | Improvement | Expected Gain | Effort |
|----------|-------------|---------------|--------|
| P2 | Rotation-invariant descriptors | Handle rotated patterns | High |
| P2 | Scale-invariant keypoints | Handle scaled patterns | High |
| P3 | Affine transform estimation | Full geometric invariance | Very High |

### Long-term (Architectural)

| Priority | Improvement | Expected Gain | Effort |
|----------|-------------|---------------|--------|
| P3 | Native spatial-invariant similarity function | Eliminates bottleneck entirely | Very High |
| P4 | Learned alignment (behavior-as-data) | Adaptive to data type | Very High |

---

## Validation Plan

### Test Suite for Spatial Robustness

1. **MNIST-like digits** with random shifts (±3px), rotations (±15°), scaling (0.8-1.2x)
2. **Face patches** with random cropping and alignment errors
3. **Audio clips** with time shifts and tempo changes
4. **DNA sequences** with insertions/deletions (not just substitution)
5. **Text documents** with word reordering (should remain invariant)

### Success Criteria

| Metric | Current | Target |
|--------|---------|--------|
| Shifted digit recognition | 22% | >90% |
| Position-invariant text | 90% | ≥90% (no degradation) |
| Mixed data (faces) | N/A | >80% |
| Cross-scale matching | N/A | >75% |

---

## Core Principle Validation

This roadmap directly validates the project's core principles:

1. **Continuous mapping layer isolation**: Each layer progressively removes spatial info. L1=spatial, L3=invariant. This is exactly "按需提取" — extract spatial info when needed, filter it when not.

2. **Active + passive dual mode**: Passive extracts local features (keypoints), Active matches templates (alignment). Their combination solves spatial sensitivity.

3. **Behavior-as-data**: The spatiality detector and α-weight can be stored as data, allowing the same fixed code to handle both spatial and non-spatial tasks.

4. **Contrast point crossover**: Keypoints ARE contrast points (high variance = high information). Aligning by contrast points is exactly "信息产生在差异".

---

## Conclusion

The spatial sensitivity bottleneck is **solvable within the existing architecture** — no deep learning, no external dependencies required. The key is:

1. **Detect** whether data is spatial (Layer 1)
2. **Align** spatial data via keypoints or multi-scale (Layers 2-3)
3. **Transform** to invariant representation when needed (Layer 4)
4. **Combine** both for mixed data (Layer 5)

All layers use existing cos-comparison primitives (`local_variance`, `cos_comparison_passive`, `cos_comparison_active`, `mean_local`). The improvement is in **how these primitives are composed**, not in new algorithms.

This is consistent with the project's philosophy: fixed code + variable behavior (data-driven) = universal capability.
