"""
PGD v8: Coarse-to-fine angle search + contrast-point tiebreaker + feedback in matching.

Targets remaining bottlenecks from v7.1:
1. 0<->4 confusion (closed ring vs open-top): multi-scale verification
2. 2->3 confusion: finer angle search near best estimate
3. Angle estimation 90/180 deg errors: coarse-to-fine with verification
4. Low discrimination (0.74-0.80): contrast point pattern as secondary score

No arbitrary weighting: all fusions have explicit mathematical meaning.
- Primary: pixel cosine at best rotation+shift (intensity agreement)
- Secondary: symmetric kernel cosine (structural agreement) - 0.25 weight (v6 proven)
- Tiebreaker: contrast point overlap ratio (structural feature agreement) - used only when primary scores close
"""
import os, time, math, json, random
from collections import defaultdict, Counter
from cos_comparison.core import cos, local_variance, mean_local

random.seed(42)

# ============================================================
# Utilities
# ============================================================
def rotate_2d(matrix, angle_deg):
    h, w = len(matrix), len(matrix[0])
    angle = math.radians(angle_deg)
    ca, sa = math.cos(angle), math.sin(angle)
    result = [[0.0]*w for _ in range(h)]
    cx, cy = w/2, h/2
    for i in range(h):
        for j in range(w):
            x, y = j-cx, i-cy
            sx = x*ca + y*sa + cx
            sy = -x*sa + y*ca + cy
            si, sj = int(round(sy)), int(round(sx))
            if 0 <= si < h and 0 <= sj < w:
                result[i][j] = matrix[si][sj]
    return result

def symmetric_kernel_variance(matrix, radius=1):
    h, w = len(matrix), len(matrix[0])
    result = [[0.0]*w for _ in range(h)]
    for i in range(h):
        for j in range(w):
            vals = []
            for di in range(-radius, radius+1):
                for dj in range(-radius, radius+1):
                    if di*di+dj*dj <= radius*radius:
                        ni, nj = i+di, j+dj
                        if 0 <= ni < h and 0 <= nj < w:
                            vals.append(matrix[ni][nj])
            if vals:
                m = sum(vals)/len(vals)
                result[i][j] = sum((v-m)**2 for v in vals)/len(vals)
    return result

# ============================================================
# Feedback contrast extractor (refined points used in matching)
# ============================================================
class FeedbackContrastExtractor:
    def __init__(self, percentile=85, min_points=3, max_points=12):
        self.percentile = percentile
        self.min_points = min_points
        self.max_points = max_points
        self.point_contribution = defaultdict(float)
        self.match_count = 0
        self.max_abs_contrib = 1.0

    def extract(self, matrix):
        h, w = len(matrix), len(matrix[0])
        sk = symmetric_kernel_variance(matrix, 1)
        scored = [(sk[i][j], i, j) for i in range(h) for j in range(w)]
        scored.sort(reverse=True)
        n_take = max(self.min_points, min(self.max_points,
                     int(len(scored) * (100 - self.percentile) / 100)))
        return [(i, j) for _, i, j in scored[:n_take]]

    def record_feedback(self, points, match_score, is_correct):
        self.match_count += 1
        contrib = match_score if is_correct else -match_score
        for p in points:
            self.point_contribution[p] += contrib
            if abs(self.point_contribution[p]) > self.max_abs_contrib:
                self.max_abs_contrib = abs(self.point_contribution[p])

    def get_refined_points(self, matrix):
        """Re-rank by variance * proven usefulness. Used in matching after feedback."""
        h, w = len(matrix), len(matrix[0])
        sk = symmetric_kernel_variance(matrix, 1)
        candidates = self.extract(matrix)
        if self.match_count < 10:
            return candidates
        scored = []
        for (i, j) in candidates:
            variance = sk[i][j]
            contrib = self.point_contribution.get((i, j), 0.0) / self.max_abs_contrib
            usefulness = 1.0 + contrib * 0.5
            scored.append((variance * usefulness, i, j))
        scored.sort(reverse=True)
        return [(i, j) for _, i, j in scored[:len(candidates)]]

# ============================================================
# Contrast point overlap (tiebreaker)
# ============================================================
def contrast_overlap(points_a, points_b, max_shift=2, tolerance=1):
    """Count how many contrast points in A align with B after best shift.

    Mathematical meaning: structural feature agreement.
    Two images with same structure should have contrast points at same relative positions.
    Used as tiebreaker when primary pixel cosine scores are close.
    Returns (overlap_ratio, best_shift).
    """
    best_overlap = 0
    best_shift = (0, 0)
    set_b = set(points_b)
    for dx in range(-max_shift, max_shift + 1):
        for dy in range(-max_shift, max_shift + 1):
            shifted_a = set((i + dx, j + dy) for (i, j) in points_a)
            overlap = 0
            for (ai, aj) in shifted_a:
                for di in range(-tolerance, tolerance + 1):
                    for dj in range(-tolerance, tolerance + 1):
                        if (ai + di, aj + dj) in set_b:
                            overlap += 1
                            break
                    else:
                        continue
                    break
            if overlap > best_overlap:
                best_overlap = overlap
                best_shift = (dx, dy)
    denom = min(len(points_a), len(points_b))
    return (best_overlap / denom if denom > 0 else 0.0), best_shift

# ============================================================
# Coarse-to-fine rotation + shift matching
# ============================================================
COARSE_ANGLES = (0, 30, 45, 60, 90, 120, 135, 180, 225, 270)
FINE_OFFSETS = (-15, 0, 15)  # fine search around best coarse angle

def match_at_angle_shift(img1, rotated, dx, dy, sk1_flat):
    """Compute pixel cosine + symmetric kernel similarity at given alignment."""
    h, w = len(img1), len(img1[0])
    a_vals, b_vals = [], []
    for i in range(h):
        for j in range(w):
            bi, bj = i - dx, j - dy
            if 0 <= bi < h and 0 <= bj < w:
                a_vals.append(img1[i][j])
                b_vals.append(rotated[bi][bj])
    if len(a_vals) < h * w * 0.5:
        return -1, 0.0
    try: pix_cos = cos(a_vals, b_vals)
    except: pix_cos = 0.0
    sk2 = symmetric_kernel_variance(rotated, 1)
    try: sk_sim = cos(sk1_flat, [x for r in sk2 for x in r])
    except: sk_sim = 0.0
    # v6 proven: 0.75 intensity + 0.25 structure (both have clear meaning)
    score = 0.75 * pix_cos + 0.25 * sk_sim
    return score, pix_cos

def rotation_shift_match(img1, img2, extractor, use_refined=False, max_shift=2):
    """Coarse-to-fine: 10 angles -> refine best angle with ±15° -> shift search.

    Returns (best_score, best_angle, best_shift, best_pix_cos, contrast_overlap).
    """
    h, w = len(img1), len(img1[0])
    sk1 = symmetric_kernel_variance(img1, 1)
    sk1_flat = [x for r in sk1 for x in r]
    pts1 = extractor.get_refined_points(img1) if use_refined else extractor.extract(img1)

    # Phase 1: coarse angle search (all shifts at each angle)
    coarse_results = []
    for angle in COARSE_ANGLES:
        rotated = rotate_2d(img2, angle)
        best_for_angle = (-1, (0, 0), 0.0)
        for dx in range(-max_shift, max_shift + 1):
            for dy in range(-max_shift, max_shift + 1):
                score, pix = match_at_angle_shift(img1, rotated, dx, dy, sk1_flat)
                if score > best_for_angle[0]:
                    best_for_angle = (score, (dx, dy), pix)
        coarse_results.append((angle, best_for_angle[0], best_for_angle[1], best_for_angle[2]))
    coarse_results.sort(key=lambda x: x[1], reverse=True)
    best_coarse_angle = coarse_results[0][0]

    # Phase 2: fine search around best coarse angle (±15°)
    fine_angles = [best_coarse_angle + off for off in FINE_OFFSETS]
    best_score = -1
    best_angle = best_coarse_angle
    best_shift = (0, 0)
    best_pix = 0.0
    for angle in fine_angles:
        angle_norm = angle % 360
        rotated = rotate_2d(img2, angle_norm)
        for dx in range(-max_shift, max_shift + 1):
            for dy in range(-max_shift, max_shift + 1):
                score, pix = match_at_angle_shift(img1, rotated, dx, dy, sk1_flat)
                if score > best_score:
                    best_score = score
                    best_angle = angle_norm
                    best_shift = (dx, dy)
                    best_pix = pix

    # Phase 3: contrast overlap at best alignment (tiebreaker feature)
    rotated_best = rotate_2d(img2, best_angle)
    pts2 = extractor.extract(rotated_best)
    c_overlap, _ = contrast_overlap(pts1, pts2, max_shift=max_shift)

    return best_score, best_angle, best_shift, best_pix, c_overlap

# ============================================================
# Recognizer with tiebreaker
# ============================================================
class PatternRecognizerV8:
    def __init__(self):
        self.extractor = FeedbackContrastExtractor(percentile=85)
        self.templates = {}
        self.tiebreaker_threshold = 0.03  # if top1-top2 < this, use contrast overlap

    def train(self, label, matrix):
        self.templates[label] = matrix

    def validate(self, matrix, return_details=False, use_refined=False):
        """Match with tiebreaker: if top1-top2 close, contrast overlap decides."""
        results = []
        for label, tpl in self.templates.items():
            score, angle, shift, pix, cov = rotation_shift_match(
                matrix, tpl, self.extractor, use_refined=use_refined, max_shift=2)
            results.append((label, score, angle, shift, pix, cov))
        results.sort(key=lambda x: x[1], reverse=True)

        # Tiebreaker: if top1 and top2 primary scores are close, contrast overlap decides
        if len(results) >= 2:
            gap = results[0][1] - results[1][1]
            if gap < self.tiebreaker_threshold:
                # Re-rank top-2 by contrast overlap (structural feature agreement)
                top2 = results[:2]
                top2.sort(key=lambda x: x[5], reverse=True)
                results = top2 + results[2:]

        if return_details:
            return results
        return results[0][0], results[0][1]

    def feedback(self, matrix, predicted, correct):
        points = self.extractor.extract(matrix)
        self.extractor.record_feedback(points, 1.0, predicted == correct)

# ============================================================
# Digit generator
# ============================================================
def make_digit(d, noise=0.15, shift=(0,0), rotation=0):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r+shift[0], c+shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    if rotation != 0: grid = rotate_2d(grid, rotation)
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

# ============================================================
# TASKS
# ============================================================
def task_difficulty_curve(use_refined=False):
    rec = PatternRecognizerV8()
    for d in range(6): rec.train(d, make_digit(d, 0))
    conditions = [
        ('clean', 0.0, 0, (0,0)),
        ('noise=0.2', 0.2, 0, (0,0)),
        ('rot=random', 0.1, 'random', (0,0)),
        ('shift=±1', 0.1, 0, 'random'),
        ('rot=45+shift', 0.1, 45, 'random'),
        ('rot=random+shift', 0.1, 'random', 'random'),
        ('hard: rot+shift+noise0.15', 0.15, 'random', 'random'),
    ]
    results = {}
    for name, noise, rot, shift in conditions:
        correct = 0
        total = 0
        for true_d in range(6):
            for _ in range(5):
                r = random.choice([0,30,45,60,90,120,135,180,225,270]) if rot=='random' else rot
                s = (random.randint(-1,1), random.randint(-1,1)) if shift=='random' else shift
                test = make_digit(true_d, noise=noise, rotation=r, shift=s)
                pred, _ = rec.validate(test, use_refined=use_refined)
                if pred == true_d: correct += 1
                total += 1
        results[name] = correct / total
        print(f"  {name:35s}: {correct/total:.1%} ({correct}/{total})")
    return results

def task_feedback_ablation():
    """Compare: no feedback vs with feedback (refined points in matching)."""
    # No feedback
    rec1 = PatternRecognizerV8()
    for d in range(6): rec1.train(d, make_digit(d, 0))
    correct1 = 0
    for true_d in range(6):
        for _ in range(5):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec1.validate(test, use_refined=False)
            if pred == true_d: correct1 += 1

    # With feedback (100 rounds)
    rec2 = PatternRecognizerV8()
    for d in range(6): rec2.train(d, make_digit(d, 0))
    for _ in range(100):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, _ = rec2.validate(test, use_refined=False)
            rec2.feedback(test, pred, true_d)
    correct2 = 0
    for true_d in range(6):
        for _ in range(5):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec2.validate(test, use_refined=True)
            if pred == true_d: correct2 += 1

    return {'no_feedback': correct1/30, 'with_feedback': correct2/30,
            'improvement': (correct2-correct1)/30}

def task_confusion_matrix():
    rec = PatternRecognizerV8()
    for d in range(6): rec.train(d, make_digit(d, 0))
    confusion = defaultdict(lambda: defaultdict(int))
    for true_d in range(6):
        for _ in range(20):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            confusion[true_d][pred] += 1
    print("  true\\pred  " + "  ".join(f"{d}" for d in range(6)))
    for true_d in range(6):
        row = "  ".join(f"{confusion[true_d][d]:3d}" for d in range(6))
        c = confusion[true_d][true_d]
        print(f"  {true_d}         {row}   ({c}/20)")
    total_correct = sum(confusion[d][d] for d in range(6))
    return {'accuracy': total_correct / 120, 'confusion': {str(k): dict(v) for k, v in confusion.items()}}

def task_generation():
    rec = PatternRecognizerV8()
    for d in range(6): rec.train(d, make_digit(d, 0))
    gen_sims = []
    for true_d in range(6):
        for angle in [0, 45, 90, 180]:
            test = make_digit(true_d, noise=0.1, rotation=angle, shift=(1, -1))
            details = rec.validate(test, return_details=True)
            pred, score, best_angle, (dx, dy), pix, cov = details[0]
            tpl = rec.templates[pred]
            aligned = rotate_2d(tpl, best_angle)
            h, w = 8, 8
            generated = [[0.0]*w for _ in range(h)]
            for i in range(h):
                for j in range(w):
                    bi, bj = i - dx, j - dy
                    if 0 <= bi < h and 0 <= bj < w:
                        generated[i][j] = aligned[bi][bj]
            pts = rec.extractor.extract(test)
            for (ci, cj) in pts[:5]:
                if 0 <= ci < h and 0 <= cj < w and test[ci][cj] > 0.3:
                    generated[ci][cj] = test[ci][cj]
            gen_sim = cos([x for r in generated for x in r], [x for r in test for x in r])
            gen_sims.append(gen_sim)
    return {'mean': sum(gen_sims)/len(gen_sims), 'min': min(gen_sims), 'max': max(gen_sims)}

# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':
    print("=" * 70)
    print("PGD v8: Coarse-to-Fine Angle + Contrast Tiebreaker + Feedback Matching")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Difficulty Curve")
    r = task_difficulty_curve(use_refined=False)
    results['difficulty'] = r

    print("\n[2] Feedback Ablation (refined points in matching)")
    r = task_feedback_ablation()
    results['feedback'] = r
    print(f"  No feedback:     {r['no_feedback']:.1%}")
    print(f"  With feedback:   {r['with_feedback']:.1%}")
    print(f"  Improvement:     {r['improvement']*100:+.1f}pp")

    print("\n[3] Confusion Matrix (hard condition, 20/digit)")
    r = task_confusion_matrix()
    results['confusion'] = r
    print(f"  Overall: {r['accuracy']:.1%}")

    print("\n[4] Generation")
    r = task_generation()
    results['generation'] = r
    print(f"  Mean: {r['mean']:.3f}, range: [{r['min']:.3f}, {r['max']:.3f}]")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.1f}s")

    print("\n" + "=" * 70)
    print("v7.1 -> v8 COMPARISON")
    print("=" * 70)
    hard = 'hard: rot+shift+noise0.15'
    print(f"  Hard condition: v7.1=76.7% -> v8={results['difficulty'].get(hard, 0):.1%}")
    print(f"  Rot+shift:      v7.1=83.3% -> v8={results['difficulty'].get('rot=random+shift', 0):.1%}")
    print(f"  Feedback:       v7.1=+3.3pp -> v8={results['feedback']['improvement']*100:+.1f}pp")
    print(f"  Generation:     v7.1=0.953 -> v8={results['generation']['mean']:.3f}")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_v8_results.json")
    with open(out, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved: {out}")
    print("\n✅ PGD v8 complete.")
