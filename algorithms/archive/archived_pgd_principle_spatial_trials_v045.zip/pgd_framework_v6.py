"""
PGD v6: Final fixes based on v5 diagnostic.
1. Cross-modal: use spatial_dist (90% discriminative) instead of contrast_hist (30%)
2. Template library: store labels with templates, no index guessing
3. Full-chain: direct rotation-invariant matching + structure-guided generation
4. Rotation: 12 angles including non-90 multiples
"""
import os, time, math, json, random
from collections import defaultdict, Counter
from cos_comparison.core import cos, local_variance, mean_local

random.seed(42)

# ============================================================
# Utilities
# ============================================================
def rotate_2d(matrix, angle_deg):
    h, w = len(matrix), len(matrix[0])
    angle = math.radians(angle_deg)
    ca, sa = math.cos(angle), math.sin(angle)
    result = [[0.0]*w for _ in range(h)]
    cx, cy = w/2, h/2
    for i in range(h):
        for j in range(w):
            x, y = j-cx, i-cy
            sx = x*ca + y*sa + cx
            sy = -x*sa + y*ca + cy
            si, sj = int(round(sy)), int(round(sx))
            if 0 <= si < h and 0 <= sj < w:
                result[i][j] = matrix[si][sj]
    return result

def symmetric_kernel_variance(matrix, radius=1):
    h, w = len(matrix), len(matrix[0])
    result = [[0.0]*w for _ in range(h)]
    for i in range(h):
        for j in range(w):
            vals = []
            for di in range(-radius, radius+1):
                for dj in range(-radius, radius+1):
                    if di*di+dj*dj <= radius*radius:
                        ni, nj = i+di, j+dj
                        if 0 <= ni < h and 0 <= nj < w:
                            vals.append(matrix[ni][nj])
            if vals:
                m = sum(vals)/len(vals)
                result[i][j] = sum((v-m)**2 for v in vals)/len(vals)
    return result

def spatial_contrast_distribution(matrix, grid=4):
    h, w = len(matrix), len(matrix[0])
    sk = symmetric_kernel_variance(matrix, 1)
    ch, cw = h//grid, w//grid
    feat = []
    for gi in range(grid):
        for gj in range(grid):
            vals = []
            for i in range(gi*ch, min((gi+1)*ch, h)):
                for j in range(gj*cw, min((gj+1)*cw, w)):
                    vals.append(sk[i][j])
            feat.append(sum(vals)/len(vals) if vals else 0)
    return feat

def rotation_invariant_match(img1, img2, angles=(0, 30, 45, 60, 90, 120, 135, 180, 225, 270)):
    best = -1
    best_angle = 0
    for angle in angles:
        rot = rotate_2d(img2, angle)
        f1 = [x for r in img1 for x in r]
        f2 = [x for r in rot for x in r]
        try: s = cos(f1, f2)
        except: s = 0
        if s > best: best, best_angle = s, angle
    sk1 = symmetric_kernel_variance(img1, 1)
    sk2 = symmetric_kernel_variance(img2, 1)
    try: sk_s = cos([x for r in sk1 for x in r], [x for r in sk2 for x in r])
    except: sk_s = 0
    return 0.75*best + 0.25*sk_s, best_angle, sk_s

# ============================================================
# Cross-Modal Mapper v3 (uses spatial_dist, k-NN after mapping)
# ============================================================
class CrossModalMapperV3:
    def __init__(self, k=5):
        self.pairs = []
        self.labels = []
        self.k = k
        self.mapping = None
        self.a_mean = None
        self.b_mean = None

    def add_pair(self, feat_a, feat_b, label=None):
        self.pairs.append((feat_a, feat_b))
        self.labels.append(label)

    def train(self):
        if len(self.pairs) < 5: return
        ad = len(self.pairs[0][0])
        bd = len(self.pairs[0][1])
        cross = [[0.0]*bd for _ in range(ad)]
        am = [0.0]*ad
        bm = [0.0]*bd
        for fa, fb in self.pairs:
            for i in range(ad): am[i] += fa[i]/len(self.pairs)
            for j in range(bd): bm[j] += fb[j]/len(self.pairs)
        for fa, fb in self.pairs:
            for i in range(ad):
                for j in range(bd):
                    cross[i][j] += (fa[i]-am[i])*(fb[j]-bm[j])/len(self.pairs)
        self.mapping = cross
        self.a_mean = am
        self.b_mean = bm

    def map_a_to_b(self, fa):
        if self.mapping is None: return None
        bd = len(self.mapping[0])
        result = [0.0]*bd
        for j in range(bd):
            ws, wsum = 0.0, 0.0
            for i in range(len(fa)):
                w = abs(self.mapping[i][j])
                ws += w * fa[i]
                wsum += w
            result[j] = self.b_mean[j] + (ws/wsum if wsum > 0 else 0)
        return result

    def classify(self, feat_a):
        """k-NN in mapped B space."""
        mapped = self.map_a_to_b(feat_a)
        if mapped is None: return None, 0
        dists = []
        for idx, (_, fb) in enumerate(self.pairs):
            d = sum((mapped[j]-fb[j])**2 for j in range(len(fb)))
            dists.append((d, self.labels[idx]))
        dists.sort()
        top = dists[:self.k]
        vote = Counter(l for _, l in top)
        pred = vote.most_common(1)[0][0]
        conf = vote.most_common(1)[0][1] / self.k
        return pred, conf

    def classify_direct_knn(self, feat_a):
        """Direct k-NN in A space (no mapping) - upper bound."""
        dists = []
        for idx, (fa, _) in enumerate(self.pairs):
            ml = min(len(feat_a), len(fa))
            d = sum((feat_a[j]-fa[j])**2 for j in range(ml))
            dists.append((d, self.labels[idx]))
        dists.sort()
        top = dists[:self.k]
        vote = Counter(l for _, l in top)
        return vote.most_common(1)[0][0]

# ============================================================
# Template Library with Labels
# ============================================================
class LabeledTemplateLibrary:
    def __init__(self, threshold=0.70):
        self.templates = []  # (template, label, level)
        self.threshold = threshold

    def add(self, template, label, level=2):
        # Check similarity with existing same-label templates
        for tpl, lbl, lvl in self.templates:
            if lbl == label and lvl == level:
                f1 = [x for r in template for x in r]
                f2 = [x for r in tpl for x in r]
                try:
                    if cos(f1, f2) >= self.threshold:
                        return  # duplicate, skip
                except: pass
        self.templates.append((template, label, level))
        return len(self.templates) - 1

    def match(self, query, top_k=3):
        scores = []
        for idx, (tpl, label, level) in enumerate(self.templates):
            score, _, _ = rotation_invariant_match(query, tpl)
            scores.append((idx, score, label))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

    def size(self):
        return len(self.templates)

# ============================================================
# Perception
# ============================================================
class Perception:
    @staticmethod
    def extract_2d(matrix):
        h, w = len(matrix), len(matrix[0])
        f = {'raw': matrix, 'flat': [x for r in matrix for x in r], 'shape': (h,w)}
        f['symmetric_kernel'] = symmetric_kernel_variance(matrix, 1)
        f['spatial_dist'] = spatial_contrast_distribution(matrix, grid=4)
        sk_flat = [x for r in f['symmetric_kernel'] for x in r]
        vmax = max(sk_flat) if sk_flat else 1
        f['contrast_points'] = [(i//w, i%w) for i,v in enumerate(sk_flat) if v > vmax*0.3]
        return f

# ============================================================
# Digit generator
# ============================================================
def make_digit(d, noise=0.15, shift=(0,0), rotation=0):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r+shift[0], c+shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    if rotation != 0: grid = rotate_2d(grid, rotation)
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

# ============================================================
# TASKS
# ============================================================
def task_rotation():
    templates = {d: make_digit(d, 0) for d in range(6)}
    angles = [0, 15, 30, 45, 60, 75, 90, 120, 135, 180, 225, 270]
    c_std = c_rot = c_spatial = 0
    total = 0
    for true_d in range(6):
        for angle in angles:
            test = make_digit(true_d, noise=0.1, rotation=angle)
            # Standard
            bd, bs = -1, -1
            for d, t in templates.items():
                s = cos([x for r in test for x in r], [x for r in t for x in r])
                if s > bs: bs, bd = s, d
            if bd == true_d: c_std += 1
            # Rotation-invariant
            bd, bs = -1, -1
            for d, t in templates.items():
                s, _, _ = rotation_invariant_match(test, t)
                if s > bs: bs, bd = s, d
            if bd == true_d: c_rot += 1
            # Spatial distribution (rotation-robust)
            bd, bs = -1, -1
            for d, t in templates.items():
                s = cos(spatial_contrast_distribution(test), spatial_contrast_distribution(t))
                if s > bs: bs, bd = s, d
            if bd == true_d: c_spatial += 1
            total += 1
    return {'standard': c_std/total, 'rotation_invariant': c_rot/total,
            'spatial_dist': c_spatial/total, 'angles': len(angles)}

def task_cross_modal_v3():
    """Cross-modal: image spatial_dist -> 'semantic' internal code via mapping + k-NN."""
    mapper = CrossModalMapperV3(k=5)
    # Internal "semantic" codes: one-hot-ish 6-dim vectors (the model's internal language)
    internal_codes = {d: [1.0 if i == d else 0.0 for i in range(6)] for d in range(6)}
    # Train: 300 pairs
    for _ in range(300):
        d = random.randint(0, 5)
        img = make_digit(d, noise=random.uniform(0.05, 0.2),
                         rotation=random.choice([0,0,0,0,30,45,60,90,120,135,180,225,270]))
        feat = Perception.extract_2d(img)
        img_feat = feat['spatial_dist']  # 16-dim, 90% discriminative
        code = [max(0, v + random.gauss(0, 0.02)) for v in internal_codes[d]]
        mapper.add_pair(img_feat, code, label=d)
    mapper.train()
    # Test: mapped k-NN vs direct k-NN
    correct_mapped = 0
    correct_direct = 0
    total = 0
    for true_d in range(6):
        for _ in range(8):
            img = make_digit(true_d, noise=random.uniform(0.05, 0.15),
                             rotation=random.choice([0, 15, 30, 45, 60, 75, 90, 120, 135, 180, 225, 270]))
            feat = Perception.extract_2d(img)
            img_feat = feat['spatial_dist']
            pred_mapped, _ = mapper.classify(img_feat)
            pred_direct = mapper.classify_direct_knn(img_feat)
            if pred_mapped == true_d: correct_mapped += 1
            if pred_direct == true_d: correct_direct += 1
            total += 1
    return {'mapped_accuracy': correct_mapped/total, 'direct_knn_accuracy': correct_direct/total,
            'total': total, 'train_pairs': len(mapper.pairs), 'k': mapper.k}

def task_template_library_v3():
    lib = LabeledTemplateLibrary(threshold=0.70)
    templates = {d: make_digit(d, 0) for d in range(6)}
    for d in range(6):
        lib.add(templates[d], label=d, level=2)
        for angle in [45, 90, 135, 180, 225, 270]:
            lib.add(rotate_2d(templates[d], angle), label=d, level=2)
    # Test: rotated digit 3
    test = make_digit(3, noise=0.1, rotation=45)
    matches = lib.match(test, top_k=3)
    # Majority vote among top-3 labels
    labels = [m[2] for m in matches]
    pred = Counter(labels).most_common(1)[0][0]
    return {'library_size': lib.size(), 'top_matches': [(idx, round(s,3), lbl) for idx,s,lbl in matches],
            'predicted': pred, 'actual': 3, 'correct': pred == 3}

def task_full_chain_v6():
    """Full chain: perceive rotated digit -> match (rotation-invariant) -> generate."""
    templates = {d: make_digit(d, 0) for d in range(6)}
    # Input: rotated 45 + shifted
    test = make_digit(3, noise=0.15, shift=(1, -1), rotation=45)
    feat = Perception.extract_2d(test)
    # Decision: rotation-invariant matching
    scores = []
    for d, tpl in templates.items():
        s, angle, sk = rotation_invariant_match(test, tpl)
        scores.append((d, s, angle))
    scores.sort(key=lambda x: x[1], reverse=True)
    predicted = scores[0][0]
    best_angle = scores[0][2]
    # Generation: rotate matched template back to input orientation + contrast overlay
    matched = templates[predicted]
    # Rotate matched template by best_angle to align with input
    aligned = rotate_2d(matched, best_angle)
    h, w = 8, 8
    generated = [row[:] for row in aligned[:h]]
    while len(generated) < h: generated.append([0.0]*w)
    for row in generated:
        while len(row) < w: row.append(0.0)
    # Overlay contrast points from input (selective, not overwriting strong structure)
    for (ci, cj) in feat['contrast_points'][:8]:
        if 0 <= ci < h and 0 <= cj < w:
            if generated[ci][cj] < 0.3 and test[ci][cj] > 0.3:
                generated[ci][cj] = test[ci][cj]
    gen_sim = cos([x for r in generated for x in r], [x for r in test for x in r])
    return {'predicted': predicted, 'actual': 3, 'correct': predicted == 3,
            'best_rotation_angle': best_angle,
            'top3': [(d, round(s,3), a) for d,s,a in scores[:3]],
            'generation_similarity': gen_sim,
            'contrast_points': len(feat['contrast_points'])}

# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':
    print("=" * 70)
    print("PGD v6: Final - Cross-Modal + Template Library + Full Chain")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Rotation Invariance (12 angles)")
    r = task_rotation()
    results['rotation'] = r
    print(f"  Standard: {r['standard']:.1%}")
    print(f"  Multi-angle+symkernel: {r['rotation_invariant']:.1%}")
    print(f"  Spatial distribution: {r['spatial_dist']:.1%}")

    print("\n[2] Cross-Modal Mapping v3 (300 pairs, spatial_dist, k=5)")
    r = task_cross_modal_v3()
    results['cross_modal'] = r
    print(f"  Mapped k-NN: {r['mapped_accuracy']:.1%}")
    print(f"  Direct k-NN (upper bound): {r['direct_knn_accuracy']:.1%}")
    print(f"  Train pairs: {r['train_pairs']}")

    print("\n[3] Labeled Template Library")
    r = task_template_library_v3()
    results['templates'] = r
    print(f"  Library size: {r['library_size']}")
    print(f"  Top matches: {r['top_matches']}")
    print(f"  Predicted: {r['predicted']}, Actual: {r['actual']}, Correct: {r['correct']}")

    print("\n[4] Full Chain (rotated 45° + shifted)")
    r = task_full_chain_v6()
    results['full_chain'] = r
    print(f"  Predicted: {r['predicted']}, Actual: {r['actual']}, Correct: {r['correct']}")
    print(f"  Best rotation: {r['best_rotation_angle']}°")
    print(f"  Top3: {r['top3']}")
    print(f"  Generation similarity: {r['generation_similarity']:.3f}")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.2f}s")

    print("\n" + "=" * 70)
    print("FINAL SUMMARY (v4 -> v5 -> v6)")
    print("=" * 70)
    print(f"  Rotation invariance: v4=92.6% -> v6={results['rotation']['rotation_invariant']:.1%} (12 angles)")
    print(f"  Cross-modal: v4=16.7% -> v5=16.7% -> v6={results['cross_modal']['mapped_accuracy']:.1%}")
    print(f"  Full chain: v4=FAIL -> v5=FAIL -> v6={'PASS' if results['full_chain']['correct'] else 'FAIL'}")
    print(f"  Template library: {results['templates']['library_size']} templates, match={'PASS' if results['templates']['correct'] else 'FAIL'}")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_v6_results.json")
    with open(out, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved: {out}")
    print("\n✅ PGD v6 complete.")
