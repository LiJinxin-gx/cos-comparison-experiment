"""
PGD v9: Two-stage discrimination for confusable digit pairs.

Insight: Digits like 2/3, 3/5, 0/4 are structurally similar - even humans confuse
them. Humans resolve via contextual attention: focus on discriminative features.
This is exactly how CAPTCHAs work.

Architecture (continuous mapping layer isolation):
- Layer 1 (low abstraction): general matching over all contrast points -> top candidates
- Layer 2 (high abstraction): confusable pair detection -> if top1/top2 are a
  known confusable pair and scores are close, activate discriminative point extractor
- Layer 2 drives Layer 1: discriminative points are learned via feedback from
  past confusions, focusing on features that separate the pair

No arbitrary weighting: discriminative points are data-driven via feedback.
A point is "discriminative" for pair (A,B) if it appears frequently in A but
not B, or vice versa (mutual information with the pair label).
"""
import os, time, math, json, random
from collections import defaultdict, Counter
from cos_comparison.core import cos, local_variance, mean_local

random.seed(42)

# ============================================================
# Utilities
# ============================================================
def rotate_2d(matrix, angle_deg):
    h, w = len(matrix), len(matrix[0])
    angle = math.radians(angle_deg)
    ca, sa = math.cos(angle), math.sin(angle)
    result = [[0.0]*w for _ in range(h)]
    cx, cy = w/2, h/2
    for i in range(h):
        for j in range(w):
            x, y = j-cx, i-cy
            sx = x*ca + y*sa + cx
            sy = -x*sa + y*ca + cy
            si, sj = int(round(sy)), int(round(sx))
            if 0 <= si < h and 0 <= sj < w:
                result[i][j] = matrix[si][sj]
    return result

def symmetric_kernel_variance(matrix, radius=1):
    h, w = len(matrix), len(matrix[0])
    result = [[0.0]*w for _ in range(h)]
    for i in range(h):
        for j in range(w):
            vals = []
            for di in range(-radius, radius+1):
                for dj in range(-radius, radius+1):
                    if di*di+dj*dj <= radius*radius:
                        ni, nj = i+di, j+dj
                        if 0 <= ni < h and 0 <= nj < w:
                            vals.append(matrix[ni][nj])
            if vals:
                m = sum(vals)/len(vals)
                result[i][j] = sum((v-m)**2 for v in vals)/len(vals)
    return result

# ============================================================
# General contrast extractor (Layer 1)
# ============================================================
class GeneralExtractor:
    def __init__(self, percentile=80, min_points=4, max_points=14):
        self.percentile = percentile
        self.min_points = min_points
        self.max_points = max_points

    def extract(self, matrix):
        h, w = len(matrix), len(matrix[0])
        sk = symmetric_kernel_variance(matrix, 1)
        scored = [(sk[i][j], i, j) for i in range(h) for j in range(w)]
        scored.sort(reverse=True)
        n = max(self.min_points, min(self.max_points,
            int(len(scored) * (100 - self.percentile) / 100)))
        return [(i, j) for _, i, j in scored[:n]]

# ============================================================
# Discriminative point extractor for confusable pairs (Layer 2)
# ============================================================
class PairDiscriminator:
    """Learns discriminative points for a confusable pair via feedback.

    For pair (A, B), a point is discriminative if:
    - It appears frequently in correct matches of A but not B, and vice versa
    - Measured by: point_frequency_A - point_frequency_B (normalized)

    This is data-driven mutual information: which positions separate A from B?
    No arbitrary weighting - points are ranked by their discriminative score.
    """
    def __init__(self, pair):
        self.pair = pair  # (label_a, label_b)
        self.point_count_a = defaultdict(int)
        self.point_count_b = defaultdict(int)
        self.total_a = 0
        self.total_b = 0
        self.trained = False

    def record(self, points, label):
        """Record point appearance for a given label in the pair."""
        if label == self.pair[0]:
            for p in points: self.point_count_a[p] += 1
            self.total_a += 1
        elif label == self.pair[1]:
            for p in points: self.point_count_b[p] += 1
            self.total_b += 1
        self.trained = True

    def discriminative_score(self, point):
        """How well does this point separate the pair?

        Score = |freq_A - freq_B|, where freq = count/total.
        High score = appears in one digit but not the other = discriminative.
        """
        fa = self.point_count_a.get(point, 0) / max(self.total_a, 1)
        fb = self.point_count_b.get(point, 0) / max(self.total_b, 1)
        return abs(fa - fb)

    def get_discriminative_points(self, matrix, top_n=6):
        """Extract top discriminative points from matrix for this pair.

        Ranks general contrast points by their discriminative score for this pair.
        Points that separate A from B are prioritized.
        """
        if not self.trained or self.total_a < 5 or self.total_b < 5:
            return None  # insufficient training data
        extractor = GeneralExtractor(percentile=70)  # more candidates for discrimination
        candidates = extractor.extract(matrix)
        scored = [(self.discriminative_score(p), p) for p in candidates]
        scored.sort(reverse=True)
        return [p for _, p in scored[:top_n]]

    def discriminate(self, matrix, template_a, template_b):
        """Use discriminative points to decide between A and B.

        Method: extract discriminative points from input, compute match score
        against A and B using ONLY those points. The one with higher overlap wins.

        Mathematical meaning: points that separate A from B are the voting features.
        Pure count of aligned points, no weighting.
        """
        disc_points = self.get_discriminative_points(matrix)
        if disc_points is None or len(disc_points) < 2:
            return None  # can't discriminate, fall back to general matching
        h, w = len(matrix), len(matrix[0])
        # For each template, find best alignment of discriminative points
        best_a = self._best_point_overlap(matrix, template_a, disc_points)
        best_b = self._best_point_overlap(matrix, template_b, disc_points)
        if best_a > best_b:
            return self.pair[0], best_a, best_b
        elif best_b > best_a:
            return self.pair[1], best_a, best_b
        else:
            return None  # tie, fall back

    def _best_point_overlap(self, matrix, template, points, max_shift=2):
        """Find best shift alignment and count how many discriminative points match."""
        best = 0
        for angle in [0, 45, 90, 135, 180, 225, 270]:
            rotated = rotate_2d(template, angle)
            for dx in range(-max_shift, max_shift+1):
                for dy in range(-max_shift, max_shift+1):
                    overlap = 0
                    for (pi, pj) in points:
                        ti, tj = pi - dx, pj - dy
                        if 0 <= ti < 8 and 0 <= tj < 8:
                            # Point matches if template has high value at that position
                            if rotated[ti][tj] > 0.3 and matrix[pi][pj] > 0.3:
                                overlap += 1
                            elif rotated[ti][tj] < 0.2 and matrix[pi][pj] < 0.2:
                                overlap += 1  # both absent is also informative
                    if overlap > best:
                        best = overlap
        return best

# ============================================================
# Confusable pair registry
# ============================================================
CONFUSABLE_PAIRS = [
    (2, 3),  # 2 bottom curve resembles 3
    (3, 5),  # 5's upper curve resembles 3
    (0, 4),  # 0's ring vs 4's frame
    (1, 4),  # 1's vertical vs 4's vertical
]

class PairRegistry:
    def __init__(self):
        self.discriminators = {}
        for pair in CONFUSABLE_PAIRS:
            self.discriminators[pair] = PairDiscriminator(pair)
            self.discriminators[(pair[1], pair[0])] = self.discriminators[pair]

    def get(self, a, b):
        return self.discriminators.get((a, b))

    def is_confusable(self, a, b):
        return (a, b) in self.discriminators

    def record_feedback(self, points, label):
        """Record point appearance for all pairs involving this label."""
        for pair in CONFUSABLE_PAIRS:
            if label in pair:
                self.discriminators[pair].record(points, label)

# ============================================================
# Matching (v8.3 proven)
# ============================================================
ANGLES = (0, 30, 45, 60, 90, 120, 135, 180, 225, 270)

def match_templates(img1, templates, max_shift=2):
    h, w = len(img1), len(img1[0])
    sk1 = symmetric_kernel_variance(img1, 1)
    sk1_flat = [x for r in sk1 for x in r]
    best = (-1, 0, (0,0), 0)
    for tpl_idx, tpl in enumerate(templates):
        for angle in ANGLES:
            rotated = rotate_2d(tpl, angle)
            sk2 = symmetric_kernel_variance(rotated, 1)
            try: sk_sim = cos(sk1_flat, [x for r in sk2 for x in r])
            except: sk_sim = 0.0
            for dx in range(-max_shift, max_shift+1):
                for dy in range(-max_shift, max_shift+1):
                    a_vals, b_vals = [], []
                    for i in range(h):
                        for j in range(w):
                            bi, bj = i-dx, j-dy
                            if 0 <= bi < h and 0 <= bj < w:
                                a_vals.append(img1[i][j])
                                b_vals.append(rotated[bi][bj])
                    if len(a_vals) < h*w*0.5: continue
                    try: pix = cos(a_vals, b_vals)
                    except: pix = 0.0
                    score = 0.75 * pix + 0.25 * sk_sim
                    if score > best[0]:
                        best = (score, angle, (dx,dy), tpl_idx)
    return best

# ============================================================
# Recognizer with two-stage discrimination
# ============================================================
class RecognizerV9:
    def __init__(self):
        self.general_extractor = GeneralExtractor(percentile=80)
        self.templates = {}
        self.registry = PairRegistry()
        self.tiebreaker_gap = 0.05
        self.discriminator_gap = 0.08  # if top1-top2 < this and confusable, activate L2

    def train(self, label, clean_matrix):
        variants = [clean_matrix]
        noisy = [row[:] for row in clean_matrix]
        for i in range(8):
            for j in range(8):
                noisy[i][j] = max(0, min(1, noisy[i][j] + random.gauss(0, 0.1)))
        variants.append(noisy)
        self.templates[label] = variants

    def validate(self, matrix, return_details=False):
        # Layer 1: general matching
        results = []
        for label, variants in self.templates.items():
            score, angle, shift, tpl_idx = match_templates(matrix, variants)
            results.append((label, score, angle, shift, tpl_idx))
        results.sort(key=lambda x: x[1], reverse=True)

        # Layer 2: confusable pair discrimination
        final_label = results[0][0]
        used_discriminator = False
        if len(results) >= 2:
            top1_label, top1_score = results[0][0], results[0][1]
            top2_label, top2_score = results[1][0], results[1][1]
            gap = top1_score - top2_score
            if gap < self.discriminator_gap and self.registry.is_confusable(top1_label, top2_label):
                disc = self.registry.get(top1_label, top2_label)
                tpl_a = self.templates[top1_label][0]  # clean template
                tpl_b = self.templates[top2_label][0]
                decision = disc.discriminate(matrix, tpl_a, tpl_b)
                if decision is not None:
                    final_label = decision[0]
                    used_discriminator = True
                    # Reorder results so final_label is first
                    results.sort(key=lambda x: 0 if x[0] == final_label else 1)

        if return_details:
            return results, used_discriminator
        return final_label, results[0][1]

    def feedback(self, matrix, predicted, correct):
        """Record general points for pair discriminator training."""
        points = self.general_extractor.extract(matrix)
        self.registry.record_feedback(points, correct)

# ============================================================
# Digit generator
# ============================================================
def make_digit(d, noise=0.15, shift=(0,0), rotation=0):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r+shift[0], c+shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    if rotation != 0: grid = rotate_2d(grid, rotation)
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

# ============================================================
# TASKS
# ============================================================
def task_difficulty(use_discriminator=True):
    rec = RecognizerV9()
    for d in range(6): rec.train(d, make_digit(d, 0))
    # Pre-train discriminators with 200 feedback rounds
    for _ in range(200):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            rec.feedback(test, pred, true_d)

    conditions = [
        ('clean', 0.0, 0, (0,0)),
        ('noise=0.2', 0.2, 0, (0,0)),
        ('rot=random', 0.1, 'random', (0,0)),
        ('shift=±1', 0.1, 0, 'random'),
        ('rot=45+shift', 0.1, 45, 'random'),
        ('rot=random+shift', 0.1, 'random', 'random'),
        ('hard: rot+shift+noise0.15', 0.15, 'random', 'random'),
    ]
    results = {}
    disc_activations = 0
    disc_correct = 0
    disc_total = 0
    for name, noise, rot, shift in conditions:
        correct = total = 0
        for true_d in range(6):
            for _ in range(5):
                r = random.choice([0,30,45,60,90,120,135,180,225,270]) if rot=='random' else rot
                s = (random.randint(-1,1), random.randint(-1,1)) if shift=='random' else shift
                test = make_digit(true_d, noise=noise, rotation=r, shift=s)
                details, used_disc = rec.validate(test, return_details=True)
                pred = details[0][0]
                if used_disc:
                    disc_activations += 1
                    disc_total += 1
                    if pred == true_d: disc_correct += 1
                if pred == true_d: correct += 1
                total += 1
        results[name] = correct/total
        print(f"  {name:35s}: {correct/total:.1%} ({correct}/{total})")
    results['_disc_activations'] = disc_activations
    results['_disc_accuracy'] = disc_correct / max(disc_total, 1)
    print(f"\n  Discriminator activated: {disc_activations} times, accuracy: {disc_correct}/{disc_total} = {disc_correct/max(disc_total,1):.1%}")
    return results

def task_confusion_analysis():
    """Analyze which confusions the discriminator fixes."""
    rec = RecognizerV9()
    for d in range(6): rec.train(d, make_digit(d, 0))
    for _ in range(200):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            rec.feedback(test, pred, true_d)

    # Without discriminator
    conf_no_disc = defaultdict(lambda: defaultdict(int))
    for true_d in range(6):
        for _ in range(20):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            # Temporarily disable discriminator
            rec.discriminator_gap = -1  # never activate
            pred, _ = rec.validate(test)
            conf_no_disc[true_d][pred] += 1
    rec.discriminator_gap = 0.08  # restore

    # With discriminator
    conf_with_disc = defaultdict(lambda: defaultdict(int))
    for true_d in range(6):
        for _ in range(20):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            conf_with_disc[true_d][pred] += 1

    print("  Without L2 discriminator:")
    print("  true\\pred  " + "  ".join(f"{d}" for d in range(6)))
    for true_d in range(6):
        row = "  ".join(f"{conf_no_disc[true_d][d]:3d}" for d in range(6))
        c = conf_no_disc[true_d][true_d]
        print(f"  {true_d}         {row}   ({c}/20)")
    no_total = sum(conf_no_disc[d][d] for d in range(6))

    print("\n  With L2 discriminator:")
    print("  true\\pred  " + "  ".join(f"{d}" for d in range(6)))
    for true_d in range(6):
        row = "  ".join(f"{conf_with_disc[true_d][d]:3d}" for d in range(6))
        c = conf_with_disc[true_d][true_d]
        print(f"  {true_d}         {row}   ({c}/20)")
    with_total = sum(conf_with_disc[d][d] for d in range(6))

    # Specific confusion pairs
    print(f"\n  Overall: no_disc={no_total}/120={no_total/120:.1%}, with_disc={with_total}/120={with_total/120:.1%}")
    for a, b in CONFUSABLE_PAIRS:
        err_no = conf_no_disc[a][b] + conf_no_disc[b][a]
        err_with = conf_with_disc[a][b] + conf_with_disc[b][a]
        print(f"  Pair ({a},{b}): errors {err_no} -> {err_with}")
    return {'no_disc': no_total/120, 'with_disc': with_total/120}

def task_generation():
    rec = RecognizerV9()
    for d in range(6): rec.train(d, make_digit(d, 0))
    for _ in range(100):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            rec.feedback(test, pred, true_d)
    sims = []
    for true_d in range(6):
        for angle in [0, 45, 90, 180]:
            test = make_digit(true_d, noise=0.1, rotation=angle, shift=(1,-1))
            details, _ = rec.validate(test, return_details=True)
            pred = details[0][0]
            score = details[0][1]
            best_angle = details[0][2]
            dx, dy = details[0][3]
            tpl_idx = details[0][4]
            tpl = rec.templates[pred][tpl_idx]
            aligned = rotate_2d(tpl, best_angle)
            h, w = 8, 8
            gen = [[0.0]*w for _ in range(h)]
            for i in range(h):
                for j in range(w):
                    bi, bj = i-dx, j-dy
                    if 0 <= bi < h and 0 <= bj < w: gen[i][j] = aligned[bi][bj]
            pts = rec.general_extractor.extract(test)
            for (ci,cj) in pts[:5]:
                if 0<=ci<h and 0<=cj<w and test[ci][cj]>0.3: gen[ci][cj] = test[ci][cj]
            sims.append(cos([x for r in gen for x in r], [x for r in test for x in r]))
    return {'mean': sum(sims)/len(sims), 'min': min(sims), 'max': max(sims)}

# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':
    print("=" * 70)
    print("PGD v9: Two-Stage Discrimination for Confusable Digit Pairs")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Difficulty Curve (with L2 discriminator, 200 feedback rounds)")
    r = task_difficulty(use_discriminator=True)
    results['difficulty'] = r

    print("\n[2] Confusion Analysis (no L2 vs with L2)")
    r = task_confusion_analysis()
    results['confusion'] = r

    print("\n[3] Generation")
    r = task_generation()
    results['generation'] = r
    print(f"  Mean: {r['mean']:.3f}, range: [{r['min']:.3f}, {r['max']:.3f}]")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.1f}s")

    print("\n" + "=" * 70)
    print("v8.3 -> v9 COMPARISON")
    print("=" * 70)
    hard = 'hard: rot+shift+noise0.15'
    print(f"  Hard condition: v8.3=86.7% -> v9={results['difficulty'].get(hard, 0):.1%}")
    print(f"  No L2: {results['confusion']['no_disc']:.1%}, With L2: {results['confusion']['with_disc']:.1%}")
    print(f"  L2 improvement: {(results['confusion']['with_disc']-results['confusion']['no_disc'])*100:+.1f}pp")
    print(f"  Generation: v8.3=0.960 -> v9={results['generation']['mean']:.3f}")
    print(f"  Discriminator activations: {results['difficulty'].get('_disc_activations', 0)}")
    print(f"  Discriminator accuracy: {results['difficulty'].get('_disc_accuracy', 0):.1%}")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_v9_results.json")
    with open(out, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved: {out}")
    print("\n✅ PGD v9 complete.")
