"""
cos-comparison v0.4.4 - Retrospective Comparative Analysis
Integrate all 7 rounds of experiments, cross-compare methods,
analyze evolution path and task adaptation.
"""
import os
import json
import math

print("=" * 70)
print("Retrospective Comparative Analysis - 7 Rounds Integrated")
print("=" * 70)

# ============================================================
# All experiment results consolidated
# ============================================================

# Round 1: Diverse experiments (baseline capabilities)
round1 = {
    'hierarchical': {'raw_l1': 0.976, 'raw_l2': 0.0, 'note': 'layer orthogonality'},
    'anomaly': {'f1': 0.467, 'precision': 0.368, 'recall': 0.636},
    'joint_extraction': {'passive_shape': '13x14', 'active_shape': '12x12'},
    'compression': {'cos': 0.0, 'note': 'threshold_map API issue'},
    'tensor_ops': {'mean': 49.5, 'var': 833.25},
    'multi_backend': {'pydll_ms': 0.322, 'python_ms': 0.399},
    'signal_chain': {'steps': 3, 'time_s': 0.0001},
}

# Round 2: Deep breakthrough (boundary pushing)
round2 = {
    'self_reference': {'3layer_retention': 0.814, 'decay_per_layer': 0.025},
    'extreme_dims': {'5d': True, '6d': True, '6d_time_s': 0.0011},
    'fractal': {'3x3_sim': 0.684, '7x7_sim': 0.583},
    'noise_robustness': {'80pct_noise_sim': 0.659},
    'large_scale': {'5000_time_s': 0.0005},
    'edge_cases': {'all_pass': True},
    'multi_scale': {'windows': [3,5,7,9]},
}

# Round 3: Principle-driven (core principle verification)
round3 = {
    'layer_isolation': {'10layer_raw': 0.541, '10layer_task': 0.989, 'key': 'task info preserved'},
    'contrast_info': {'efficiency': 2.25, 'capture': 1.16},
    'hierarchical_driving': {'coverage': 0.079, 'retention': 0.876},
    'dual_mode': {'passive_hf_share': 0.947, 'note': 'active scale issue'},
    'on_demand': {'retention': 1.0},
    'behavior_as_data': {'determinism': 1.0},
}

# Round 4: Multi-task validation (concrete tasks)
round4 = {
    'digit': {'accuracy': 1.0},
    'anomaly': {'f1': 0.0, 'note': 'cos threshold failed'},
    'text': {'accuracy': 1.0},
    'compression': {'psnr_db': 8.83, 'note': 'API misuse'},
    'audio': {'accuracy': 0.65},
    'dna': {'accuracy': 0.614, 'separation': 0.0004},
    'recommendation': {'precision': 0.814},
    'sensor': {'f1': 0.217, 'precision': 0.123},
}

# Round 5: Universal enhancements (targeted fixes)
round5 = {
    'anomaly': {'f1_before': 0.0, 'f1_after': 0.907, 'method': 'variance+difference'},
    'audio': {'acc_before': 0.65, 'acc_after': 0.65, 'method': 'multiscale (ineffective)'},
    'dna': {'acc_before': 0.614, 'acc_after': 0.95, 'method': 'active template'},
    'sensor': {'f1_before': 0.217, 'f1_after': 0.667, 'method': 'cross-channel'},
    'compression': {'psnr_before': 8.83, 'psnr_after': 35.8, 'method': 'fixed quantization'},
}

# Round 6: Principle enhancement (direction/strength/synthesis)
round6 = {
    'direction': {'diversity': 590, 'anti_diag_var': 0.005642},
    'strength': {'contrast_improvement': 1.0, 'note': 'cos scale-invariant, b-offset effective'},
    'synthesis': {'algo_diversity': 29.36, 'active_max': 0.945},
    'integrated': {'std_acc': 0.361, 'enh_acc': 1.0, 'gain': 0.639},
}

# Round 7: Generality test (8 domains, std vs enhanced)
round7 = {
    'digit': {'std': 0.22, 'enh': 1.0, 'gain': 0.78, 'method': 'direction'},
    'anomaly': {'std_f1': 0.0, 'enh_f1': 1.0, 'gain': 1.0, 'method': 'strength'},
    'text': {'std': 0.90, 'enh': 0.90, 'gain': 0.0, 'method': 'direction (no benefit)'},
    'audio': {'std': 0.711, 'enh': 0.822, 'gain': 0.111, 'method': 'synthesis(multiscale)'},
    'recommendation': {'std': 0.72, 'enh': 0.693, 'gain': -0.027, 'method': 'ensemble (hurt)'},
    'sensor': {'std_f1': 0.326, 'enh_f1': 0.857, 'gain': 0.531, 'method': 'synthesis(cross-channel)'},
    'compression': {'std_db': 29.25, 'enh_db': 26.28, 'gain': -2.97, 'method': 'adaptive (hurt)'},
    'dna': {'std': 0.80, 'enh': 0.533, 'gain': -0.267, 'method': 'fusion (hurt, no norm)'},
}

# ============================================================
# Analysis 1: Method Evolution Path
# ============================================================
print("\n" + "=" * 70)
print("Analysis 1: Method Evolution Path")
print("=" * 70)

print("""
Round 1 (Capabilities): Discovered what the model CAN do
  - Hierarchical extraction, anomaly detection, dual-mode, tensor ops
  - Key finding: threshold_map API needs careful usage

Round 2 (Boundaries): Pushed limits
  - 5D/6D data, fractal patterns, 80% noise, 5000 elements
  - Key finding: model handles extreme dimensions and noise gracefully

Round 3 (Principles): Verified core design principles
  - Layer isolation: 10 layers → 54% raw, 99% task (MOST IMPORTANT)
  - Contrast points: 2.25x efficiency
  - Behavior-as-data: perfect determinism

Round 4 (Concrete Tasks): Applied to real tasks
  - 3 tasks at 100%, 3 tasks failing (anomaly, compression, sensor)
  - Key finding: method selection matters more than algorithm power

Round 5 (Targeted Fixes): Fixed failures from Round 4
  - Anomaly: 0 → 90.7% F1 (variance+difference)
  - DNA: 61.4% → 95% (active template)
  - Sensor: 21.7% → 66.7% F1 (cross-channel)
  - Key finding: match feature type to task type

Round 6 (Principle Enhancement): 3-dimensional enhancement
  - Direction: 590x diversity, shift search
  - Strength: adaptive amplification, b-offset
  - Synthesis: 4-algorithm fusion, dual-mode
  - Integrated: 36.1% → 100% on digit recognition

Round 7 (Generality): Tested across 8 domains
  - 4/8 improved, 1/8 unchanged, 3/8 degraded
  - Key finding: enhancements must match task structure
""")

# ============================================================
# Analysis 2: Enhancement Effectiveness by Dimension
# ============================================================
print("\n" + "=" * 70)
print("Analysis 2: Enhancement Effectiveness by Dimension")
print("=" * 70)

# Direction enhancement results
direction_tasks = [
    ('digit (R7)', 0.22, 1.0, 0.78),
    ('digit (R6 integrated)', 0.361, 1.0, 0.639),
    ('text (R7)', 0.90, 0.90, 0.0),
]
print("\nDirection Enhancement (shift/search):")
print(f"  {'Task':<25} {'Before':>8} {'After':>8} {'Gain':>8}")
print("  " + "-" * 51)
for name, before, after, gain in direction_tasks:
    print(f"  {name:<25} {before:>7.1%} {after:>7.1%} {gain:>+7.1%}")
print(f"  Average gain: +{(0.78+0.639+0)/3*100:.1f}pp")
print("  Verdict: HIGHLY effective for spatial tasks, useless for position-invariant")

# Strength enhancement results
strength_tasks = [
    ('anomaly (R5)', 0.0, 0.907, 0.907),
    ('anomaly (R7)', 0.0, 1.0, 1.0),
    ('compression (R7)', 29.25, 26.28, -2.97),
]
print("\nStrength Enhancement (variance/adaptive):")
print(f"  {'Task':<25} {'Before':>8} {'After':>8} {'Gain':>8}")
print("  " + "-" * 51)
for name, before, after, gain in strength_tasks:
    if 'dB' in name or 'compression' in name:
        print(f"  {name:<25} {before:>7.2f}dB {after:>7.2f}dB {gain:>+7.2f}dB")
    else:
        print(f"  {name:<25} {before:>7.3f} {after:>7.3f} {gain:>+7.3f}")
print("  Verdict: Effective for anomaly/detection, harmful for uniform data")

# Synthesis enhancement results
synthesis_tasks = [
    ('audio (R7)', 0.711, 0.822, 0.111),
    ('sensor (R7)', 0.326, 0.857, 0.531),
    ('dna (R7)', 0.80, 0.533, -0.267),
    ('recommendation (R7)', 0.72, 0.693, -0.027),
]
print("\nSynthesis Enhancement (fusion/ensemble):")
print(f"  {'Task':<25} {'Before':>8} {'After':>8} {'Gain':>8}")
print("  " + "-" * 51)
for name, before, after, gain in synthesis_tasks:
    print(f"  {name:<25} {before:>7.1%} {after:>7.1%} {gain:>+7.1%}")
print(f"  Average gain: {(0.111+0.531-0.267-0.027)/4*100:+.1f}pp")
print("  Verdict: Effective for multi-channel/frequency, requires normalization")

# ============================================================
# Analysis 3: Task Type Adaptation Matrix
# ============================================================
print("\n" + "=" * 70)
print("Analysis 3: Task Type Adaptation Matrix")
print("=" * 70)

print("""
Task Category          | Direction | Strength  | Synthesis | Best Method
-----------------------|-----------|-----------|-----------|------------------
Spatial pattern        |  +78pp    |    N/A    |    +0pp   | Direction shift
Time series anomaly    |    N/A    |  +1.0 F1  |    N/A    | Variance+difference
Position-invariant     |    0pp    |    N/A    |    N/A    | Standard (saturated)
Frequency/signal       |    N/A    |    N/A    |  +11pp    | Multi-scale fusion
Multi-channel          |    N/A    |    N/A    | +0.53 F1  | Cross-channel corr
Uniform data           |    N/A    |  -3dB     |    N/A    | Standard uniform
Multi-algorithm        |    N/A    |    N/A    |  -27pp    | Normalize first!
Ensemble/recommendation|    N/A    |    N/A    |  -3pp     | Single best match
""")

# ============================================================
# Analysis 4: Failure Root Cause Taxonomy
# ============================================================
print("\n" + "=" * 70)
print("Analysis 4: Failure Root Cause Taxonomy")
print("=" * 70)

failures = [
    ('Anomaly (R4)', 'cos threshold', 'Cosine insensitive to point anomalies', 'Use variance/difference', 'Fixed in R5'),
    ('Compression (R4)', 'threshold_map API', 'Incorrect pair ordering', 'Direct quantization', 'Fixed in R5'),
    ('DNA (R4)', 'one-hot+mean', 'Short motif over-smoothed', 'Active template matching', 'Fixed in R5'),
    ('Sensor (R4)', 'independent threshold', 'Noise triggers false positives', 'Cross-channel coordination', 'Fixed in R5'),
    ('Audio (R5)', 'multiscale mean', 'Mean is low-pass, loses freq', 'Need variance/spectral', 'Partial in R7'),
    ('DNA (R7)', 'cos+active fusion', 'Different output scales, no normalization', 'Normalize before fusion', 'OPEN'),
    ('Compression (R7)', 'adaptive quant', 'Uniform data, no heterogeneity', 'Use uniform quantization', 'OPEN'),
    ('Recommendation (R7)', 'top-3 ensemble', 'Noise from less-similar users', 'Use single best match', 'OPEN'),
]

print(f"\n{'Failure':<20} {'Cause':<25} {'Root Reason':<35} {'Fix':<25} {'Status':<10}")
print("-" * 115)
for name, cause, root, fix, status in failures:
    print(f"{name:<20} {cause:<25} {root:<35} {fix:<25} {status:<10}")

# ============================================================
# Analysis 5: Key Insights Ranking
# ============================================================
print("\n" + "=" * 70)
print("Analysis 5: Key Insights Ranked by Impact")
print("=" * 70)

insights = [
    (1, 'Layer isolation preserves task-relevant info', '10 layers: 54% raw, 99% task performance. This is the core architectural advantage.'),
    (2, 'Direction alignment is critical for spatial tasks', 'Shift search improves digit recognition 22%→100%. Single biggest gain.'),
    (3, 'Feature type must match task type', 'Anomaly needs variance/difference, not similarity. Pattern matching needs cosine.'),
    (4, 'Contrast points carry disproportionate information', '51.6% of points capture 116% of variance. 2.25x efficiency.'),
    (5, 'Multi-algorithm fusion requires normalization', 'cos and active have different scales. Unnormalized fusion: -27pp.'),
    (6, 'Adaptive methods need data heterogeneity', 'Uniform data: adaptive quantization -3dB. Uniform methods better.'),
    (7, 'Ensemble can hurt when base is reliable', 'Recommendation: top-3 ensemble -2.7pp. Single match better.'),
    (8, '4 algorithms share accumulators → zero-cost fusion', 'Compute a,b,ab once, apply 4 formulas. 29x diversity.'),
    (9, 'Cosine is scale-invariant, offset-sensitive', 'w parameter no effect, b parameter significant. Counterintuitive.'),
    (10, 'Model handles 6D data and 80% noise', 'Extreme robustness. 6D in 0.001s, 80% noise retains 66% similarity.'),
]

for rank, title, detail in insights:
    print(f"\n  #{rank}: {title}")
    print(f"      {detail}")

# ============================================================
# Analysis 6: Performance Evolution
# ============================================================
print("\n" + "=" * 70)
print("Analysis 6: Performance Evolution Across Rounds")
print("=" * 70)

print("""
Metric                    R1(Init)  R4(Tasks)  R5(Fixed)  R7(General)
------------------------- --------- ---------- ---------- -----------
Digit Recognition         N/A       100%       100%       22%→100%
Anomaly Detection F1      0.467     0.0        0.907      0.0→1.0
Text Classification       N/A       100%       100%       90%→90%
Audio Recognition         N/A       65%        65%        71%→82%
DNA Motif Detection       N/A       61.4%      95%        80%→53%*
Sensor Event F1           N/A       0.217      0.667      0.326→0.857
Recommendation Precision  N/A       81.4%      N/A        72%→69%*
Compression PSNR          N/A       8.83dB     35.8dB     29→26dB*

* = enhanced method hurt performance (see failure taxonomy)
""")

# ============================================================
# Summary
# ============================================================
print("\n" + "=" * 70)
print("RETROSPECTIVE SUMMARY")
print("=" * 70)

print("""
7 rounds, 40+ experiments, 8 task domains.

MOST IMPORTANT FINDING:
  Layer isolation (continuous mapping) preserves task-relevant information
  while filtering noise. At 10 abstraction layers: 54% raw data retained,
  but 99% task performance retained. This validates the core architecture.

BIGGEST IMPROVEMENT:
  Direction (shift search) for spatial tasks: 22% → 100% (+78pp)

BIGGEST LESSON:
  No single enhancement works everywhere. Match method to task:
  - Spatial misalignment → Direction
  - Anomaly/detection → Strength (variance)
  - Multi-channel/frequency → Synthesis (fusion)
  - Position-invariant → Standard
  - Always normalize before multi-algorithm fusion

OPEN ISSUES:
  1. Multi-algorithm fusion normalization (DNA task: -27pp)
  2. Audio frequency features (mean loses frequency info)
  3. Adaptive method calibration for uniform data
""")

output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "retrospective_analysis.json")
with open(output_path, 'w') as f:
    json.dump({
        'rounds': 7,
        'key_insight': 'layer isolation preserves task info (54% raw, 99% task at 10 layers)',
        'biggest_gain': 'direction shift: +78pp on digit recognition',
        'open_issues': ['fusion normalization', 'audio spectral features', 'adaptive calibration'],
        'round1': round1, 'round2': round2, 'round3': round3,
        'round4': round4, 'round5': round5, 'round6': round6, 'round7': round7,
    }, f, indent=2, default=str)
print(f"Results saved: {output_path}")
print("\n✅ Retrospective analysis complete!")
