"""
PGD v8.2: Fix v8.1 regression - keep v7.1's 10-angle search, add targeted improvements.

v8.1 failed because storing only 3 rotated variants (0,90,180) lost 45/60/120 etc.
v7.1's 10-angle search is proven. Keep it, add:
1. More contrast points (percentile=75 -> top 25%) to capture 0/4 and 2/3 structural differences
2. Multi-noise templates: store 3 variants per digit (noise=0, 0.1, 0.2) for robustness
3. Optimized tiebreaker: contrast overlap when gap < 0.05
4. Simple feedback (v7.1 version, discriminative feedback caused regression)
"""
import os, time, math, json, random
from collections import defaultdict, Counter
from cos_comparison.core import cos, local_variance, mean_local

random.seed(42)

# ============================================================
# Utilities
# ============================================================
def rotate_2d(matrix, angle_deg):
    h, w = len(matrix), len(matrix[0])
    angle = math.radians(angle_deg)
    ca, sa = math.cos(angle), math.sin(angle)
    result = [[0.0]*w for _ in range(h)]
    cx, cy = w/2, h/2
    for i in range(h):
        for j in range(w):
            x, y = j-cx, i-cy
            sx = x*ca + y*sa + cx
            sy = -x*sa + y*ca + cy
            si, sj = int(round(sy)), int(round(sx))
            if 0 <= si < h and 0 <= sj < w:
                result[i][j] = matrix[si][sj]
    return result

def symmetric_kernel_variance(matrix, radius=1):
    h, w = len(matrix), len(matrix[0])
    result = [[0.0]*w for _ in range(h)]
    for i in range(h):
        for j in range(w):
            vals = []
            for di in range(-radius, radius+1):
                for dj in range(-radius, radius+1):
                    if di*di+dj*dj <= radius*radius:
                        ni, nj = i+di, j+dj
                        if 0 <= ni < h and 0 <= nj < w:
                            vals.append(matrix[ni][nj])
            if vals:
                m = sum(vals)/len(vals)
                result[i][j] = sum((v-m)**2 for v in vals)/len(vals)
    return result

# ============================================================
# Contrast extractor (simple feedback, v7.1 proven)
# ============================================================
class ContrastExtractor:
    def __init__(self, percentile=75, min_points=5, max_points=16):
        self.percentile = percentile  # top 25% by variance (more points for structure)
        self.min_points = min_points
        self.max_points = max_points
        self.point_contribution = defaultdict(float)
        self.match_count = 0
        self.max_abs = 1.0

    def extract(self, matrix):
        h, w = len(matrix), len(matrix[0])
        sk = symmetric_kernel_variance(matrix, 1)
        scored = [(sk[i][j], i, j) for i in range(h) for j in range(w)]
        scored.sort(reverse=True)
        n = max(self.min_points, min(self.max_points,
            int(len(scored) * (100 - self.percentile) / 100)))
        return [(i, j) for _, i, j in scored[:n]]

    def record_feedback(self, points, score, is_correct):
        self.match_count += 1
        c = score if is_correct else -score
        for p in points:
            self.point_contribution[p] += c
            if abs(self.point_contribution[p]) > self.max_abs:
                self.max_abs = abs(self.point_contribution[p])

    def get_refined(self, matrix):
        if self.match_count < 15:
            return self.extract(matrix)
        h, w = len(matrix), len(matrix[0])
        sk = symmetric_kernel_variance(matrix, 1)
        cands = self.extract(matrix)
        scored = []
        for (i, j) in cands:
            v = sk[i][j]
            contrib = self.point_contribution.get((i,j), 0) / self.max_abs
            factor = 1.0 + contrib * 0.5
            scored.append((v * factor, i, j))
        scored.sort(reverse=True)
        return [(i, j) for _, i, j in scored[:len(cands)]]

# ============================================================
# Contrast overlap at shift
# ============================================================
def contrast_overlap(pts_a, pts_b, dx, dy, tol=1):
    set_b = set(pts_b)
    overlap = 0
    for (ai, aj) in pts_a:
        si, sj = ai + dx, aj + dy
        found = False
        for di in range(-tol, tol+1):
            for dj in range(-tol, tol+1):
                if (si+di, sj+dj) in set_b:
                    overlap += 1
                    found = True
                    break
            if found: break
    denom = min(len(pts_a), len(pts_b))
    return overlap / denom if denom > 0 else 0.0

# ============================================================
# Matching: 10 angles + shift, against multi-noise templates
# ============================================================
ANGLES = (0, 30, 45, 60, 90, 120, 135, 180, 225, 270)

def match_against_templates(img1, templates, extractor, use_refined=False, max_shift=2):
    """Match against list of template variants, take max score across all.

    templates: list of raw matrices (different noise levels, same digit).
    For each template, try 10 rotations x 25 shifts.
    Returns (best_score, best_angle, best_shift, best_cov, best_template_idx).
    """
    h, w = len(img1), len(img1[0])
    sk1 = symmetric_kernel_variance(img1, 1)
    sk1_flat = [x for r in sk1 for x in r]
    pts1 = extractor.get_refined(img1) if use_refined else extractor.extract(img1)

    best = (-1, 0, (0,0), 0.0, 0)
    for tpl_idx, tpl in enumerate(templates):
        for angle in ANGLES:
            rotated = rotate_2d(tpl, angle)
            sk2 = symmetric_kernel_variance(rotated, 1)
            try: sk_sim = cos(sk1_flat, [x for r in sk2 for x in r])
            except: sk_sim = 0.0
            pts2 = extractor.extract(rotated)
            for dx in range(-max_shift, max_shift+1):
                for dy in range(-max_shift, max_shift+1):
                    a_vals, b_vals = [], []
                    for i in range(h):
                        for j in range(w):
                            bi, bj = i-dx, j-dy
                            if 0 <= bi < h and 0 <= bj < w:
                                a_vals.append(img1[i][j])
                                b_vals.append(rotated[bi][bj])
                    if len(a_vals) < h*w*0.5: continue
                    try: pix = cos(a_vals, b_vals)
                    except: pix = 0.0
                    score = 0.75 * pix + 0.25 * sk_sim
                    if score > best[0]:
                        cov = contrast_overlap(pts1, pts2, dx, dy)
                        best = (score, angle, (dx,dy), cov, tpl_idx)
    return best

# ============================================================
# Recognizer
# ============================================================
class RecognizerV82:
    def __init__(self, n_noise_variants=3):
        self.extractor = ContrastExtractor(percentile=75)
        self.templates = {}  # label -> list of noise-variant templates
        self.n_variants = n_noise_variants
        self.tiebreaker_gap = 0.05

    def train(self, label, clean_matrix):
        """Store clean + noisy variants for robustness."""
        variants = [clean_matrix]
        for noise_level in [0.1, 0.2][:self.n_variants-1]:
            noisy = [row[:] for row in clean_matrix]
            for i in range(8):
                for j in range(8):
                    noisy[i][j] = max(0, min(1, noisy[i][j] + random.gauss(0, noise_level)))
            variants.append(noisy)
        self.templates[label] = variants

    def validate(self, matrix, return_details=False, use_refined=False):
        results = []
        for label, variants in self.templates.items():
            score, angle, shift, cov, tpl_idx = match_against_templates(
                matrix, variants, self.extractor, use_refined=use_refined)
            results.append((label, score, angle, shift, cov, tpl_idx))
        results.sort(key=lambda x: x[1], reverse=True)
        # Tiebreaker
        if len(results) >= 2 and results[0][1] - results[1][1] < self.tiebreaker_gap:
            top2 = sorted(results[:2], key=lambda x: x[4], reverse=True)
            results = top2 + results[2:]
        if return_details: return results
        return results[0][0], results[0][1]

    def feedback(self, matrix, predicted, correct):
        pts = self.extractor.extract(matrix)
        self.extractor.record_feedback(pts, 1.0, predicted == correct)

# ============================================================
# Digit generator
# ============================================================
def make_digit(d, noise=0.15, shift=(0,0), rotation=0):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r+shift[0], c+shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    if rotation != 0: grid = rotate_2d(grid, rotation)
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

# ============================================================
# TASKS
# ============================================================
def task_difficulty(use_refined=False):
    rec = RecognizerV82(n_noise_variants=3)
    for d in range(6): rec.train(d, make_digit(d, 0))
    conditions = [
        ('clean', 0.0, 0, (0,0)),
        ('noise=0.2', 0.2, 0, (0,0)),
        ('rot=random', 0.1, 'random', (0,0)),
        ('shift=±1', 0.1, 0, 'random'),
        ('rot=45+shift', 0.1, 45, 'random'),
        ('rot=random+shift', 0.1, 'random', 'random'),
        ('hard: rot+shift+noise0.15', 0.15, 'random', 'random'),
    ]
    results = {}
    for name, noise, rot, shift in conditions:
        correct = total = 0
        for true_d in range(6):
            for _ in range(5):
                r = random.choice([0,30,45,60,90,120,135,180,225,270]) if rot=='random' else rot
                s = (random.randint(-1,1), random.randint(-1,1)) if shift=='random' else shift
                test = make_digit(true_d, noise=noise, rotation=r, shift=s)
                pred, _ = rec.validate(test, use_refined=use_refined)
                if pred == true_d: correct += 1
                total += 1
        results[name] = correct/total
        print(f"  {name:35s}: {correct/total:.1%} ({correct}/{total})")
    return results

def task_feedback():
    rec = RecognizerV82(n_noise_variants=3)
    for d in range(6): rec.train(d, make_digit(d, 0))
    c1 = 0
    for true_d in range(6):
        for _ in range(5):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            if pred == true_d: c1 += 1
    for _ in range(150):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            rec.feedback(test, pred, true_d)
    c2 = 0
    for true_d in range(6):
        for _ in range(5):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec.validate(test, use_refined=True)
            if pred == true_d: c2 += 1
    return {'before': c1/30, 'after': c2/30, 'imp': (c2-c1)/30}

def task_confusion():
    rec = RecognizerV82(n_noise_variants=3)
    for d in range(6): rec.train(d, make_digit(d, 0))
    for _ in range(100):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            rec.feedback(test, pred, true_d)
    confusion = defaultdict(lambda: defaultdict(int))
    for true_d in range(6):
        for _ in range(20):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec.validate(test, use_refined=True)
            confusion[true_d][pred] += 1
    print("  true\\pred  " + "  ".join(f"{d}" for d in range(6)))
    for true_d in range(6):
        row = "  ".join(f"{confusion[true_d][d]:3d}" for d in range(6))
        c = confusion[true_d][true_d]
        print(f"  {true_d}         {row}   ({c}/20)")
    total = sum(confusion[d][d] for d in range(6))
    return {'accuracy': total/120}

def task_generation():
    rec = RecognizerV82(n_noise_variants=3)
    for d in range(6): rec.train(d, make_digit(d, 0))
    sims = []
    for true_d in range(6):
        for angle in [0, 45, 90, 180]:
            test = make_digit(true_d, noise=0.1, rotation=angle, shift=(1,-1))
            details = rec.validate(test, return_details=True)
            pred, score, best_angle, (dx,dy), cov, tpl_idx = details[0]
            tpl = rec.templates[pred][tpl_idx]
            aligned = rotate_2d(tpl, best_angle)
            h, w = 8, 8
            gen = [[0.0]*w for _ in range(h)]
            for i in range(h):
                for j in range(w):
                    bi, bj = i-dx, j-dy
                    if 0 <= bi < h and 0 <= bj < w: gen[i][j] = aligned[bi][bj]
            pts = rec.extractor.extract(test)
            for (ci,cj) in pts[:5]:
                if 0<=ci<h and 0<=cj<w and test[ci][cj]>0.3: gen[ci][cj] = test[ci][cj]
            sims.append(cos([x for r in gen for x in r], [x for r in test for x in r]))
    return {'mean': sum(sims)/len(sims), 'min': min(sims), 'max': max(sims)}

# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':
    print("=" * 70)
    print("PGD v8.2: 10-angle search + multi-noise templates + 25% contrast points")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Difficulty Curve")
    r = task_difficulty(use_refined=False)
    results['difficulty'] = r

    print("\n[2] Feedback (150 rounds)")
    r = task_feedback()
    results['feedback'] = r
    print(f"  Before: {r['before']:.1%}, After: {r['after']:.1%}, Imp: {r['imp']*100:+.1f}pp")

    print("\n[3] Confusion Matrix (with feedback, 20/digit)")
    r = task_confusion()
    results['confusion'] = r
    print(f"  Overall: {r['accuracy']:.1%}")

    print("\n[4] Generation")
    r = task_generation()
    results['generation'] = r
    print(f"  Mean: {r['mean']:.3f}, range: [{r['min']:.3f}, {r['max']:.3f}]")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.1f}s")

    print("\n" + "=" * 70)
    print("v7.1 -> v8.2 COMPARISON")
    print("=" * 70)
    hard = 'hard: rot+shift+noise0.15'
    print(f"  Hard:     v7.1=76.7% -> v8.2={results['difficulty'].get(hard,0):.1%}")
    print(f"  Rot+shift: v7.1=83.3% -> v8.2={results['difficulty'].get('rot=random+shift',0):.1%}")
    print(f"  Feedback: v7.1=+3.3pp -> v8.2={results['feedback']['imp']*100:+.1f}pp")
    print(f"  Gen:      v7.1=0.953 -> v8.2={results['generation']['mean']:.3f}")
    print(f"  Time:     v7.1=28s -> v8.2={elapsed:.0f}s")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_v8_2_results.json")
    with open(out, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved: {out}")
    print("\n✅ PGD v8.2 complete.")
