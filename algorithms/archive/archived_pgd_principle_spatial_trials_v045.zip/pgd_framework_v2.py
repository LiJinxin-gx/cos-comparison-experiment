"""
PGD Full-Chain Framework v2 - Targeted improvements from Round 1 retrospective.
Fixes:
1. PGD classification integrates shift search for 2D spatial data
2. Text classification uses raw frequency vectors (position-invariant)
3. Image reconstruction: better inverse mapping (mean + contrast detail + structure)
4. Bandit: UCB-like exploration bonus based on uncertainty
5. Generation: contrast-guided template placement (high-level guides low-level)
"""
import os
import time
import math
import json
import random
from collections import Counter

from cos_comparison.core import cos, local_variance, mean_local, cos_comparison_passive

random.seed(42)

# ============================================================
# PERCEPTION (enhanced)
# ============================================================
class Perception:
    @staticmethod
    def extract_1d(data, n_levels=3, window=5):
        features = {'raw': data[:]}
        try:
            features['variance'] = local_variance(data, local_size=(window,))
        except Exception:
            features['variance'] = []
        try:
            features['mean'] = mean_local(data, local_size=(window,))
        except Exception:
            features['mean'] = []
        try:
            features['passive'] = cos_comparison_passive(data, local_size=(window,))
        except Exception:
            features['passive'] = []
        if features['variance']:
            vmax = max(features['variance']) if features['variance'] else 1
            features['contrast_points'] = [i for i, v in enumerate(features['variance']) if v > vmax * 0.3]
        else:
            features['contrast_points'] = []
        return features

    @staticmethod
    def extract_2d(matrix, n_levels=3, window=3):
        h, w = len(matrix), len(matrix[0])
        flat = [x for row in matrix for x in row]
        features = {'raw': matrix, 'flat': flat, 'shape': (h, w)}
        row_vars = []
        for row in matrix:
            try:
                row_vars.append(local_variance(row, local_size=(window,)))
            except Exception:
                row_vars.append([])
        features['row_variance'] = row_vars
        col_vars = []
        for j in range(w):
            col = [matrix[i][j] for i in range(h)]
            try:
                col_vars.append(local_variance(col, local_size=(window,)))
            except Exception:
                col_vars.append([])
        features['col_variance'] = col_vars
        contrast = set()
        for i, rvs in enumerate(row_vars):
            if rvs:
                vmax = max(rvs)
                for j, v in enumerate(rvs):
                    if v > vmax * 0.3:
                        contrast.add((i, min(j + window // 2, w - 1)))
        for j, cvs in enumerate(col_vars):
            if cvs:
                vmax = max(cvs)
                for i, v in enumerate(cvs):
                    if v > vmax * 0.3:
                        contrast.add((min(i + window // 2, h - 1), j))
        features['contrast_points'] = sorted(contrast)
        return features

    @staticmethod
    def spatiality_1d(data):
        n = len(data)
        if n < 4:
            return 1.0
        m = sum(data) / n
        num = sum((data[i] - m) * (data[i + 1] - m) for i in range(n - 1))
        den = sum((x - m) ** 2 for x in data)
        corr = num / den if den > 1e-10 else 0.0
        return abs(corr) * 5 + 1.0


# ============================================================
# GENERATION (enhanced: contrast-guided)
# ============================================================
class Generation:
    @staticmethod
    def combine_2d(templates, selection, shape=None):
        if shape is None:
            h = max(b for _, _, _, b, _ in selection)
            w = max(r for _, _, _, _, r in selection)
            shape = (h, w)
        h, w = shape
        result = [[0.0] * w for _ in range(h)]
        for tpl_idx, top, left, bottom, right in selection:
            if tpl_idx < len(templates):
                tpl = templates[tpl_idx]
                for i in range(top, min(bottom, h)):
                    for j in range(left, min(right, w)):
                        si, sj = i - top, j - left
                        if si < len(tpl) and sj < len(tpl[0]):
                            result[i][j] = tpl[si][sj]
        return result

    @staticmethod
    def contrast_guided_generate(source_feat, templates, target_shape):
        """Place template patches at contrast point locations.
        High-level contrast map guides low-level template placement."""
        h, w = target_shape
        result = [[0.0] * w for _ in range(h)]
        contrast_pts = source_feat.get('contrast_points', [])
        if not contrast_pts or not templates:
            return result
        tpl = templates[0]
        th, tw = len(tpl), len(tpl[0])
        for (ci, cj) in contrast_pts:
            top = max(0, ci - th // 2)
            left = max(0, cj - tw // 2)
            for i in range(th):
                for j in range(tw):
                    ri, rj = top + i, left + j
                    if 0 <= ri < h and 0 <= rj < w:
                        if result[ri][rj] == 0.0:
                            result[ri][rj] = tpl[i][j]
        return result

    @staticmethod
    def reconstruct_1d(features, length):
        """Improved reconstruction: mean base + contrast detail + passive structure."""
        result = [0.0] * length
        mn = features.get('mean', [])
        var = features.get('variance', [])
        passive = features.get('passive', [])
        contrast = features.get('contrast_points', [])
        # Base: local mean
        if mn:
            for i in range(min(length, len(mn))):
                result[i] = mn[i]
        # Detail at contrast points: use variance amplitude with passive sign
        for idx in contrast:
            if idx < length:
                amp = var[idx] if idx < len(var) else 0
                sign = 1.0
                if passive and idx < len(passive):
                    sign = 1.0 if passive[idx] >= 0 else -1.0
                result[idx] += sign * amp * 0.7
        # Fill remaining from raw if available
        raw = features.get('raw', [])
        if raw:
            for i in range(min(length, len(raw))):
                if result[i] == 0.0 and raw[i] != 0:
                    result[i] = raw[i] * 0.5
        return result


# ============================================================
# DECISION (enhanced: shift-aware, UCB)
# ============================================================
def match_2d_shifted(img1, img2, shifts=(-2, -1, 0, 1, 2)):
    best = -1
    h = min(len(img1), len(img2))
    w = min(len(img1[0]) if img1 else 0, len(img2[0]) if img2 else 0)
    for dy in shifts:
        for dx in shifts:
            f1, f2 = [], []
            for i in range(h):
                for j in range(w):
                    f1.append(img1[i][j])
                    ni, nj = i + dy, j + dx
                    f2.append(img2[ni][nj] if 0 <= ni < len(img2) and 0 <= nj < len(img2[0]) else 0.0)
            s = cos(f1, f2)
            if s > best:
                best = s
    return best


class Decision:
    @staticmethod
    def classify(input_features, templates_features, threshold=0.5, shifts=(-2, -1, 0, 1, 2)):
        """Enhanced: 2D data uses shift search; 1D position-invariant uses raw."""
        scores = {}
        input_raw = input_features.get('raw', [])
        is_2d = bool(input_raw and isinstance(input_raw[0], list))
        for label, tpl_feat in templates_features.items():
            tpl_raw = tpl_feat.get('raw', [])
            if is_2d:
                # 2D spatial: use shift search
                raw_score = match_2d_shifted(input_raw, tpl_raw, shifts=shifts)
                # Variance features as secondary
                input_var = [x for row in input_features.get('row_variance', []) for x in row]
                tpl_var = [x for row in tpl_feat.get('row_variance', []) for x in row]
                if input_var and tpl_var:
                    ml = min(len(input_var), len(tpl_var))
                    try:
                        var_score = cos(input_var[:ml], tpl_var[:ml])
                    except Exception:
                        var_score = 0.0
                else:
                    var_score = 0.0
                combined = 0.8 * raw_score + 0.2 * var_score
            else:
                # 1D: check spatiality
                flat = input_raw
                spatiality = Perception.spatiality_1d(flat) if flat else 1.0
                if spatiality > 1.5:
                    # Spatial 1D: shift search
                    best_s = -1
                    for shift in range(-3, 4):
                        shifted = []
                        for i in range(len(flat)):
                            j = i + shift
                            shifted.append(tpl_raw[j] if 0 <= j < len(tpl_raw) else 0.0)
                        ml = min(len(flat), len(shifted))
                        try:
                            s = cos(flat[:ml], shifted[:ml])
                        except Exception:
                            s = 0
                        if s > best_s:
                            best_s = s
                    raw_score = best_s
                else:
                    # Position-invariant: direct cosine
                    ml = min(len(flat), len(tpl_raw))
                    try:
                        raw_score = cos(flat[:ml], tpl_raw[:ml])
                    except Exception:
                        raw_score = 0.0
                # Variance secondary
                input_var = input_features.get('variance', [])
                tpl_var = tpl_feat.get('variance', [])
                if input_var and tpl_var:
                    ml = min(len(input_var), len(tpl_var))
                    try:
                        var_score = cos(input_var[:ml], tpl_var[:ml])
                    except Exception:
                        var_score = 0.0
                else:
                    var_score = 0.0
                alpha = min(spatiality / 3.0, 1.0)
                combined = alpha * raw_score + (1 - alpha) * var_score
            scores[label] = combined
        if not scores:
            return None, 0.0, {}
        best_label = max(scores, key=scores.get)
        best_score = scores[best_label]
        return best_label, best_score if best_score > threshold else 0.0, scores

    @staticmethod
    def select_bandit_arm(arm_features, n_pulls, round_idx, explore_rounds=20, c=1.0):
        """UCB-like: exploit high mean, explore high uncertainty (variance)."""
        if round_idx < explore_rounds:
            return random.randint(0, len(arm_features) - 1)
        scores = []
        total_pulls = sum(n_pulls)
        for arm in range(len(arm_features)):
            feat = arm_features[arm]
            mean_r = feat[0]  # mean reward
            var_r = feat[1]   # variance (uncertainty)
            n = n_pulls[arm] if arm < len(n_pulls) else 1
            # UCB: mean + c * sqrt(ln(total) / n)
            exploration = c * math.sqrt(math.log(total_pulls + 1) / max(n, 1))
            scores.append(mean_r + exploration)
        return scores.index(max(scores))


# ============================================================
# TASKS (v2)
# ============================================================
def make_digit(d, noise=0.15, shift=(0, 0)):
    grid = [[0.0] * 8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r + shift[0], c + shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8:
            grid[nr][nc] = 1.0
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid


def task_digit_pgd():
    templates = {d: make_digit(d, noise=0) for d in range(6)}
    tpl_feats = {d: Perception.extract_2d(tpl) for d, tpl in templates.items()}
    correct_pgd = correct_std = correct_shift = 0
    total = 0
    for true_d in range(6):
        for _ in range(10):
            test = make_digit(true_d, noise=random.uniform(0.1, 0.3),
                              shift=(random.randint(-2, 2), random.randint(-2, 2)))
            best_d, best_s = -1, -1
            for d, tpl in templates.items():
                s = cos([x for row in test for x in row], [x for row in tpl for x in row])
                if s > best_s: best_s, best_d = s, d
            if best_d == true_d: correct_std += 1
            best_d, best_s = -1, -1
            for d, tpl in templates.items():
                s = match_2d_shifted(test, tpl)
                if s > best_s: best_s, best_d = s, d
            if best_d == true_d: correct_shift += 1
            feat = Perception.extract_2d(test)
            label, _, _ = Decision.classify(feat, tpl_feats)
            if label == true_d: correct_pgd += 1
            total += 1
    return {'standard': correct_std / total, 'shift': correct_shift / total,
            'pgd': correct_pgd / total, 'total': total}


def task_digit_generation():
    templates = {d: make_digit(d, noise=0) for d in range(6)}
    tpl_list = list(templates.values())
    results = []
    for a in range(6):
        for b in range(6):
            if a == b: continue
            feat_a = Perception.extract_2d(templates[a])
            # Contrast-guided generation: use A's contrast map, place B's template
            gen = Generation.contrast_guided_generate(feat_a, [templates[b]], (8, 8))
            gen_feat = Perception.extract_2d(gen)
            tpl_feats = {d: Perception.extract_2d(tpl) for d, tpl in templates.items()}
            label, conf, _ = Decision.classify(gen_feat, tpl_feats)
            flat_gen = [x for row in gen for x in row]
            max_sim = max(cos(flat_gen, [x for row in tpl for x in row]) for tpl in tpl_list)
            results.append({'sources': (a, b), 'classified_as': label, 'confidence': conf,
                            'max_sim': max_sim, 'contrast_pts': len(gen_feat['contrast_points'])})
    valid = sum(1 for r in results if r['max_sim'] > 0.5)
    highq = sum(1 for r in results if r['max_sim'] > 0.7)
    avg = sum(r['max_sim'] for r in results) / len(results)
    return {'total': len(results), 'valid': valid, 'high_quality': highq, 'avg_sim': avg,
            'samples': results[:4]}


def task_anomaly_pgd():
    random.seed(123)
    n = 300
    baseline = [math.sin(i * 0.1) + 0.5 * math.sin(i * 0.3) for i in range(n)]
    test = baseline[:]
    anomaly_pos = [40, 100, 160, 220, 280]
    labels = [0] * n
    for pos in anomaly_pos:
        for off in range(-2, 3):
            idx = pos + off
            if 0 <= idx < n:
                test[idx] += random.choice([-1, 1]) * random.uniform(0.7, 1.2)
                labels[idx] = 1
    feat = Perception.extract_1d(test, window=5)
    var = feat['variance']
    thresh = sorted(var)[int(len(var) * 0.90)]
    detections = [i + 2 for i in range(len(var)) if var[i] > thresh]
    diff = [abs(test[i] - test[i - 1]) for i in range(1, n)]
    diff_feat = Perception.extract_1d(diff, window=5)
    dv = diff_feat['variance']
    dt = sorted(dv)[int(len(dv) * 0.85)] if dv else 0
    for i in range(len(dv)):
        if dv[i] > dt: detections.append(i + 1)
    detections = sorted(set(detections))
    true_set = set(i for i, l in enumerate(labels) if l == 1)
    tp = sum(1 for d in detections if any(abs(d - t) <= 3 for t in true_set))
    fp = len(detections) - tp
    fn = sum(1 for t in true_set if not any(abs(d - t) <= 3 for d in detections))
    p = tp / (tp + fp) if tp + fp else 0
    r = tp / (tp + fn) if tp + fn else 0
    f1 = 2 * p * r / (p + r) if p + r else 0
    return {'precision': p, 'recall': r, 'f1': f1, 'detections': len(detections),
            'contrast_pts': len(feat['contrast_points'])}


def task_text_pgd():
    vocab = 26
    topics = {
        'tech': [3,1,3,2,5,1,2,3,3,1,2,3,2,3,3,2,1,2,2,3,2,1,1,1,2,1],
        'sports': [3,1,1,1,3,1,1,1,3,1,1,1,2,3,3,2,1,2,3,3,1,1,1,1,1,1],
        'food': [3,1,1,3,2,3,1,1,2,1,1,1,1,2,3,1,1,1,2,3,1,1,1,1,1,1],
        'nature': [2,1,2,1,3,2,1,2,1,3,2,1,2,1,3,1,2,1,2,1,3,2,1,2,1,2],
    }
    def make_doc(topic, length=150):
        w = topics[topic]
        total = sum(w)
        freq = [0.0] * vocab
        for _ in range(length):
            r = random.random()
            cum = 0
            for idx, p in enumerate([x / total for x in w]):
                cum += p
                if r <= cum:
                    freq[idx] += 1
                    break
        s = sum(freq)
        return [f / s for f in freq]
    # Templates: raw frequency vectors (position-invariant, no local variance)
    tpl_feats = {}
    for topic in topics:
        doc = make_doc(topic, length=200)
        tpl_feats[topic] = {'raw': doc, 'variance': [], 'contrast_points': []}
    correct = 0
    total = 0
    for true_t in topics:
        for _ in range(10):
            doc = make_doc(true_t)
            feat = {'raw': doc, 'variance': [], 'contrast_points': []}
            label, _, _ = Decision.classify(feat, tpl_feats)
            if label == true_t: correct += 1
            total += 1
    # Hybrid generation
    topic_list = list(topics.keys())
    hybrids = []
    for i, t1 in enumerate(topic_list):
        for t2 in topic_list[i + 1:]:
            w1, w2 = topics[t1], topics[t2]
            hybrid_w = w1[:13] + w2[13:]
            total_w = sum(hybrid_w)
            freq = [0.0] * vocab
            for _ in range(150):
                r = random.random()
                cum = 0
                for idx, p in enumerate([x / total_w for x in hybrid_w]):
                    cum += p
                    if r <= cum:
                        freq[idx] += 1
                        break
            s = sum(freq)
            hybrid_doc = [f / s for f in freq]
            feat = {'raw': hybrid_doc, 'variance': [], 'contrast_points': []}
            label, conf, _ = Decision.classify(feat, tpl_feats)
            hybrids.append({'sources': (t1, t2), 'classified_as': label, 'confidence': conf})
    return {'classification_acc': correct / total, 'hybrid_count': len(hybrids),
            'hybrid_samples': hybrids[:3]}


def task_image_reconstruction():
    random.seed(789)
    h, w = 16, 16
    image = []
    for i in range(h):
        row = []
        for j in range(w):
            val = 128 + 40 * math.sin(i * 0.3) + 30 * math.cos(j * 0.25) + random.gauss(0, 3)
            row.append(max(0, min(255, val)))
        image.append(row)
    flat = [x for row in image for x in row]
    feat = Perception.extract_1d(flat, window=5)
    feat_2d = Perception.extract_2d(image, window=3)
    # Improved reconstruction
    recon_flat = Generation.reconstruct_1d(feat, len(flat))
    recon_2d = [recon_flat[i * w:(i + 1) * w] for i in range(h)]
    sim = cos(flat, recon_flat)
    mse = sum((a - b) ** 2 for a, b in zip(flat, recon_flat)) / len(flat)
    psnr = 10 * math.log10(255 ** 2 / mse) if mse > 0 else 100
    recon_feat = Perception.extract_2d(recon_2d, window=3)
    retention = (len(set(feat_2d['contrast_points']) & set(recon_feat['contrast_points'])) /
                 max(len(feat_2d['contrast_points']), 1))
    return {'cosine': sim, 'psnr_db': psnr, 'mse': mse, 'contrast_retention': retention,
            'n_contrast_orig': len(feat_2d['contrast_points']),
            'n_contrast_recon': len(recon_feat['contrast_points'])}


def task_bandit_pgd():
    random.seed(999)
    n_arms = 5
    n_rounds = 100
    true_probs = [0.2, 0.5, 0.8, 0.3, 0.6]
    arm_history = {i: [] for i in range(n_arms)}
    n_pulls = [0] * n_arms
    rewards = []
    selections = []
    for rnd in range(n_rounds):
        # Perception: build features from history
        arm_features = []
        for arm in range(n_arms):
            hist = arm_history[arm]
            if hist:
                m = sum(hist) / len(hist)
                v = sum((x - m) ** 2 for x in hist) / len(hist)
                recent = sum(hist[-3:]) / min(3, len(hist))
            else:
                m, v, recent = 0.5, 0.25, 0.5
            arm_features.append([m, v, recent])
        # Decision: UCB-like selection
        chosen = Decision.select_bandit_arm(arm_features, n_pulls, rnd,
                                            explore_rounds=15, c=0.5)
        reward = 1 if random.random() < true_probs[chosen] else 0
        arm_history[chosen].append(reward)
        n_pulls[chosen] += 1
        rewards.append(reward)
        selections.append(chosen)
    total = sum(rewards)
    optimal = true_probs.index(max(true_probs))
    opt_pulls = selections.count(optimal)
    regret = max(true_probs) * n_rounds - total
    return {'avg_reward': total / n_rounds, 'optimal_pulls': opt_pulls, 'regret': regret,
            'true_probs': true_probs, 'selection_dist': dict(Counter(selections))}


# ============================================================
# MAIN
# ============================================================
def run_all():
    print("=" * 70)
    print("PGD FULL-CHAIN v2 - Targeted Improvements")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Digit Recognition (shift-aware PGD)")
    r = task_digit_pgd()
    results['digit'] = r
    print(f"  Std={r['standard']:.1%}, Shift={r['shift']:.1%}, PGD={r['pgd']:.1%}")

    print("\n[2] Digit Generation (contrast-guided)")
    r = task_digit_generation()
    results['generation'] = r
    print(f"  Total={r['total']}, Valid={r['valid']}, HighQ={r['high_quality']}, AvgSim={r['avg_sim']:.3f}")

    print("\n[3] Anomaly Detection")
    r = task_anomaly_pgd()
    results['anomaly'] = r
    print(f"  P={r['precision']:.3f}, R={r['recall']:.3f}, F1={r['f1']:.3f}")

    print("\n[4] Text Classification (raw frequency vectors)")
    r = task_text_pgd()
    results['text'] = r
    print(f"  Acc={r['classification_acc']:.1%}, Hybrids={r['hybrid_count']}")

    print("\n[5] Image Reconstruction (improved inverse mapping)")
    r = task_image_reconstruction()
    results['reconstruction'] = r
    print(f"  Cos={r['cosine']:.4f}, PSNR={r['psnr_db']:.2f}dB, ContrastRet={r['contrast_retention']:.1%}")

    print("\n[6] Multi-Armed Bandit (UCB exploration)")
    r = task_bandit_pgd()
    results['bandit'] = r
    print(f"  AvgReward={r['avg_reward']:.3f}, OptPulls={r['optimal_pulls']}/100, Regret={r['regret']:.1f}")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.2f}s")
    return results


def retrospective(r1, r2):
    print("\n" + "=" * 70)
    print("RETROSPECTIVE: v1 -> v2 Comparison")
    print("=" * 70)
    comparisons = [
        ('Digit PGD', 'pgd', r1['digit'], r2['digit']),
        ('Digit Gen AvgSim', 'avg_sim', r1['generation'], r2['generation']),
        ('Anomaly F1', 'f1', r1['anomaly'], r2['anomaly']),
        ('Text Acc', 'classification_acc', r1['text'], r2['text']),
        ('Recon PSNR', 'psnr_db', r1['reconstruction'], r2['reconstruction']),
        ('Bandit AvgReward', 'avg_reward', r1['bandit'], r2['bandit']),
    ]
    print(f"\n  {'Task':<20} {'v1':>8} {'v2':>8} {'Delta':>8}")
    print("  " + "-" * 46)
    improvements = []
    regressions = []
    for name, key, v1d, v2d in comparisons:
        v1_val = v1d.get(key, 0)
        v2_val = v2d.get(key, 0)
        delta = v2_val - v1_val
        marker = "↑" if delta > 0.001 else ("↓" if delta < -0.001 else "=")
        print(f"  {name:<20} {v1_val:>7.3f} {v2_val:>7.3f} {delta:>+7.3f} {marker}")
        if delta > 0.001: improvements.append((name, delta))
        elif delta < -0.001: regressions.append((name, delta))

    print(f"\n  Improvements: {len(improvements)}")
    for n, d in improvements: print(f"    + {n}: {d:+.3f}")
    print(f"  Regressions: {len(regressions)}")
    for n, d in regressions: print(f"    - {n}: {d:+.3f}")

    # Remaining weaknesses
    print("\n  Remaining weaknesses for Round 3:")
    if r2['reconstruction']['psnr_db'] < 20:
        print("    - Image reconstruction PSNR still low (<20dB): need structure-aware reconstruction")
    if r2['generation']['high_quality'] < 15:
        print("    - Generation high-quality ratio low: need better template selection")
    if r2['bandit']['regret'] > 10:
        print("    - Bandit regret still high: UCB parameter tuning needed")
    return improvements, regressions


if __name__ == '__main__':
    # Load v1 results for comparison
    v1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_round1_results.json")
    with open(v1_path, 'r') as f:
        v1_data = json.load(f)
    r1 = v1_data['results']

    r2 = run_all()
    improvements, regressions = retrospective(r1, r2)

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_round2_results.json")
    with open(out, 'w') as f:
        json.dump({'results': r2, 'v1_comparison': {'improvements': improvements, 'regressions': regressions}},
                  f, indent=2, default=str)
    print(f"\nv2 saved: {out}")
    print("\n✅ PGD v2 complete.")
