"""
PGD v8.1: Optimized - remove slow coarse-to-fine, enhance discriminative feedback,
multi-template storage, optimized contrast tiebreaker.

Key changes from v8:
1. Remove coarse-to-fine (16x slower, no gain) -> back to 10 angles like v7.1
2. Enhanced feedback: discriminative contribution = correct_match_contrib - wrong_match_contrib
   Points that separate correct from wrong matches are prioritized
3. Multi-template storage: store 3 rotated variants per digit (0, 90, 180) to reduce
   interpolation error during matching
4. Contrast tiebreaker: overlap ratio computed at best alignment, used when gap < 0.05
5. More contrast points (percentile=80 -> top 20%) to capture structural differences
   between 0/4 and 2/3
"""
import os, time, math, json, random
from collections import defaultdict, Counter
from cos_comparison.core import cos, local_variance, mean_local

random.seed(42)

# ============================================================
# Utilities
# ============================================================
def rotate_2d(matrix, angle_deg):
    h, w = len(matrix), len(matrix[0])
    angle = math.radians(angle_deg)
    ca, sa = math.cos(angle), math.sin(angle)
    result = [[0.0]*w for _ in range(h)]
    cx, cy = w/2, h/2
    for i in range(h):
        for j in range(w):
            x, y = j-cx, i-cy
            sx = x*ca + y*sa + cx
            sy = -x*sa + y*ca + cy
            si, sj = int(round(sy)), int(round(sx))
            if 0 <= si < h and 0 <= sj < w:
                result[i][j] = matrix[si][sj]
    return result

def symmetric_kernel_variance(matrix, radius=1):
    h, w = len(matrix), len(matrix[0])
    result = [[0.0]*w for _ in range(h)]
    for i in range(h):
        for j in range(w):
            vals = []
            for di in range(-radius, radius+1):
                for dj in range(-radius, radius+1):
                    if di*di+dj*dj <= radius*radius:
                        ni, nj = i+di, j+dj
                        if 0 <= ni < h and 0 <= nj < w:
                            vals.append(matrix[ni][nj])
            if vals:
                m = sum(vals)/len(vals)
                result[i][j] = sum((v-m)**2 for v in vals)/len(vals)
    return result

# ============================================================
# Enhanced feedback contrast extractor
# ============================================================
class DiscriminativeExtractor:
    """Contrast points ranked by variance * discriminative contribution.

    Discriminative contribution = (sum of scores in correct matches) - (sum of scores in wrong matches)
    Points that appear in correct matches but not wrong matches get high positive contribution.
    Points that appear in both get near-zero contribution (not discriminative).
    Points that appear in wrong matches get negative contribution.

    Mathematical meaning: mutual information between point presence and correct classification.
    """
    def __init__(self, percentile=80, min_points=4, max_points=15):
        self.percentile = percentile  # top 20% by variance
        self.min_points = min_points
        self.max_points = max_points
        self.correct_contrib = defaultdict(float)  # point -> cumulative correct match scores
        self.wrong_contrib = defaultdict(float)    # point -> cumulative wrong match scores
        self.match_count = 0
        self.max_discriminative = 1.0

    def extract(self, matrix):
        h, w = len(matrix), len(matrix[0])
        sk = symmetric_kernel_variance(matrix, 1)
        scored = [(sk[i][j], i, j) for i in range(h) for j in range(w)]
        scored.sort(reverse=True)
        n_take = max(self.min_points, min(self.max_points,
                     int(len(scored) * (100 - self.percentile) / 100)))
        return [(i, j) for _, i, j in scored[:n_take]]

    def record_feedback(self, points, match_score, is_correct):
        self.match_count += 1
        for p in points:
            if is_correct:
                self.correct_contrib[p] += match_score
            else:
                self.wrong_contrib[p] += match_score
            disc = abs(self.correct_contrib[p] - self.wrong_contrib[p])
            if disc > self.max_discriminative:
                self.max_discriminative = disc

    def get_refined_points(self, matrix):
        """Re-rank by variance * (1 + normalized_discriminative_contribution)."""
        h, w = len(matrix), len(matrix[0])
        sk = symmetric_kernel_variance(matrix, 1)
        candidates = self.extract(matrix)
        if self.match_count < 20:
            return candidates
        scored = []
        for (i, j) in candidates:
            variance = sk[i][j]
            disc = (self.correct_contrib.get((i,j), 0) - self.wrong_contrib.get((i,j), 0)) / self.max_discriminative
            # discriminative factor: [0.5, 1.5], points that separate correct from wrong prioritized
            factor = 1.0 + disc * 0.5
            scored.append((variance * factor, i, j))
        scored.sort(reverse=True)
        return [(i, j) for _, i, j in scored[:len(candidates)]]

# ============================================================
# Contrast overlap at alignment
# ============================================================
def contrast_overlap_at_shift(points_a, points_b, dx, dy, tolerance=1):
    """Count overlap of point sets at given shift (no search, just compute)."""
    set_b = set(points_b)
    overlap = 0
    for (ai, aj) in points_a:
        si, sj = ai + dx, aj + dy
        for di in range(-tolerance, tolerance + 1):
            for dj in range(-tolerance, tolerance + 1):
                if (si + di, sj + dj) in set_b:
                    overlap += 1
                    break
            else:
                continue
            break
    denom = min(len(points_a), len(points_b))
    return overlap / denom if denom > 0 else 0.0

# ============================================================
# Rotation + shift matching (v7.1 proven, with contrast overlap)
# ============================================================
ANGLES = (0, 30, 45, 60, 90, 120, 135, 180, 225, 270)

def match_template(img1, template_variants, extractor, use_refined=False, max_shift=2):
    """Match against multiple rotated variants of a template.

    template_variants: list of pre-rotated templates to reduce interpolation error.
    Returns (best_score, best_angle, best_shift, contrast_overlap).
    """
    h, w = len(img1), len(img1[0])
    sk1 = symmetric_kernel_variance(img1, 1)
    sk1_flat = [x for r in sk1 for x in r]
    pts1 = extractor.get_refined_points(img1) if use_refined else extractor.extract(img1)

    best_score = -1
    best_angle = 0
    best_shift = (0, 0)
    best_cov = 0.0

    for angle, rotated in template_variants:
        sk2 = symmetric_kernel_variance(rotated, 1)
        try: sk_sim = cos(sk1_flat, [x for r in sk2 for x in r])
        except: sk_sim = 0.0
        pts2 = extractor.extract(rotated)

        for dx in range(-max_shift, max_shift + 1):
            for dy in range(-max_shift, max_shift + 1):
                a_vals, b_vals = [], []
                for i in range(h):
                    for j in range(w):
                        bi, bj = i - dx, j - dy
                        if 0 <= bi < h and 0 <= bj < w:
                            a_vals.append(img1[i][j])
                            b_vals.append(rotated[bi][bj])
                if len(a_vals) < h * w * 0.5:
                    continue
                try: pix_cos = cos(a_vals, b_vals)
                except: pix_cos = 0.0
                score = 0.75 * pix_cos + 0.25 * sk_sim
                if score > best_score:
                    best_score = score
                    best_angle = angle
                    best_shift = (dx, dy)
                    best_cov = contrast_overlap_at_shift(pts1, pts2, dx, dy)
    return best_score, best_angle, best_shift, best_cov

# ============================================================
# Recognizer
# ============================================================
class RecognizerV81:
    def __init__(self, n_variants=3):
        self.extractor = DiscriminativeExtractor(percentile=80)
        self.templates = {}  # label -> list of (angle, rotated_template)
        self.n_variants = n_variants
        self.tiebreaker_gap = 0.05

    def train(self, label, matrix):
        """Store multiple rotated variants to reduce interpolation error."""
        if self.n_variants == 1:
            angles = [0]
        elif self.n_variants == 3:
            angles = [0, 90, 180]
        else:
            angles = [0, 45, 90, 135, 180, 225, 270]
        variants = [(a, rotate_2d(matrix, a)) for a in angles]
        self.templates[label] = variants

    def validate(self, matrix, return_details=False, use_refined=False):
        results = []
        for label, variants in self.templates.items():
            score, angle, shift, cov = match_template(
                matrix, variants, self.extractor, use_refined=use_refined, max_shift=2)
            results.append((label, score, angle, shift, cov))
        results.sort(key=lambda x: x[1], reverse=True)

        # Tiebreaker: if top1-top2 gap small, contrast overlap decides
        if len(results) >= 2 and results[0][1] - results[1][1] < self.tiebreaker_gap:
            top2 = results[:2]
            top2.sort(key=lambda x: x[4], reverse=True)
            results = top2 + results[2:]

        if return_details:
            return results
        return results[0][0], results[0][1]

    def feedback(self, matrix, predicted, correct):
        points = self.extractor.extract(matrix)
        self.extractor.record_feedback(points, 1.0, predicted == correct)

# ============================================================
# Digit generator
# ============================================================
def make_digit(d, noise=0.15, shift=(0,0), rotation=0):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r+shift[0], c+shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    if rotation != 0: grid = rotate_2d(grid, rotation)
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

# ============================================================
# TASKS
# ============================================================
def task_difficulty_curve(use_refined=False):
    rec = RecognizerV81(n_variants=3)
    for d in range(6): rec.train(d, make_digit(d, 0))
    conditions = [
        ('clean', 0.0, 0, (0,0)),
        ('noise=0.2', 0.2, 0, (0,0)),
        ('rot=random', 0.1, 'random', (0,0)),
        ('shift=±1', 0.1, 0, 'random'),
        ('rot=45+shift', 0.1, 45, 'random'),
        ('rot=random+shift', 0.1, 'random', 'random'),
        ('hard: rot+shift+noise0.15', 0.15, 'random', 'random'),
    ]
    results = {}
    for name, noise, rot, shift in conditions:
        correct = 0
        total = 0
        for true_d in range(6):
            for _ in range(5):
                r = random.choice([0,30,45,60,90,120,135,180,225,270]) if rot=='random' else rot
                s = (random.randint(-1,1), random.randint(-1,1)) if shift=='random' else shift
                test = make_digit(true_d, noise=noise, rotation=r, shift=s)
                pred, _ = rec.validate(test, use_refined=use_refined)
                if pred == true_d: correct += 1
                total += 1
        results[name] = correct / total
        print(f"  {name:35s}: {correct/total:.1%} ({correct}/{total})")
    return results

def task_feedback():
    rec = RecognizerV81(n_variants=3)
    for d in range(6): rec.train(d, make_digit(d, 0))
    # Before
    correct1 = 0
    for true_d in range(6):
        for _ in range(5):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            if pred == true_d: correct1 += 1
    # Feedback 150 rounds
    for _ in range(150):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            rec.feedback(test, pred, true_d)
    # After
    correct2 = 0
    for true_d in range(6):
        for _ in range(5):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec.validate(test, use_refined=True)
            if pred == true_d: correct2 += 1
    return {'before': correct1/30, 'after': correct2/30, 'improvement': (correct2-correct1)/30}

def task_confusion():
    rec = RecognizerV81(n_variants=3)
    for d in range(6): rec.train(d, make_digit(d, 0))
    # Feedback
    for _ in range(100):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, _ = rec.validate(test)
            rec.feedback(test, pred, true_d)
    confusion = defaultdict(lambda: defaultdict(int))
    for true_d in range(6):
        for _ in range(20):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.15, rotation=r, shift=s)
            pred, _ = rec.validate(test, use_refined=True)
            confusion[true_d][pred] += 1
    print("  true\\pred  " + "  ".join(f"{d}" for d in range(6)))
    for true_d in range(6):
        row = "  ".join(f"{confusion[true_d][d]:3d}" for d in range(6))
        c = confusion[true_d][true_d]
        print(f"  {true_d}         {row}   ({c}/20)")
    total = sum(confusion[d][d] for d in range(6))
    return {'accuracy': total/120}

def task_generation():
    rec = RecognizerV81(n_variants=3)
    for d in range(6): rec.train(d, make_digit(d, 0))
    gen_sims = []
    for true_d in range(6):
        for angle in [0, 45, 90, 180]:
            test = make_digit(true_d, noise=0.1, rotation=angle, shift=(1, -1))
            details = rec.validate(test, return_details=True)
            pred, score, best_angle, (dx, dy), cov = details[0]
            # Use the matched variant
            variants = rec.templates[pred]
            aligned = None
            for a, v in variants:
                if a == best_angle:
                    aligned = v
                    break
            if aligned is None:
                aligned = rotate_2d(rec.templates[pred][0][1], best_angle)
            h, w = 8, 8
            generated = [[0.0]*w for _ in range(h)]
            for i in range(h):
                for j in range(w):
                    bi, bj = i - dx, j - dy
                    if 0 <= bi < h and 0 <= bj < w:
                        generated[i][j] = aligned[bi][bj]
            pts = rec.extractor.extract(test)
            for (ci, cj) in pts[:5]:
                if 0 <= ci < h and 0 <= cj < w and test[ci][cj] > 0.3:
                    generated[ci][cj] = test[ci][cj]
            gen_sim = cos([x for r in generated for x in r], [x for r in test for x in r])
            gen_sims.append(gen_sim)
    return {'mean': sum(gen_sims)/len(gen_sims), 'min': min(gen_sims), 'max': max(gen_sims)}

# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':
    print("=" * 70)
    print("PGD v8.1: Discriminative Feedback + Multi-Template + Optimized Tiebreaker")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Difficulty Curve")
    r = task_difficulty_curve(use_refined=False)
    results['difficulty'] = r

    print("\n[2] Feedback (150 rounds, discriminative)")
    r = task_feedback()
    results['feedback'] = r
    print(f"  Before: {r['before']:.1%}, After: {r['after']:.1%}, Improvement: {r['improvement']*100:+.1f}pp")

    print("\n[3] Confusion Matrix (with feedback, 20/digit)")
    r = task_confusion()
    results['confusion'] = r
    print(f"  Overall: {r['accuracy']:.1%}")

    print("\n[4] Generation")
    r = task_generation()
    results['generation'] = r
    print(f"  Mean: {r['mean']:.3f}, range: [{r['min']:.3f}, {r['max']:.3f}]")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.1f}s")

    print("\n" + "=" * 70)
    print("v7.1 -> v8 -> v8.1 COMPARISON")
    print("=" * 70)
    hard = 'hard: rot+shift+noise0.15'
    print(f"  Hard condition: v7.1=76.7% -> v8=76.7% -> v8.1={results['difficulty'].get(hard, 0):.1%}")
    print(f"  Feedback:       v7.1=+3.3pp -> v8=+6.7pp -> v8.1={results['feedback']['improvement']*100:+.1f}pp")
    print(f"  Generation:     v7.1=0.953 -> v8=0.958 -> v8.1={results['generation']['mean']:.3f}")
    print(f"  Time:           v7.1=28s -> v8=465s -> v8.1={elapsed:.0f}s")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_v8_1_results.json")
    with open(out, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved: {out}")
    print("\n✅ PGD v8.1 complete.")
