"""
cos-comparison v0.4.4 - Principle-Driven Experiments
From first principles: hierarchical driving, contrast point crossover,
on-demand extraction, dual-mode complementarity, continuous mapping bottleneck.
Zero dependencies, only cos_comparison.
"""
import os
import time
import math
import json
import random

random.seed(42)

from cos_comparison.core import (
    cos, cos_comparison_passive, cos_comparison_active,
    mean_local, local_variance,
    threshold_filter, threshold_map,
    vector_map_as_tensor,
    set_mode, get_mode,
)

print("=" * 70)
print("Principle-Driven Experiments")
print("=" * 70)

results = {}

# ============================================================
# Principle 1: Hierarchical Driving Loop
# High-level features guide low-level re-extraction
# ============================================================
print("\n[P1] Hierarchical Driving Loop")
print("  Principle: High-level abstraction guides low-level extraction")
print("  to avoid missing details (high->low driving)")

# Generate data with subtle pattern
size = 40
data = []
for i in range(size):
    row = []
    for j in range(size):
        # Base pattern: gradient
        val = (i + j) / (2 * size)
        # Subtle embedded pattern (only visible at fine scale)
        if 10 <= i < 20 and 10 <= j < 20:
            val += 0.1 * math.sin((i - 10) * 0.8) * math.sin((j - 10) * 0.8)
        row.append(val)
    data.append(row)

# Step 1: Coarse extraction (high level)
t0 = time.time()
coarse = mean_local(data, local_size=(5, 5))
coarse_flat = [x for row in coarse for x in row]
t1 = time.time()
print(f"  Coarse extraction: {t1-t0:.4f}s, shape={len(coarse)}x{len(coarse[0])}")

# Step 2: Identify regions of interest from high-level (high variance)
coarse_var = local_variance(coarse, local_size=(3, 3))
roi_threshold = 0.001
roi_count = sum(1 for row in coarse_var for x in row if x > roi_threshold)
print(f"  ROIs identified (var>{roi_threshold}): {roi_count} regions")

# Step 3: Use high-level guidance to focus low-level extraction
# Instead of full fine extraction, only extract in ROIs
t0 = time.time()
fine_full = mean_local(data, local_size=(2, 2))
t1 = time.time()
full_time = t1 - t0

# Guided extraction: only process regions near high-variance areas
t0 = time.time()
guided_results = []
for i in range(0, size - 1, 2):
    for j in range(0, size - 1, 2):
        # Check if this region is in or near an ROI
        ci = min(i // 5, len(coarse_var) - 1)
        cj = min(j // 5, len(coarse_var[0]) - 1)
        if coarse_var[ci][cj] > roi_threshold * 0.5:
            # Fine extraction only here
            window = [data[x][y] for x in range(i, min(i+2, size)) for y in range(j, min(j+2, size))]
            if window:
                guided_results.append(sum(window) / len(window))
t1 = time.time()
guided_time = t1 - t0

# Compare information retention
fine_flat = [x for row in fine_full for x in row]
min_len = min(len(fine_flat), len(guided_results))
if min_len > 0:
    info_retention = cos(fine_flat[:min_len], guided_results[:min_len])
else:
    info_retention = 0

print(f"  Full fine extraction: {full_time:.4f}s")
print(f"  Guided extraction: {guided_time:.4f}s ({guided_time/full_time*100:.1f}% cost)")
print(f"  Information retention: {info_retention:.4f}")
print(f"  Speedup: {full_time/guided_time:.2f}x" if guided_time > 0 else "  Speedup: N/A")

results['hierarchical_driving'] = {
    'full_time': full_time,
    'guided_time': guided_time,
    'info_retention': info_retention,
    'speedup': full_time / guided_time if guided_time > 0 else 0,
    'roi_count': roi_count
}

# ============================================================
# Principle 2: Contrast Point Crossover Analysis
# Information is generated in differences
# ============================================================
print("\n[P2] Contrast Point Crossover Analysis")
print("  Principle: Information exists in differences, not similarities")
print("  Cross-analyze contrast points at same abstraction level")

# Create two related patterns
pattern_a = []
pattern_b = []
for i in range(30):
    row_a = []
    row_b = []
    for j in range(30):
        base = math.sin(i * 0.3) * math.cos(j * 0.2)
        row_a.append(base + 0.1 * math.sin(i * 1.5))  # A has high-freq detail
        row_b.append(base + 0.1 * math.cos(j * 1.5))  # B has different detail
    pattern_a.append(row_a)
    pattern_b.append(row_b)

t0 = time.time()
# Extract features from both
feat_a = cos_comparison_passive(pattern_a, window_size=(3, 3))
feat_b = cos_comparison_passive(pattern_b, window_size=(3, 3))

# Find contrast points (where they differ significantly)
contrast_points = []
for i in range(min(len(feat_a), len(feat_b))):
    for j in range(min(len(feat_a[0]), len(feat_b[0]))):
        diff = abs(feat_a[i][j] - feat_b[i][j])
        if diff > 0.1:
            contrast_points.append((i, j, diff))

# Find common points (where they are similar)
common_points = []
for i in range(min(len(feat_a), len(feat_b))):
    for j in range(min(len(feat_a[0]), len(feat_b[0]))):
        sim = 1 - abs(feat_a[i][j] - feat_b[i][j])
        if sim > 0.9:
            common_points.append((i, j, sim))

t1 = time.time()

# Information content analysis
total_points = len(feat_a) * len(feat_a[0]) if feat_a else 0
contrast_ratio = len(contrast_points) / total_points if total_points else 0
common_ratio = len(common_points) / total_points if total_points else 0

# Verify: reconstruct from contrast points vs common points
if contrast_points:
    avg_contrast = sum(p[2] for p in contrast_points) / len(contrast_points)
else:
    avg_contrast = 0

print(f"  Total feature points: {total_points}")
print(f"  Contrast points: {len(contrast_points)} ({contrast_ratio*100:.1f}%)")
print(f"  Common points: {len(common_points)} ({common_ratio*100:.1f}%)")
print(f"  Average contrast magnitude: {avg_contrast:.4f}")
print(f"  Analysis time: {t1-t0:.4f}s")

# Key insight: contrast points carry more information per point
info_per_contrast = avg_contrast * len(contrast_points)
info_per_common = (1 - avg_contrast) * len(common_points) if common_points else 0
print(f"  Information in contrast: {info_per_contrast:.2f}")
print(f"  Information in common: {info_per_common:.2f}")
print(f"  Contrast/Common info ratio: {info_per_contrast/info_per_common:.2f}x" if info_per_common > 0 else "")

results['contrast_crossover'] = {
    'contrast_points': len(contrast_points),
    'common_points': len(common_points),
    'avg_contrast': avg_contrast,
    'contrast_ratio': contrast_ratio,
    'info_ratio': info_per_contrast / info_per_common if info_per_common > 0 else 0
}

# ============================================================
# Principle 3: On-Demand Extraction Efficiency
# ============================================================
print("\n[P3] On-Demand Extraction Efficiency")
print("  Principle: Extract only what's needed, not all data")

data_large = [random.random() for _ in range(2000)]

# Full extraction
t0 = time.time()
full_features = mean_local(data_large, local_size=(5,))
t1 = time.time()
full_time = t1 - t0

# On-demand: extract only every Nth position
for step in [2, 5, 10, 20]:
    t0 = time.time()
    on_demand = []
    for i in range(0, len(data_large) - 5, step):
        window = data_large[i:i+5]
        on_demand.append(sum(window) / len(window))
    t1 = time.time()
    od_time = t1 - t0
    
    # Compare with full features at sampled positions
    sampled_full = [full_features[i] for i in range(0, len(full_features), step) if i < len(full_features)]
    min_l = min(len(sampled_full), len(on_demand))
    if min_l > 0:
        retention = cos(sampled_full[:min_l], on_demand[:min_l])
    else:
        retention = 0
    
    print(f"  Step={step:2d}: time={od_time:.4f}s ({od_time/full_time*100:5.1f}%), "
          f"samples={len(on_demand):4d}, retention={retention:.4f}")

results['on_demand'] = {'tested_steps': [2, 5, 10, 20]}

# ============================================================
# Principle 4: Dual-Mode Complementarity
# Passive (sliding window) + Active (template matching)
# ============================================================
print("\n[P4] Dual-Mode Complementarity")
print("  Principle: Passive captures local structure, Active matches templates")
print("  Their union captures more than either alone")

# Create image with both texture (passive) and shape (active)
img_size = 24
image = []
template = []
for i in range(img_size):
    row = []
    for j in range(img_size):
        # Texture (high frequency)
        texture = 0.3 * math.sin(i * 2.0) * math.cos(j * 2.0)
        # Shape (low frequency blob)
        r = math.sqrt((i - 12)**2 + (j - 12)**2)
        shape = 0.7 * math.exp(-r * 0.1)
        row.append(texture + shape)
    image.append(row)

# Template for active mode (blob shape)
tpl_size = 7
for i in range(tpl_size):
    row = []
    for j in range(tpl_size):
        r = math.sqrt((i - 3)**2 + (j - 3)**2)
        row.append(math.exp(-r * 0.3))
    template.append(row)

t0 = time.time()
# Passive mode: captures texture
passive_feat = cos_comparison_passive(image, window_size=(3, 3))
# Active mode: captures shape
active_feat = cos_comparison_active(image, kernel=template)
t1 = time.time()

# Analyze what each captures
passive_flat = [x for row in passive_feat for x in row]
active_flat = [x for row in active_feat for x in row]

# Variance as information measure
p_var = sum((x - sum(passive_flat)/len(passive_flat))**2 for x in passive_flat) / len(passive_flat) if passive_flat else 0
a_var = sum((x - sum(active_flat)/len(active_flat))**2 for x in active_flat) / len(active_flat) if active_flat else 0

# Combined information (union of high-response regions)
p_high = sum(1 for x in passive_flat if x > 0.5)
a_high = sum(1 for x in active_flat if x > 0.5)

print(f"  Passive features: {len(passive_flat)} points, variance={p_var:.6f}, high-resp={p_high}")
print(f"  Active features: {len(active_flat)} points, variance={a_var:.6f}, high-resp={a_high}")
print(f"  Extraction time: {t1-t0:.4f}s")

# Complementarity: if they capture different things, their correlation should be low
min_l = min(len(passive_flat), len(active_flat))
if min_l > 0:
    mode_correlation = cos(passive_flat[:min_l], active_flat[:min_l])
    print(f"  Mode correlation: {mode_correlation:.4f} (lower = more complementary)")
    print(f"  Complementarity score: {1 - mode_correlation:.4f}")
else:
    mode_correlation = 0

results['dual_mode'] = {
    'passive_variance': p_var,
    'active_variance': a_var,
    'correlation': mode_correlation,
    'complementarity': 1 - mode_correlation
}

# ============================================================
# Principle 5: Continuous Mapping Information Bottleneck
# Find optimal number of abstraction layers
# ============================================================
print("\n[P5] Continuous Mapping Information Bottleneck")
print("  Principle: Each abstraction layer loses some info;")
print("  find the optimal depth where benefit > cost")

base_data = [math.sin(i * 0.1) + random.gauss(0, 0.05) for i in range(500)]

print(f"  {'Layers':<8} {'Retention':>10} {'Time':>10} {'Efficiency':>12}")
print("  " + "-" * 42)

layer_results = []
for max_layers in [1, 2, 3, 4, 5, 6, 8, 10]:
    t0 = time.time()
    current = base_data
    for layer in range(max_layers):
        current = mean_local(current, local_size=(3,))
    t1 = time.time()
    
    min_l = min(len(base_data), len(current))
    retention = cos(base_data[:min_l], current[:min_l]) if min_l > 0 else 0
    elapsed = t1 - t0
    efficiency = retention / elapsed if elapsed > 0 else 0
    
    print(f"  {max_layers:<8} {retention:>10.4f} {elapsed:>10.4f}s {efficiency:>12.2f}")
    layer_results.append({'layers': max_layers, 'retention': retention, 'time': elapsed, 'efficiency': efficiency})

# Find optimal (max efficiency)
optimal = max(layer_results, key=lambda x: x['efficiency'])
print(f"\n  Optimal layers: {optimal['layers']} (efficiency={optimal['efficiency']:.2f})")
print(f"  Retention at optimal: {optimal['retention']:.4f}")

results['bottleneck'] = {
    'optimal_layers': optimal['layers'],
    'optimal_retention': optimal['retention'],
    'layer_data': layer_results
}

# ============================================================
# Principle 6: Behavior-as-Data (Von Neumann architecture)
# Instructions stored as data, executed by fixed code
# ============================================================
print("\n[P6] Behavior-as-Data Architecture")
print("  Principle: Instructions are data; fixed interpreter executes")
print("  variable logic without code modification")

# Define "instructions" as data (parameter sets)
instructions = [
    {'name': 'smooth', 'local_size': 5, 'operation': 'mean'},
    {'name': 'edge', 'local_size': 3, 'operation': 'variance'},
    {'name': 'coarse', 'local_size': 9, 'operation': 'mean'},
    {'name': 'fine_edge', 'local_size': 2, 'operation': 'variance'},
]

# Fixed interpreter
def execute_instruction(data, instr):
    if instr['operation'] == 'mean':
        return mean_local(data, local_size=(instr['local_size'],))
    elif instr['operation'] == 'variance':
        return local_variance(data, local_size=(instr['local_size'],))
    return data

test_data = [math.sin(i * 0.1) + random.gauss(0, 0.1) for i in range(200)]

t0 = time.time()
# Execute all instructions (data-driven behavior)
outputs = {}
for instr in instructions:
    result = execute_instruction(test_data, instr)
    outputs[instr['name']] = result
t1 = time.time()

print(f"  Executed {len(instructions)} instructions in {t1-t0:.4f}s")
for name, result in outputs.items():
    avg = sum(result) / len(result) if result else 0
    print(f"    {name}: {len(result)} values, avg={avg:.4f}")

# Verify: same instruction produces same result (deterministic)
r1 = execute_instruction(test_data, instructions[0])
r2 = execute_instruction(test_data, instructions[0])
determinism = cos(r1, r2) if len(r1) == len(r2) else 0
print(f"  Determinism verification: {determinism:.4f} (should be 1.0)")

results['behavior_as_data'] = {
    'instructions': len(instructions),
    'time': t1 - t0,
    'determinism': determinism
}

# ============================================================
# Summary
# ============================================================
print("\n" + "=" * 70)
print("PRINCIPLE-DRIVEN EXPERIMENT SUMMARY")
print("=" * 70)

print("\nKey Principle Verifications:")
print(f"  1. Hierarchical driving: {results['hierarchical_driving']['speedup']:.2f}x speedup, "
      f"{results['hierarchical_driving']['info_retention']:.4f} retention")
print(f"  2. Contrast crossover: contrast info {results['contrast_crossover']['info_ratio']:.2f}x of common info")
print(f"  4. Dual-mode complementarity: {results['dual_mode']['complementarity']:.4f}")
print(f"  5. Optimal layers: {results['bottleneck']['optimal_layers']} "
      f"(retention={results['bottleneck']['optimal_retention']:.4f})")
print(f"  6. Behavior-as-data: determinism={results['behavior_as_data']['determinism']:.4f}")

output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "principle_results.json")
with open(output_path, 'w') as f:
    json.dump(results, f, indent=2, default=str)
print(f"\nResults saved: {output_path}")
print("\n✅ All 6 principle-driven experiments completed!")
