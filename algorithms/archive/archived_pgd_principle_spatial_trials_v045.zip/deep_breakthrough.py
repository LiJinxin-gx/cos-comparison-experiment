"""
cos-comparison v0.4.4 - Deep Boundary Breaking Experiments
Store in explore directory for algorithm sharing.
Zero external dependencies, only cos_comparison.
"""
import os
import sys
import time
import math
import json
import random
from collections import deque

# Ensure reproducibility
random.seed(2024)

import cos_comparison
from cos_comparison.core import (
    cos, cos_comparison_passive, cos_comparison_active,
    mean_local, local_variance,
    threshold_filter, threshold_map, threshold_judge,
    vector_map_as_tensor, create_void_list,
    set_mode, get_mode, infer_shape,
)

print("=" * 70)
print("cos-comparison v0.4.4 - Deep Boundary Breaking")
print("=" * 70)
print(f"Version: {cos_comparison.__version__}")
print(f"Backend: {get_mode()}")

results = {}

# ============================================================
# Experiment 1: Self-Reference (Model analyzing its own output)
# ============================================================
print("\n[Exp 1] Self-Reference Analysis")
# Generate data, extract features, then analyze feature similarity
data = [math.sin(i * 0.1) + random.gauss(0, 0.1) for i in range(200)]

t0 = time.time()
# Layer 1: raw features
f1 = mean_local(data, local_size=(5,))
# Layer 2: features of features
f2 = mean_local(f1, local_size=(5,))
# Layer 3: features of features of features
f3 = mean_local(f2, local_size=(5,))
t1 = time.time()

# Compare information retention across layers
min_len = min(len(data), len(f1), len(f2), len(f3))
sim_d_f1 = cos(data[:min_len], f1[:min_len])
sim_f1_f2 = cos(f1[:min_len], f2[:min_len])
sim_f2_f3 = cos(f2[:min_len], f3[:min_len])
sim_d_f3 = cos(data[:min_len], f3[:min_len])

print(f"  Time: {t1-t0:.4f}s")
print(f"  data->f1: {sim_d_f1:.4f}, f1->f2: {sim_f1_f2:.4f}, f2->f3: {sim_f2_f3:.4f}")
print(f"  data->f3 (3-layer): {sim_d_f3:.4f}")
print(f"  Information decay per layer: {(1-sim_d_f1):.4f}, {(1-sim_f1_f2):.4f}, {(1-sim_f2_f3):.4f}")
results['self_reference'] = {
    'sim_d_f1': sim_d_f1, 'sim_f1_f2': sim_f1_f2,
    'sim_f2_f3': sim_f2_f3, 'sim_d_f3': sim_d_f3
}

# ============================================================
# Experiment 2: Extreme Dimensionality (5D and 6D)
# ============================================================
print("\n[Exp 2] Extreme Dimensionality (5D/6D)")
for dims in [5, 6]:
    size = 4
    # Build nested list
    def build_nd(d, remaining):
        if remaining == 0:
            return random.random()
        return [build_nd(d, remaining-1) for _ in range(size)]
    
    data_nd = build_nd(dims, dims)
    t0 = time.time()
    try:
        local_size = tuple([2] * dims)
        result = mean_local(data_nd, local_size=local_size)
        t1 = time.time()
        # Count output elements
        def count_elements(obj):
            if isinstance(obj, list):
                return sum(count_elements(x) for x in obj)
            return 1
        out_count = count_elements(result)
        print(f"  {dims}D: input={size}^{dims}={size**dims}, output_elements={out_count}, time={t1-t0:.4f}s")
        results[f'{dims}d'] = {'success': True, 'time': t1-t0, 'output_elements': out_count}
    except Exception as e:
        t1 = time.time()
        print(f"  {dims}D: ERROR - {e}")
        results[f'{dims}d'] = {'success': False, 'error': str(e)}

# ============================================================
# Experiment 3: Fractal Pattern Recognition
# ============================================================
print("\n[Exp 3] Fractal Pattern Recognition")
# Generate Sierpinski-like pattern
size = 32
fractal = []
for i in range(size):
    row = []
    for j in range(size):
        # Sierpinski triangle pattern
        val = 1.0 if (i & j) == 0 else 0.0
        row.append(val)
    fractal.append(row)

t0 = time.time()
# Multi-scale analysis
for ws in [3, 5, 7]:
    features = cos_comparison_passive(fractal, window_size=(ws, ws))
    flat = [x for row in features for x in row]
    if flat:
        avg = sum(flat) / len(flat)
        variance = sum((x-avg)**2 for x in flat) / len(flat)
        print(f"  Window {ws}x{ws}: avg_sim={avg:.4f}, variance={variance:.6f}")
t1 = time.time()
print(f"  Total time: {t1-t0:.4f}s")
results['fractal'] = {'time': t1-t0}

# ============================================================
# Experiment 4: Information Compression Limit
# ============================================================
print("\n[Exp 4] Information Compression Limit")
# Test how much compression preserves similarity
original = [random.random() for _ in range(500)]

for bits in [1, 2, 3, 4, 5, 6, 7, 8]:
    levels = 2 ** bits
    # Create threshold pairs: quantize to levels
    pairs = []
    for i in range(levels):
        threshold = (i + 1) / levels
        value = (i + 0.5) / levels
        pairs.append((threshold, value))
    compressed = threshold_map(original, pairs, default_value=(levels - 0.5) / levels)
    sim = cos(original, compressed)
    mse = sum((a-b)**2 for a,b in zip(original, compressed)) / len(original)
    unique_vals = len(set(compressed))
    print(f"  {bits} bits ({levels:3d} levels): cos={sim:.4f}, MSE={mse:.6f}, unique={unique_vals}, ratio={8/bits:.1f}x")

results['compression_limit'] = {'bits_tested': [1,2,3,4,5,6,7,8]}

# ============================================================
# Experiment 5: Streaming Data Processing
# ============================================================
print("\n[Exp 5] Streaming Data Processing")
# Simulate real-time stream with sliding window
stream = [math.sin(i * 0.05) + random.gauss(0, 0.05) for i in range(1000)]
window_size = 50
step = 10

t0 = time.time()
stream_results = []
for start in range(0, len(stream) - window_size, step):
    window = stream[start:start+window_size]
    # Extract features from window
    m = mean_local(window, local_size=(5,))
    v = local_variance(window, local_size=(5,))
    # Detect change points
    if v and max(v) > 0.02:
        stream_results.append((start, max(v)))
t1 = time.time()

print(f"  Stream length: {len(stream)}, windows processed: {len(stream_results)}")
print(f"  Change points detected: {len(stream_results)}")
print(f"  Time: {t1-t0:.4f}s ({(t1-t0)/len(stream)*1000:.3f}ms per 1000 samples)")
results['streaming'] = {'change_points': len(stream_results), 'time': t1-t0}

# ============================================================
# Experiment 6: Adversarial Robustness
# ============================================================
print("\n[Exp 6] Adversarial Robustness")
# Create two nearly identical patterns, test discrimination
base_pattern = [math.sin(i * 0.1) for i in range(100)]

for perturbation in [0.001, 0.01, 0.05, 0.1, 0.2, 0.5]:
    perturbed = [x + random.gauss(0, perturbation) for x in base_pattern]
    sim = cos(base_pattern, perturbed)
    # Also test with local features
    base_f = mean_local(base_pattern, local_size=(3,))
    pert_f = mean_local(perturbed, local_size=(3,))
    min_l = min(len(base_f), len(pert_f))
    sim_f = cos(base_f[:min_l], pert_f[:min_l])
    print(f"  Perturbation={perturbation:.3f}: raw_cos={sim:.4f}, feature_cos={sim_f:.4f}")

results['adversarial'] = {'perturbations': [0.001, 0.01, 0.05, 0.1, 0.2, 0.5]}

# ============================================================
# Experiment 7: Cross-Domain Pattern Transfer
# ============================================================
print("\n[Exp 7] Cross-Domain Pattern Transfer")
# Same pattern in different "domains" (scales/offsets)
pattern = [math.sin(i * 0.2) for i in range(50)]

domains = {
    'original': pattern,
    'scaled_2x': [x * 2 for x in pattern],
    'offset_1': [x + 1 for x in pattern],
    'scaled_offset': [x * 0.5 + 0.5 for x in pattern],
    'reversed': pattern[::-1],
    'noisy': [x + random.gauss(0, 0.1) for x in pattern],
}

print(f"  {'Domain':<15} {'cos_sim':>10} {'local_cos':>10}")
print("  " + "-" * 37)
for name, data in domains.items():
    sim = cos(pattern, data)
    f1 = mean_local(pattern, local_size=(3,))
    f2 = mean_local(data, local_size=(3,))
    min_l = min(len(f1), len(f2))
    sim_f = cos(f1[:min_l], f2[:min_l]) if min_l > 0 else 0
    print(f"  {name:<15} {sim:>10.4f} {sim_f:>10.4f}")

results['cross_domain'] = {'domains': list(domains.keys())}

# ============================================================
# Experiment 8: Tensor Algebra Composition
# ============================================================
print("\n[Exp 8] Tensor Algebra Composition")
# Build 3D tensor and perform chained operations
data_3d = []
for i in range(8):
    plane = []
    for j in range(8):
        row = [math.sin(i*0.3 + j*0.2 + k*0.1) for k in range(8)]
        plane.append(row)
    data_3d.append(plane)

t0 = time.time()
# Operation chain: 3D mean -> flatten -> 1D variance -> threshold
step1 = mean_local(data_3d, local_size=(2,2,2))
# Flatten 3D to 1D
step1_1d = []
for plane in step1:
    for row in plane:
        step1_1d.extend(row)
step2 = local_variance(step1_1d, local_size=(3,))
step3 = threshold_map(step2, [(0.0, 0.0), (0.01, 1.0), (0.05, 2.0), (0.1, 3.0)], default_value=0.0)
t1 = time.time()

print(f"  3D->1D chain: {t1-t0:.4f}s")
print(f"  Step1 (3D mean): planes={len(step1)}")
print(f"  Step2 (1D var): length={len(step2)}")
print(f"  Step3 (1D threshold): values={len(step3)}, unique={len(set(step3))}")
results['tensor_algebra'] = {'time': t1-t0}

# ============================================================
# Experiment 9: Memory-Efficient Large Matrix
# ============================================================
print("\n[Exp 9] Memory-Efficient Large Matrix")
# Test with large 2D data using vector_map_as_tensor views
large_size = 100
large_data = [random.random() for _ in range(large_size * large_size)]

t0 = time.time()
vmt = vector_map_as_tensor(vector=large_data, shape=(large_size, large_size))
# Extract multiple views without copying
views = []
for i in range(0, large_size - 10, 10):
    for j in range(0, large_size - 10, 10):
        view = vmt[i:i+10, j:j+10]
        views.append(view)
t1 = time.time()

print(f"  Large matrix: {large_size}x{large_size} = {large_size**2} elements")
print(f"  Views created: {len(views)} (zero-copy)")
print(f"  Time: {t1-t0:.4f}s")
print(f"  Memory: original {large_size**2*8} bytes, views share memory")
results['memory_efficient'] = {'views': len(views), 'time': t1-t0}

# ============================================================
# Experiment 10: Pattern Generation via Inverse Mapping
# ============================================================
print("\n[Exp 10] Pattern Generation via Threshold Inversion")
# Generate patterns from compressed representations
template = [0.0, 0.25, 0.5, 0.75, 1.0, 0.75, 0.5, 0.25, 0.0]

t0 = time.time()
generated = []
for scale in [1.0, 2.0, 0.5]:
    for offset in [0.0, 0.2, -0.2]:
        pattern = [min(1.0, max(0.0, x * scale + offset)) for x in template]
        generated.append(pattern)
t1 = time.time()

# Compare generated patterns
print(f"  Generated {len(generated)} pattern variants")
for i, p in enumerate(generated[:3]):
    sim = cos(template, p)
    print(f"  Variant {i}: cos_to_template={sim:.4f}")
print(f"  Time: {t1-t0:.4f}s")
results['pattern_generation'] = {'variants': len(generated)}

# ============================================================
# Summary
# ============================================================
print("\n" + "=" * 70)
print("DEEP BREAKTHROUGH SUMMARY")
print("=" * 70)
print(json.dumps(results, indent=2, default=str))

# Save results
output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "breakthrough_results.json")
with open(output_path, 'w') as f:
    json.dump(results, f, indent=2, default=str)
print(f"\nResults saved to: {output_path}")
print("\n✅ All 10 deep breakthrough experiments completed!")
