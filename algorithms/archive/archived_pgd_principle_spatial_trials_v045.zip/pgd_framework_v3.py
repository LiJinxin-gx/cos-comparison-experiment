"""
PGD Full-Chain v3 - Fix reconstruction and generation, final generalization.
Key fixes:
1. Reconstruction: preserve contrast point values exactly, fill rest from mean (structure-aware)
2. Generation: multi-template selective combination with high-level structure guidance
3. Text: add variance of frequency as discriminative feature
4. Bandit: tuned UCB
"""
import os, time, math, json, random
from collections import Counter
from cos_comparison.core import cos, local_variance, mean_local, cos_comparison_passive

random.seed(42)

class Perception:
    @staticmethod
    def extract_1d(data, window=5):
        f = {'raw': data[:]}
        try: f['variance'] = local_variance(data, local_size=(window,))
        except: f['variance'] = []
        try: f['mean'] = mean_local(data, local_size=(window,))
        except: f['mean'] = []
        try: f['passive'] = cos_comparison_passive(data, local_size=(window,))
        except: f['passive'] = []
        if f['variance']:
            vmax = max(f['variance'])
            f['contrast_points'] = [i for i, v in enumerate(f['variance']) if v > vmax * 0.3]
        else:
            f['contrast_points'] = []
        return f

    @staticmethod
    def extract_2d(matrix, window=3):
        h, w = len(matrix), len(matrix[0])
        f = {'raw': matrix, 'flat': [x for row in matrix for x in row], 'shape': (h, w)}
        f['row_variance'] = []
        for row in matrix:
            try: f['row_variance'].append(local_variance(row, local_size=(window,)))
            except: f['row_variance'].append([])
        f['col_variance'] = []
        for j in range(w):
            col = [matrix[i][j] for i in range(h)]
            try: f['col_variance'].append(local_variance(col, local_size=(window,)))
            except: f['col_variance'].append([])
        contrast = set()
        for i, rvs in enumerate(f['row_variance']):
            if rvs:
                vmax = max(rvs)
                for j, v in enumerate(rvs):
                    if v > vmax * 0.3: contrast.add((i, min(j + window // 2, w - 1)))
        for j, cvs in enumerate(f['col_variance']):
            if cvs:
                vmax = max(cvs)
                for i, v in enumerate(cvs):
                    if v > vmax * 0.3: contrast.add((min(i + window // 2, h - 1), j))
        f['contrast_points'] = sorted(contrast)
        return f

    @staticmethod
    def spatiality_1d(data):
        n = len(data)
        if n < 4: return 1.0
        m = sum(data) / n
        num = sum((data[i] - m) * (data[i + 1] - m) for i in range(n - 1))
        den = sum((x - m) ** 2 for x in data)
        return abs(num / den) * 5 + 1.0 if den > 1e-10 else 1.0


class Generation:
    @staticmethod
    def reconstruct_1d_structure(features, length):
        """Structure-aware reconstruction:
        - Contrast points: preserve original values exactly (information-rich)
        - Non-contrast: fill from local mean (smooth structure)
        - This is '按需提取': preserve detail where it matters, smooth where it doesn't.
        """
        raw = features.get('raw', [])
        mn = features.get('mean', [])
        contrast = set(features.get('contrast_points', []))
        result = [0.0] * length
        for i in range(length):
            if i in contrast and i < len(raw):
                result[i] = raw[i]  # preserve detail at info-rich points
            elif i < len(mn):
                result[i] = mn[i]  # smooth structure elsewhere
            elif i < len(raw):
                result[i] = raw[i] * 0.7  # fallback
        return result

    @staticmethod
    def selective_combine_2d(templates, selection, shape):
        """Selective combination: specific regions from specific templates."""
        h, w = shape
        result = [[0.0] * w for _ in range(h)]
        for tpl_idx, top, left, bottom, right in selection:
            if tpl_idx < len(templates):
                tpl = templates[tpl_idx]
                for i in range(top, min(bottom, h)):
                    for j in range(left, min(right, w)):
                        si, sj = i - top, j - left
                        if si < len(tpl) and sj < len(tpl[0]):
                            result[i][j] = tpl[si][sj]
        return result

    @staticmethod
    def structure_guided_generate(source_feat, templates, target_shape, primary_tpl=0):
        """High-level structure from source guides low-level template placement.
        Primary template provides overall structure; secondary templates fill contrast regions.
        """
        h, w = target_shape
        # Start with primary template (overall structure)
        result = [row[:] for row in templates[primary_tpl][:h]]
        while len(result) < h:
            result.append([0.0] * w)
        for row in result:
            while len(row) < w: row.append(0.0)
        # At contrast points, overlay secondary template patches
        contrast = source_feat.get('contrast_points', [])
        if len(templates) > 1 and contrast:
            sec = templates[1]
            th, tw = len(sec), len(sec[0])
            # Only use top-K contrast points (most informative)
            top_k = min(len(contrast), 5)
            for (ci, cj) in contrast[:top_k]:
                top = max(0, ci - th // 2)
                left = max(0, cj - tw // 2)
                for i in range(th):
                    for j in range(tw):
                        ri, rj = top + i, left + j
                        if 0 <= ri < h and 0 <= rj < w and sec[i][j] > 0:
                            result[ri][rj] = sec[i][j]
        return result


def match_2d_shifted(img1, img2, shifts=(-2, -1, 0, 1, 2)):
    best = -1
    h = min(len(img1), len(img2))
    w = min(len(img1[0]) if img1 else 0, len(img2[0]) if img2 else 0)
    for dy in shifts:
        for dx in shifts:
            f1, f2 = [], []
            for i in range(h):
                for j in range(w):
                    f1.append(img1[i][j])
                    ni, nj = i + dy, j + dx
                    f2.append(img2[ni][nj] if 0 <= ni < len(img2) and 0 <= nj < len(img2[0]) else 0.0)
            s = cos(f1, f2)
            if s > best: best = s
    return best


class Decision:
    @staticmethod
    def classify(input_feat, tpl_feats, shifts=(-2, -1, 0, 1, 2)):
        scores = {}
        raw = input_feat.get('raw', [])
        is_2d = bool(raw and isinstance(raw[0], list))
        for label, tf in tpl_feats.items():
            tpl_raw = tf.get('raw', [])
            if is_2d:
                raw_score = match_2d_shifted(raw, tpl_raw, shifts)
                iv = [x for row in input_feat.get('row_variance', []) for x in row]
                tv = [x for row in tf.get('row_variance', []) for x in row]
                var_score = cos(iv[:min(len(iv), len(tv))], tv[:min(len(iv), len(tv))]) if iv and tv else 0
                scores[label] = 0.8 * raw_score + 0.2 * var_score
            else:
                spatiality = Perception.spatiality_1d(raw) if raw else 1.0
                if spatiality > 1.5:
                    best_s = -1
                    for shift in range(-3, 4):
                        shifted = [tpl_raw[i + shift] if 0 <= i + shift < len(tpl_raw) else 0.0 for i in range(len(raw))]
                        ml = min(len(raw), len(shifted))
                        s = cos(raw[:ml], shifted[:ml])
                        if s > best_s: best_s = s
                    raw_score = best_s
                else:
                    ml = min(len(raw), len(tpl_raw))
                    raw_score = cos(raw[:ml], tpl_raw[:ml]) if ml > 0 else 0
                iv = input_feat.get('variance', [])
                tv = tf.get('variance', [])
                var_score = cos(iv[:min(len(iv), len(tv))], tv[:min(len(iv), len(tv))]) if iv and tv else 0
                alpha = min(spatiality / 3.0, 1.0)
                scores[label] = alpha * raw_score + (1 - alpha) * var_score
        if not scores: return None, 0.0, {}
        best = max(scores, key=scores.get)
        return best, scores[best], scores

    @staticmethod
    def bandit_ucb(arm_feats, n_pulls, rnd, explore=15, c=0.3):
        if rnd < explore: return random.randint(0, len(arm_feats) - 1)
        total = sum(n_pulls)
        scores = []
        for arm in range(len(arm_feats)):
            m = arm_feats[arm][0]
            n = n_pulls[arm] if arm < len(n_pulls) else 1
            ucb = m + c * math.sqrt(math.log(total + 1) / max(n, 1))
            scores.append(ucb)
        return scores.index(max(scores))


def make_digit(d, noise=0.15, shift=(0, 0)):
    grid = [[0.0] * 8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r + shift[0], c + shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid


def task_digit():
    templates = {d: make_digit(d, 0) for d in range(6)}
    tpl_feats = {d: Perception.extract_2d(t) for d, t in templates.items()}
    c_std = c_shift = c_pgd = 0
    total = 0
    for true_d in range(6):
        for _ in range(10):
            test = make_digit(true_d, random.uniform(0.1, 0.3),
                              (random.randint(-2, 2), random.randint(-2, 2)))
            bd, bs = -1, -1
            for d, t in templates.items():
                s = cos([x for r in test for x in r], [x for r in t for x in r])
                if s > bs: bs, bd = s, d
            if bd == true_d: c_std += 1
            bd, bs = -1, -1
            for d, t in templates.items():
                s = match_2d_shifted(test, t)
                if s > bs: bs, bd = s, d
            if bd == true_d: c_shift += 1
            feat = Perception.extract_2d(test)
            label, _, _ = Decision.classify(feat, tpl_feats)
            if label == true_d: c_pgd += 1
            total += 1
    return {'standard': c_std/total, 'shift': c_shift/total, 'pgd': c_pgd/total}


def task_generation():
    templates = {d: make_digit(d, 0) for d in range(6)}
    tpl_list = list(templates.values())
    tpl_feats = {d: Perception.extract_2d(t) for d, t in templates.items()}
    results = []
    for a in range(6):
        for b in range(6):
            if a == b: continue
            feat_a = Perception.extract_2d(templates[a])
            # Structure-guided: A as primary structure, B fills contrast regions
            gen = Generation.structure_guided_generate(feat_a, [templates[a], templates[b]], (8, 8), primary_tpl=0)
            gen_feat = Perception.extract_2d(gen)
            label, conf, _ = Decision.classify(gen_feat, tpl_feats)
            flat_gen = [x for r in gen for x in r]
            max_sim = max(cos(flat_gen, [x for r in t for x in r]) for t in tpl_list)
            results.append({'sources': (a, b), 'classified': label, 'max_sim': max_sim,
                            'contrast': len(gen_feat['contrast_points'])})
    valid = sum(1 for r in results if r['max_sim'] > 0.5)
    highq = sum(1 for r in results if r['max_sim'] > 0.7)
    avg = sum(r['max_sim'] for r in results) / len(results)
    return {'total': len(results), 'valid': valid, 'high_quality': highq, 'avg_sim': avg,
            'best': max(results, key=lambda x: x['max_sim'])}


def task_anomaly():
    random.seed(123)
    n = 300
    baseline = [math.sin(i * 0.1) + 0.5 * math.sin(i * 0.3) for i in range(n)]
    test = baseline[:]
    positions = [40, 100, 160, 220, 280]
    labels = [0] * n
    for pos in positions:
        for off in range(-2, 3):
            idx = pos + off
            if 0 <= idx < n:
                test[idx] += random.choice([-1, 1]) * random.uniform(0.7, 1.2)
                labels[idx] = 1
    feat = Perception.extract_1d(test, 5)
    var = feat['variance']
    thresh = sorted(var)[int(len(var) * 0.90)]
    det = [i + 2 for i in range(len(var)) if var[i] > thresh]
    diff = [abs(test[i] - test[i-1]) for i in range(1, n)]
    df = Perception.extract_1d(diff, 5)['variance']
    dt = sorted(df)[int(len(df) * 0.85)] if df else 0
    for i in range(len(df)):
        if df[i] > dt: det.append(i + 1)
    det = sorted(set(det))
    true_set = set(i for i, l in enumerate(labels) if l == 1)
    tp = sum(1 for d in det if any(abs(d - t) <= 3 for t in true_set))
    fp = len(det) - tp
    fn = sum(1 for t in true_set if not any(abs(d - t) <= 3 for d in det))
    p = tp / (tp + fp) if tp + fp else 0
    r = tp / (tp + fn) if tp + fn else 0
    f1 = 2 * p * r / (p + r) if p + r else 0
    return {'precision': p, 'recall': r, 'f1': f1, 'contrast': len(feat['contrast_points'])}


def task_text():
    vocab = 26
    topics = {
        'tech': [3,1,3,2,5,1,2,3,3,1,2,3,2,3,3,2,1,2,2,3,2,1,1,1,2,1],
        'sports': [3,1,1,1,3,1,1,1,3,1,1,1,2,3,3,2,1,2,3,3,1,1,1,1,1,1],
        'food': [3,1,1,3,2,3,1,1,2,1,1,1,1,2,3,1,1,1,2,3,1,1,1,1,1,1],
        'nature': [2,1,2,1,3,2,1,2,1,3,2,1,2,1,3,1,2,1,2,1,3,2,1,2,1,2],
    }
    def make_doc(topic, length=200):
        w = topics[topic]
        total = sum(w)
        freq = [0.0] * vocab
        for _ in range(length):
            r = random.random()
            cum = 0
            for idx, p in enumerate([x / total for x in w]):
                cum += p
                if r <= cum: freq[idx] += 1; break
        s = sum(freq)
        return [f / s for f in freq]
    tpl_feats = {}
    for topic in topics:
        doc = make_doc(topic, 300)
        # Add frequency variance as discriminative feature
        fv = sum((x - sum(doc)/len(doc))**2 for x in doc) / len(doc)
        tpl_feats[topic] = {'raw': doc, 'variance': [fv] * 10, 'contrast_points': []}
    correct = 0
    total = 0
    for true_t in topics:
        for _ in range(10):
            doc = make_doc(true_t, 150)
            fv = sum((x - sum(doc)/len(doc))**2 for x in doc) / len(doc)
            feat = {'raw': doc, 'variance': [fv] * 10, 'contrast_points': []}
            label, _, _ = Decision.classify(feat, tpl_feats)
            if label == true_t: correct += 1
            total += 1
    return {'accuracy': correct / total, 'total': total}


def task_reconstruction():
    random.seed(789)
    h, w = 16, 16
    image = []
    for i in range(h):
        row = []
        for j in range(w):
            val = 128 + 40 * math.sin(i * 0.3) + 30 * math.cos(j * 0.25) + random.gauss(0, 3)
            row.append(max(0, min(255, val)))
        image.append(row)
    flat = [x for row in image for x in row]
    feat = Perception.extract_1d(flat, 5)
    feat_2d = Perception.extract_2d(image, 3)
    # Structure-aware reconstruction
    recon_flat = Generation.reconstruct_1d_structure(feat, len(flat))
    recon_2d = [recon_flat[i * w:(i + 1) * w] for i in range(h)]
    sim = cos(flat, recon_flat)
    mse = sum((a - b) ** 2 for a, b in zip(flat, recon_flat)) / len(flat)
    psnr = 10 * math.log10(255 ** 2 / mse) if mse > 0 else 100
    recon_feat = Perception.extract_2d(recon_2d, 3)
    retention = (len(set(feat_2d['contrast_points']) & set(recon_feat['contrast_points'])) /
                 max(len(feat_2d['contrast_points']), 1))
    # Also measure: how much of original variance is preserved
    orig_var = sum((x - sum(flat)/len(flat))**2 for x in flat) / len(flat)
    recon_var = sum((x - sum(recon_flat)/len(recon_flat))**2 for x in recon_flat) / len(recon_flat)
    var_preservation = min(recon_var / orig_var, 1.0) if orig_var > 0 else 0
    return {'cosine': sim, 'psnr_db': psnr, 'contrast_retention': retention,
            'variance_preservation': var_preservation, 'mse': mse}


def task_bandit():
    random.seed(999)
    n_arms, n_rounds = 5, 100
    true_probs = [0.2, 0.5, 0.8, 0.3, 0.6]
    history = {i: [] for i in range(n_arms)}
    n_pulls = [0] * n_arms
    rewards, selections = [], []
    for rnd in range(n_rounds):
        feats = []
        for arm in range(n_arms):
            h = history[arm]
            if h:
                m = sum(h) / len(h)
                v = sum((x - m)**2 for x in h) / len(h)
            else:
                m, v = 0.5, 0.25
            feats.append([m, v, 0])
        chosen = Decision.bandit_ucb(feats, n_pulls, rnd, explore=15, c=0.3)
        reward = 1 if random.random() < true_probs[chosen] else 0
        history[chosen].append(reward)
        n_pulls[chosen] += 1
        rewards.append(reward)
        selections.append(chosen)
    total = sum(rewards)
    optimal = true_probs.index(max(true_probs))
    return {'avg_reward': total/n_rounds, 'optimal_pulls': selections.count(optimal),
            'regret': max(true_probs)*n_rounds - total, 'true_probs': true_probs}


if __name__ == '__main__':
    print("=" * 70)
    print("PGD FULL-CHAIN v3 - Final Generalization")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Digit Recognition")
    r = task_digit()
    results['digit'] = r
    print(f"  Std={r['standard']:.1%}, Shift={r['shift']:.1%}, PGD={r['pgd']:.1%}")

    print("\n[2] Digit Generation (structure-guided)")
    r = task_generation()
    results['generation'] = r
    print(f"  Total={r['total']}, Valid={r['valid']}, HighQ={r['high_quality']}, AvgSim={r['avg_sim']:.3f}")
    print(f"  Best: sources={r['best']['sources']}, sim={r['best']['max_sim']:.3f}, classified={r['best']['classified']}")

    print("\n[3] Anomaly Detection")
    r = task_anomaly()
    results['anomaly'] = r
    print(f"  P={r['precision']:.3f}, R={r['recall']:.3f}, F1={r['f1']:.3f}")

    print("\n[4] Text Classification")
    r = task_text()
    results['text'] = r
    print(f"  Acc={r['accuracy']:.1%}")

    print("\n[5] Image Reconstruction (structure-aware)")
    r = task_reconstruction()
    results['reconstruction'] = r
    print(f"  Cos={r['cosine']:.4f}, PSNR={r['psnr_db']:.2f}dB, "
          f"ContrastRet={r['contrast_retention']:.1%}, VarPres={r['variance_preservation']:.1%}")

    print("\n[6] Multi-Armed Bandit (tuned UCB)")
    r = task_bandit()
    results['bandit'] = r
    print(f"  AvgReward={r['avg_reward']:.3f}, OptPulls={r['optimal_pulls']}/100, Regret={r['regret']:.1f}")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.2f}s")

    # Load v1, v2 for full comparison
    base = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(base, "pgd_round1_results.json")) as f:
        r1 = json.load(f)['results']
    with open(os.path.join(base, "pgd_round2_results.json")) as f:
        r2 = json.load(f)['results']

    print("\n" + "=" * 70)
    print("FULL 3-ROUND COMPARISON")
    print("=" * 70)
    comps = [
        ('Digit PGD', 'pgd', 'digit'),
        ('Gen AvgSim', 'avg_sim', 'generation'),
        ('Anomaly F1', 'f1', 'anomaly'),
        ('Text Acc', 'accuracy', 'text'),
        ('Recon PSNR', 'psnr_db', 'reconstruction'),
        ('Bandit Reward', 'avg_reward', 'bandit'),
    ]
    print(f"\n  {'Task':<18} {'v1':>8} {'v2':>8} {'v3':>8} {'v1->v3':>8}")
    print("  " + "-" * 54)
    for name, key, task in comps:
        v1 = r1.get(task, {}).get(key, 0)
        v2 = r2.get(task, {}).get(key, 0)
        v3 = results.get(task, {}).get(key, 0)
        print(f"  {name:<18} {v1:>7.3f} {v2:>7.3f} {v3:>7.3f} {v3-v1:>+7.3f}")

    out = os.path.join(base, "pgd_round3_results.json")
    with open(out, 'w') as f:
        json.dump({'results': results, 'v1': r1, 'v2': r2}, f, indent=2, default=str)
    print(f"\nv3 saved: {out}")
    print("\n✅ PGD v3 complete - full chain validated.")
