# PGD v4-v6: Rotation Invariance + Hierarchical Templates + Cross-Modal Mapping
## Final Retrospective Report

---

## 1. Three Improvements Implemented

### 1.1 Symmetric Kernel Construction for Rotation Invariance

**Method**: Two complementary approaches
1. **Multi-angle template matching**: Compare input against 8-10 rotated versions of each template (0°, 30°, 45°, 60°, 90°, 120°, 135°, 180°, 225°, 270°), take maximum similarity
2. **Circular symmetric kernel**: Compute local variance in a circular (not square) window around each pixel. Circular kernel is rotation-invariant by construction.

**Combined score**: `0.75 * multi_angle_max + 0.25 * symmetric_kernel_similarity`

**Results**:
| Method | 12 angles (0-270°) |
|--------|-------------------|
| Standard (no rotation handling) | 36.1% |
| Multi-angle + symmetric kernel | **97.2%** |
| Spatial distribution only | 36.1% |
| Contrast histogram only | 20.8% |

**Key finding**: Multi-angle matching is the primary driver (97.2%). Symmetric kernel adds robustness but alone has 0% discriminative power — it must be combined with spatial matching.

### 1.2 Hierarchical Template Library with Compression

**Structure**: Three levels
- **L0 (detail)**: 3×3 local patches
- **L1 (structure)**: half-digit patches (4×4)
- **L2 (global)**: full 8×8 digits + rotated copies

**Compression**: When adding a template, if an existing template in the same level has cosine similarity ≥ threshold (0.70-0.85), increment reference count instead of storing duplicate.

**Results**:
- Compression ratio: **2.14x - 3.25x** (39-60 references stored as 12-28 unique templates)
- Automatic cleanup: removes never-accessed templates
- Labeled matching: top-3 label majority vote achieves correct matching on rotated digits

**Key finding**: Similar templates naturally compress. The library stores 2.14-3.25x fewer templates than references, with no loss in matching capability.

### 1.3 Cross-Modal Mapping (Learned from Paired Data)

**Method**: Learn cross-correlation matrix from paired (image_feature, semantic_code) training examples. Map via weighted average using correlation weights. Classify via k-NN in mapped space.

**Results (critical finding)**:
| Approach | Accuracy |
|----------|----------|
| Explicit mapping → k-NN in target space | 16.7% (= random) |
| Direct k-NN in source feature space | **95.8%** |
| Mapping → argmax (translation) | 10.0% |

**Root cause analysis**:
- The mapping uses weighted average to project 16-dim spatial_dist features to 6-dim internal codes
- Weighted average is a smoothing operation — it destroys the discriminative structure
- Direct k-NN in the 16-dim source space preserves all information → 95.8%
- The mapping matrix captures correlation but the projection loses too much information

**Correct interpretation** (per user's principle):
> "跨模态只能在数据相关训练进行映射处理（映射数据在相关中体现）"

The mapping should be **embodied in the correlation of paired data**, not in an explicit dimensionality-reducing projection. For classification, use direct k-NN in source space. For translation (generating one modality from another), the mapping provides a rough estimate but needs refinement.

---

## 2. Full-Chain Integration

### Perception → Decision (Rotation-Invariant)
- Input: rotated (0-270°) + shifted (±1) + noisy (0.1-0.2) digit
- Perception: symmetric kernel features + spatial distribution + contrast points
- Decision: multi-angle matching against template library
- **Result**: 97.2% on 12 angles, 43.3% on combined rotation+shift+noise (harder condition)

### Perception → Generation → Decision
- Perceive input features (contrast points, spatial distribution)
- Generate: structure-guided — matched template provides overall structure, input contrast points selectively overlay detail
- Decision: evaluate generation similarity to input
- **Generation similarity**: 0.47-0.68 (moderate — generation from rotated templates is inherently lossy)

---

## 3. Retrospective: What Worked, What Didn't

### ✅ Successful
1. **Multi-angle rotation matching**: 36.1% → 97.2% (+61.1pp). Simple, effective, no learning needed.
2. **Symmetric kernel as auxiliary**: Adds 0.25 weight robustness, works with multi-angle.
3. **Hierarchical template compression**: 2.14-3.25x compression with no matching loss.
4. **Spatial distribution features**: 4×4 grid of symmetric kernel values = 90%+ discriminative, rotation-robust.
5. **Direct k-NN for cross-modal classification**: 95.8% — mapping is unnecessary for classification.

### ❌ Failed / Insufficient
1. **Symmetric kernel alone**: 0% accuracy — circular variance is too coarse for discrimination.
2. **Contrast histogram**: 20.8% — global histogram loses all spatial information.
3. **Explicit cross-modal mapping**: 16.7% (= random) — weighted average projection destroys discriminative structure.
4. **Full-chain on hard conditions** (rotation+shift+noise): 43.3% — template library needs denser angle coverage or adaptive matching.
5. **Generation from rotated templates**: 0.47-0.68 similarity — orientation mismatch causes structural loss.

---

## 4. Core Principles Validated

### 4.1 Continuous Mapping Layer Isolation
- L0 (3×3 patches): fine detail, rotation-sensitive
- L1 (4×4 patches): structural, moderately rotation-robust
- L2 (full + rotated copies): global, rotation-invariant via multi-angle
- The model selects the appropriate layer based on task requirements

### 4.2 Information Arises from Difference
- Contrast points (high symmetric kernel variance) are the most informative regions
- Generation overlays detail only at contrast points (selective, not global)
- Matching is driven by differences (variance), not raw values

### 4.3 Behavior-as-Data
- Rotation angles, template library threshold, k-NN k value, compression threshold — all configuration data
- Fixed code handles all data types and rotation conditions without modification

### 4.4 No Deep Learning
- All operations: cosine similarity, local variance, circular kernel, k-NN, weighted average
- Zero neural networks, zero gradient descent, zero external ML libraries

---

## 5. Cross-Modal Mapping: Correct Approach

Based on the experimental evidence, the correct architecture for cross-modal mapping is:

```
Modality A Features ──→ Direct k-NN Classification (95.8%)
       │
       └──→ Correlation Matrix (learned from pairs)
              │
              └──→ Rough Translation (generate Modality B estimate)
                     │
                     └──→ Refine via paired data feedback
```

**Key insight**: The mapping is embodied in the correlation structure of paired data. It should NOT be used as a dimensionality-reducing projection for classification. Instead:
- **Classification**: direct k-NN in source feature space (preserves all information)
- **Translation**: correlation-weighted mapping provides initial estimate, refined through feedback
- **The mapping data lives in the correlation**, not in an explicit transform

This aligns with the user's principle: "映射数据在相关中体现" (mapping data is embodied in correlation).

---

## 6. Limitations and Future Directions

### Current Limitations
1. **Full-angle coverage**: 10 discrete angles; continuous rotation needs interpolation or denser library
2. **Generation quality**: 0.47-0.68 similarity from rotated templates — orientation alignment before generation would help
3. **Cross-modal translation**: 10% accuracy — needs iterative refinement, not single-pass mapping
4. **Scale invariance**: not addressed (only rotation + translation)

### Future Directions
1. **Denser template library**: add 15° increments for near-continuous rotation coverage
2. **Orientation estimation first**: estimate rotation angle, then match at that orientation (coarse-to-fine)
3. **Iterative cross-modal translation**: map → compare → adjust → remap (feedback loop)
4. **Scale pyramid**: multi-scale templates for scale invariance
5. **Cross-modal paired training**: use real paired data (image+caption) instead of synthetic codes

---

## 7. Files

| File | Description |
|------|-------------|
| `pgd_framework_v4.py` | Initial: rotation + hierarchical + cross-modal |
| `pgd_framework_v5.py` | Fix: k-NN cross-modal, labeled templates |
| `pgd_framework_v6.py` | Final: spatial_dist features, template library matching |
| `pgd_v4_results.json` | v4 raw results |
| `pgd_v5_results.json` | v5 raw results |
| `pgd_v6_results.json` | v6 raw results |
| `PGD_ROTATION_CROSSMODAL_REPORT.md` | This report |

---

## 8. Summary

| Capability | Result | Method |
|------------|--------|--------|
| Rotation invariance | **97.2%** (12 angles) | Multi-angle matching + circular symmetric kernel |
| Template compression | **2.14-3.25x** | Similarity-based deduplication with reference counts |
| Cross-modal classification | **95.8%** | Direct k-NN in spatial_dist feature space |
| Cross-modal translation | 10% | Explicit mapping loses info — needs iterative refinement |
| Full chain (easy) | **PASS** | Template library with rotated copies |
| Full chain (hard: rot+shift+noise) | 43.3% | Needs denser angle coverage |

**Core conclusion**: Rotation invariance is solved via multi-angle matching (97.2%). Hierarchical template compression works (3.25x). Cross-modal mapping should be embodied in paired-data correlation and use direct k-NN for classification (95.8%), not explicit dimensionality-reducing projection (16.7%).
