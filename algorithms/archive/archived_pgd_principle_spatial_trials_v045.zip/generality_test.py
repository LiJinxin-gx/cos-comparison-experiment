"""
cos-comparison v0.4.4 - Multi-Task Generality Test
Test enhanced principles (Direction + Strength + Synthesis) across 8 domains.
Each task: standard method vs enhanced method comparison.
No formal code modified.
"""
import os
import time
import math
import json
import random

random.seed(2024)

from cos_comparison.core import (
    cos, cos_comparison_passive, cos_comparison_active,
    mean_local, local_variance,
    threshold_filter, threshold_map,
    vector_map_as_tensor,
)

print("=" * 70)
print("Multi-Task Generality Test - Enhanced Principles")
print("=" * 70)

results = {}

# ============================================================
# Enhanced recognition utility (Direction + Strength + Synthesis)
# ============================================================
def enhanced_match(vec1, vec2, shifts=(-1, 0, 1)):
    """Enhanced matching: multi-direction shift search + best alignment."""
    best_score = -1
    n = min(len(vec1), len(vec2))
    for dx in shifts:
        for dy in shifts:
            # For 1D, shift is along single axis
            shifted = []
            for i in range(n):
                j = i + dx
                if 0 <= j < len(vec2):
                    shifted.append(vec2[j])
                else:
                    shifted.append(0.0)
            score = cos(vec1[:n], shifted[:n])
            if score > best_score:
                best_score = score
    return best_score

def enhanced_match_2d(img1, img2, shifts=(-1, 0, 1)):
    """Enhanced 2D matching with spatial shift search."""
    best_score = -1
    h = min(len(img1), len(img2))
    w = min(len(img1[0]) if img1 else 0, len(img2[0]) if img2 else 0)
    for dy in shifts:
        for dx in shifts:
            flat1 = []
            flat2 = []
            for i in range(h):
                for j in range(w):
                    flat1.append(img1[i][j])
                    ni, nj = i + dy, j + dx
                    if 0 <= ni < len(img2) and 0 <= nj < len(img2[0]):
                        flat2.append(img2[ni][nj])
                    else:
                        flat2.append(0.0)
            score = cos(flat1, flat2)
            if score > best_score:
                best_score = score
    return best_score

# ============================================================
# Task 1: Digit Recognition (Image/Pattern)
# ============================================================
print("\n[Task 1] Digit Recognition (Pattern Matching)")

def make_digit(d, noise=0.15, shift=(0,0)):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),
            (4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),
            (6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),
            (4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),
            (5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),
            (4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        6: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),
            (4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        7: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,5),(3,4),(4,3),(5,2),(6,1)],
        8: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,2),(3,3),(3,4),(3,5),(3,6),
            (4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        9: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,2),(3,3),(3,4),(3,5),(3,6),
            (4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r + shift[0], c + shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8:
            grid[nr][nc] = 1.0
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

templates = {d: make_digit(d, noise=0) for d in range(10)}

std_correct = 0
enh_correct = 0
total = 0
t0 = time.time()
for true_d in range(10):
    for _ in range(5):
        noise = random.uniform(0.1, 0.3)
        shift = (random.randint(-1,1), random.randint(-1,1))
        test = make_digit(true_d, noise=noise, shift=shift)
        
        # Standard
        best_d, best_s = -1, -1
        for d, tpl in templates.items():
            f1 = [x for row in test for x in row]
            f2 = [x for row in tpl for x in row]
            s = cos(f1, f2)
            if s > best_s:
                best_s, best_d = s, d
        if best_d == true_d: std_correct += 1
        
        # Enhanced
        best_d, best_s = -1, -1
        for d, tpl in templates.items():
            s = enhanced_match_2d(test, tpl)
            if s > best_s:
                best_s, best_d = s, d
        if best_d == true_d: enh_correct += 1
        total += 1

t1 = time.time()
print(f"  Standard: {std_correct}/{total} = {std_correct/total*100:.1f}%")
print(f"  Enhanced: {enh_correct}/{total} = {enh_correct/total*100:.1f}%")
print(f"  Gain: {(enh_correct-std_correct)/total*100:+.1f}pp, Time: {t1-t0:.4f}s")
results['digit'] = {'std': std_correct/total, 'enh': enh_correct/total, 'gain': (enh_correct-std_correct)/total}

# ============================================================
# Task 2: Time Series Anomaly Detection
# ============================================================
print("\n[Task 2] Time Series Anomaly Detection")

baseline = [math.sin(i*0.1) + 0.5*math.sin(i*0.3) for i in range(300)]
test_ts = baseline[:]
anomaly_pos = [40, 100, 160, 220, 280]
labels = [0]*300
for pos in anomaly_pos:
    for off in range(-2,3):
        idx = pos+off
        if 0 <= idx < 300:
            test_ts[idx] += random.choice([-1,1])*random.uniform(0.7,1.2)
            labels[idx] = 1

# Standard: cos similarity threshold
t0 = time.time()
std_det = []
for i in range(0, 280):
    w = test_ts[i:i+20]
    b = baseline[i:i+20]
    if cos(w, b) < 0.8:
        std_det.append(i+10)

# Enhanced: variance + difference + adaptive threshold
var = local_variance(test_ts, local_size=(5,))
diff = [abs(test_ts[i]-test_ts[i-1]) for i in range(1,300)]
diff_var = local_variance(diff, local_size=(5,))
var_sorted = sorted(var)
thresh = var_sorted[int(len(var_sorted)*0.9)]
enh_det = [i+2 for i in range(len(var)) if var[i] > thresh or (i < len(diff_var) and diff_var[i] > thresh*0.5)]
t1 = time.time()

def evaluate(detections, labels, tol=3):
    true_set = set(i for i,l in enumerate(labels) if l==1)
    tp = sum(1 for d in detections if any(abs(d-t)<=tol for t in true_set))
    fp = len(detections)-tp
    fn = sum(1 for t in true_set if not any(abs(d-t)<=tol for d in detections))
    p = tp/(tp+fp) if tp+fp else 0
    r = tp/(tp+fn) if tp+fn else 0
    f1 = 2*p*r/(p+r) if p+r else 0
    return p, r, f1

sp, sr, sf1 = evaluate(std_det, labels)
ep, er, ef1 = evaluate(enh_det, labels)
print(f"  Standard: P={sp:.3f}, R={sr:.3f}, F1={sf1:.3f} ({len(std_det)} det)")
print(f"  Enhanced: P={ep:.3f}, R={er:.3f}, F1={ef1:.3f} ({len(enh_det)} det)")
print(f"  F1 gain: {ef1-sf1:+.3f}, Time: {t1-t0:.4f}s")
results['anomaly'] = {'std_f1': sf1, 'enh_f1': ef1, 'gain': ef1-sf1}

# ============================================================
# Task 3: Text Topic Classification
# ============================================================
print("\n[Task 3] Text Topic Classification")

vocab = 26
topics = {
    'tech': [3,1,3,2,5,1,2,3,3,1,2,3,2,3,3,2,1,2,2,3,2,1,1,1,2,1],
    'sports': [3,1,1,1,3,1,1,1,3,1,1,1,2,3,3,2,1,2,3,3,1,1,1,1,1,1],
    'food': [3,1,1,3,2,3,1,1,2,1,1,1,1,2,3,1,1,1,2,3,1,1,1,1,1,1],
    'general': [1]*26,
}

def make_doc(topic, length=150):
    w = topics[topic]
    total = sum(w)
    freq = [0.0]*vocab
    for _ in range(length):
        r = random.random()
        cum = 0
        for idx, p in enumerate([x/total for x in w]):
            cum += p
            if r <= cum:
                freq[idx] += 1
                break
    s = sum(freq)
    return [f/s for f in freq]

corpus = {t: [make_doc(t) for _ in range(3)] for t in topics}

std_correct = 0
enh_correct = 0
total = 0
t0 = time.time()
for true_t in topics:
    for _ in range(10):
        query = make_doc(true_t)
        # Standard
        best_t, best_s = None, -1
        for t, docs in corpus.items():
            for d in docs:
                s = cos(query, d)
                if s > best_s:
                    best_s, best_t = s, t
        if best_t == true_t: std_correct += 1
        
        # Enhanced: multi-scale (different length normalization) + best of 3
        best_t, best_s = None, -1
        for t, docs in corpus.items():
            for d in docs:
                # Direction: test with slight perturbation (simulate shift in freq space)
                s = enhanced_match(query, d, shifts=(-1,0,1))
                if s > best_s:
                    best_s, best_t = s, t
        if best_t == true_t: enh_correct += 1
        total += 1

t1 = time.time()
print(f"  Standard: {std_correct}/{total} = {std_correct/total*100:.1f}%")
print(f"  Enhanced: {enh_correct}/{total} = {enh_correct/total*100:.1f}%")
print(f"  Gain: {(enh_correct-std_correct)/total*100:+.1f}pp, Time: {t1-t0:.4f}s")
results['text'] = {'std': std_correct/total, 'enh': enh_correct/total, 'gain': (enh_correct-std_correct)/total}

# ============================================================
# Task 4: Audio Tone Recognition
# ============================================================
print("\n[Task 4] Audio Tone Recognition")

def make_tone(freq, sr=100, dur=1.0):
    n = int(dur*sr)
    return [math.sin(2*math.pi*freq*i/sr) for i in range(n)]

freqs = [5, 10, 15, 20, 25]
tone_tpl = {f: make_tone(f) for f in freqs}

std_correct = 0
enh_correct = 0
total = 0
t0 = time.time()
for true_f in freqs:
    for noise in [0.05, 0.15, 0.3]:
        for _ in range(3):
            sig = make_tone(true_f)
            sig = [s + random.gauss(0, noise) for s in sig]
            other = random.choice([f for f in freqs if f != true_f])
            sig = [s + 0.2*t for s,t in zip(sig, make_tone(other))]
            
            # Standard: single-scale mean
            best_f, best_s = -1, -1
            for f, tpl in tone_tpl.items():
                f1 = mean_local(sig, local_size=(10,))
                f2 = mean_local(tpl, local_size=(10,))
                ml = min(len(f1), len(f2))
                s = cos(f1[:ml], f2[:ml])
                if s > best_s:
                    best_s, best_f = s, f
            if best_f == true_f: std_correct += 1
            
            # Enhanced: multi-scale fusion
            best_f, best_s = -1, -1
            for f, tpl in tone_tpl.items():
                scores = []
                for ws in [5, 10, 20]:
                    f1 = mean_local(sig, local_size=(ws,))
                    f2 = mean_local(tpl, local_size=(ws,))
                    ml = min(len(f1), len(f2))
                    scores.append(cos(f1[:ml], f2[:ml]))
                s = sum(scores)/len(scores)  # Synthesis: average across scales
                if s > best_s:
                    best_s, best_f = s, f
            if best_f == true_f: enh_correct += 1
            total += 1

t1 = time.time()
print(f"  Standard: {std_correct}/{total} = {std_correct/total*100:.1f}%")
print(f"  Enhanced: {enh_correct}/{total} = {enh_correct/total*100:.1f}%")
print(f"  Gain: {(enh_correct-std_correct)/total*100:+.1f}pp, Time: {t1-t0:.4f}s")
results['audio'] = {'std': std_correct/total, 'enh': enh_correct/total, 'gain': (enh_correct-std_correct)/total}

# ============================================================
# Task 5: User Recommendation
# ============================================================
print("\n[Task 5] User-Item Recommendation")

n_users, n_items = 25, 30
user_types = [[0.8,0.2,0.5,0.9,0.1],[0.2,0.9,0.8,0.1,0.7],[0.5,0.5,0.5,0.5,0.5]]
users = []
for i in range(n_users):
    ut = user_types[i%3]
    users.append([max(0,min(1,ut[j%5]+random.gauss(0,0.15))) for j in range(n_items)])

std_prec = 0
enh_prec = 0
total = 0
t0 = time.time()
for uid in range(n_users):
    known = users[uid][:n_items-5]
    hidden = users[uid][n_items-5:]
    
    # Standard: find most similar user
    best_u, best_s = -1, -1
    for oid in range(n_users):
        if oid == uid: continue
        s = cos(known, users[oid][:n_items-5])
        if s > best_s:
            best_s, best_u = s, oid
    
    recs = users[best_u][n_items-5:]
    tp = sum(1 for i in range(5) if recs[i]>0.5 and hidden[i]>0.5)
    fp = sum(1 for i in range(5) if recs[i]>0.5 and hidden[i]<=0.5)
    std_prec += tp/(tp+fp) if tp+fp else 0
    
    # Enhanced: multi-direction (test partial known subsets) + ensemble
    scores = []
    for oid in range(n_users):
        if oid == uid: continue
        # Direction: test multiple partial views
        s_list = []
        for start in [0, 5, 10]:
            end = start + 15
            if end <= len(known):
                s_list.append(cos(known[start:end], users[oid][start:end]))
        s = max(s_list) if s_list else 0
        scores.append((s, oid))
    scores.sort(reverse=True)
    # Ensemble top 3
    recs = [0.0]*5
    for s, oid in scores[:3]:
        for i in range(5):
            recs[i] += users[oid][n_items-5+i] * s
    recs = [r/3 for r in recs]
    tp = sum(1 for i in range(5) if recs[i]>0.5 and hidden[i]>0.5)
    fp = sum(1 for i in range(5) if recs[i]>0.5 and hidden[i]<=0.5)
    enh_prec += tp/(tp+fp) if tp+fp else 0
    total += 1

t1 = time.time()
print(f"  Standard precision: {std_prec/total*100:.1f}%")
print(f"  Enhanced precision: {enh_prec/total*100:.1f}%")
print(f"  Gain: {(enh_prec-std_prec)/total*100:+.1f}pp, Time: {t1-t0:.4f}s")
results['recommendation'] = {'std': std_prec/total, 'enh': enh_prec/total, 'gain': (enh_prec-std_prec)/total}

# ============================================================
# Task 6: Multi-Sensor Event Detection
# ============================================================
print("\n[Task 6] Multi-Sensor Event Detection")

n_sensors, n_samples = 4, 250
event_start, event_end = 80, 110
sensors = []
for s in range(n_sensors):
    bf = 0.1 + s*0.05
    data = [math.sin(i*bf)+random.gauss(0,0.1) for i in range(n_samples)]
    for i in range(event_start, event_end):
        data[i] += 0.5*math.sin((i-event_start)*0.3)
    sensors.append(data)

# Standard: independent threshold
t0 = time.time()
std_det = []
for s in sensors:
    var = local_variance(s, local_size=(5,))
    for i, v in enumerate(var):
        if v > 0.05:
            std_det.append(i)
std_det = sorted(set(std_det))

# Enhanced: cross-channel correlation
sensor_vars = [local_variance(s, local_size=(5,)) for s in sensors]
thresholds = [sorted(v)[int(len(v)*0.85)] for v in sensor_vars]
enh_det = []
for i in range(min(len(v) for v in sensor_vars)):
    active = sum(1 for j in range(n_sensors) if sensor_vars[j][i] > thresholds[j])
    if active >= 3:
        enh_det.append(i)
t1 = time.time()

# Evaluate (event is [80,110])
def eval_events(det, true_start, true_end, tol=5):
    tp = sum(1 for d in det if true_start-tol <= d <= true_end+tol)
    fp = len(det)-tp
    fn = 1 if tp == 0 else 0
    p = tp/(tp+fp) if tp+fp else 0
    r = 1.0 if tp > 0 else 0
    f1 = 2*p*r/(p+r) if p+r else 0
    return p, r, f1

sp, sr, sf1 = eval_events(std_det, event_start, event_end)
ep, er, ef1 = eval_events(enh_det, event_start, event_end)
print(f"  Standard: P={sp:.3f}, R={sr:.3f}, F1={sf1:.3f} ({len(std_det)} det)")
print(f"  Enhanced: P={ep:.3f}, R={er:.3f}, F1={ef1:.3f} ({len(enh_det)} det)")
print(f"  F1 gain: {ef1-sf1:+.3f}, Time: {t1-t0:.4f}s")
results['sensor'] = {'std_f1': sf1, 'enh_f1': ef1, 'gain': ef1-sf1}

# ============================================================
# Task 7: Image Compression Quality
# ============================================================
print("\n[Task 7] Image Compression & Reconstruction")

size = 24
original = []
for i in range(size):
    row = []
    for j in range(size):
        r = math.sqrt((i-12)**2+(j-12)**2)
        val = math.sin(r*0.3)*0.5+0.5+0.2*math.sin(i*0.5)*math.cos(j*0.3)
        row.append(max(0,min(1,val)))
    original.append(row)
flat_orig = [x for row in original for x in row]

# Standard: uniform quantization
t0 = time.time()
std_comp = [round(v/0.125)*0.125 for v in flat_orig]
std_mse = sum((a-b)**2 for a,b in zip(flat_orig, std_comp))/len(flat_orig)
std_psnr = 10*math.log10(1/std_mse) if std_mse > 0 else 100
std_cos = cos(flat_orig, std_comp)

# Enhanced: adaptive quantization (more levels in high-variance regions)
var_map = local_variance(original, local_size=(3,3))
enh_comp = []
for i in range(size):
    for j in range(size):
        v = original[i][j]
        # Strength: adaptive step based on local variance
        vi, vj = min(i, len(var_map)-1), min(j, len(var_map[0])-1)
        local_var = var_map[vi][vj]
        step = 0.0625 if local_var > 0.01 else 0.25  # Fine in detailed areas
        enh_comp.append(round(v/step)*step)
enh_mse = sum((a-b)**2 for a,b in zip(flat_orig, enh_comp))/len(flat_orig)
enh_psnr = 10*math.log10(1/enh_mse) if enh_mse > 0 else 100
enh_cos = cos(flat_orig, enh_comp)

# Count unique values (compression ratio)
std_unique = len(set(std_comp))
enh_unique = len(set(enh_comp))
t1 = time.time()

print(f"  Standard: PSNR={std_psnr:.2f}dB, cos={std_cos:.4f}, levels={std_unique}")
print(f"  Enhanced: PSNR={enh_psnr:.2f}dB, cos={enh_cos:.4f}, levels={enh_unique}")
print(f"  PSNR gain: {enh_psnr-std_psnr:+.2f}dB, Time: {t1-t0:.4f}s")
results['compression'] = {'std_psnr': std_psnr, 'enh_psnr': enh_psnr, 'gain': enh_psnr-std_psnr}

# ============================================================
# Task 8: DNA Motif Detection
# ============================================================
print("\n[Task 8: DNA Motif Detection]")

bases = ['A','T','G','C']
b2v = {'A':0.1,'T':0.4,'G':0.7,'C':1.0}
motif = "ATGCGATCG"
motif_vec = [b2v[b] for b in motif]

def make_dna(length, motif=None):
    seq = [random.choice(bases) for _ in range(length)]
    if motif:
        pos = random.randint(0, length-len(motif))
        for i,b in enumerate(motif):
            seq[pos+i] = b
    return seq

std_correct = 0
enh_correct = 0
total = 0
t0 = time.time()
for has_motif in [True, False]:
    for _ in range(15):
        seq = make_dna(80, motif if has_motif else None)
        seq_vec = [b2v[b] for b in seq]
        
        # Standard: sliding window cos
        best_s = 0
        for i in range(len(seq_vec)-len(motif_vec)):
            window = seq_vec[i:i+len(motif_vec)]
            s = cos(window, motif_vec)
            best_s = max(best_s, s)
        std_pred = best_s > 0.95
        
        # Enhanced: active mode template matching + multi-threshold
        seq_2d = [seq_vec]
        motif_2d = [motif_vec]
        try:
            active = cos_comparison_active(seq_2d, kernel=motif_2d)
            flat_a = [x for row in active for x in row]
            best_active = max(flat_a) if flat_a else 0
        except:
            best_active = 0
        # Synthesis: combine cos + active
        combined = max(best_s, best_active)
        enh_pred = combined > 0.90
        
        if std_pred == has_motif: std_correct += 1
        if enh_pred == has_motif: enh_correct += 1
        total += 1

t1 = time.time()
print(f"  Standard: {std_correct}/{total} = {std_correct/total*100:.1f}%")
print(f"  Enhanced: {enh_correct}/{total} = {enh_correct/total*100:.1f}%")
print(f"  Gain: {(enh_correct-std_correct)/total*100:+.1f}pp, Time: {t1-t0:.4f}s")
results['dna'] = {'std': std_correct/total, 'enh': enh_correct/total, 'gain': (enh_correct-std_correct)/total}

# ============================================================
# Summary
# ============================================================
print("\n" + "=" * 70)
print("GENERALITY TEST SUMMARY")
print("=" * 70)
print(f"\n{'Task':<25} {'Standard':>10} {'Enhanced':>10} {'Gain':>10}")
print("-" * 57)

gains = []
for task, r in results.items():
    if 'std' in r:
        std_v = r['std']*100
        enh_v = r['enh']*100
        gain = r['gain']*100
        print(f"{task:<25} {std_v:>9.1f}% {enh_v:>9.1f}% {gain:>+9.1f}%")
        gains.append(r['gain'])
    elif 'std_f1' in r:
        print(f"{task:<25} {r['std_f1']:>10.3f} {r['enh_f1']:>10.3f} {r['gain']:>+10.3f}")
        gains.append(r['gain'])
    elif 'std_psnr' in r:
        print(f"{task:<25} {r['std_psnr']:>9.2f}dB {r['enh_psnr']:>9.2f}dB {r['gain']:>+9.2f}dB")
        gains.append(r['gain']/r['std_psnr'])

avg_gain = sum(gains)/len(gains) if gains else 0
print(f"\nAverage gain: {avg_gain*100:+.1f}% (normalized)")
print(f"Tasks improved: {sum(1 for g in gains if g > 0)}/{len(gains)}")
print(f"Tasks unchanged: {sum(1 for g in gains if g == 0)}/{len(gains)}")
print(f"Tasks degraded: {sum(1 for g in gains if g < 0)}/{len(gains)}")

output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "generality_results.json")
with open(output_path, 'w') as f:
    json.dump(results, f, indent=2, default=str)
print(f"\nResults saved: {output_path}")
print("\n✅ Generality test complete!")
