"""
PGD v7: Feedback-driven contrast point discovery + pattern-based shift invariance.

Principles:
1. Feedback contrast points: extract candidates, then validate via matching feedback.
   Points that consistently contribute to correct matches are retained; noise points pruned.
   No hardcoded threshold - threshold is data-driven via percentile ranking.
2. No arbitrary weighting: similarity is pure cosine on aligned point sets.
   If any weighting is used, it has explicit mathematical meaning (e.g., inverse frequency).
3. Train/validate separation:
   - Train (know the world): store template contrast point patterns at multiple thresholds
   - Validate (discriminate/create): match input point pattern against stored patterns
4. Shift invariance: contrast point relative positions are shift-invariant.
   Find best translation by maximizing point-set overlap (no weighted sum).
"""
import os, time, math, json, random
from collections import defaultdict, Counter
from cos_comparison.core import cos, local_variance, mean_local

random.seed(42)

# ============================================================
# Utilities
# ============================================================
def rotate_2d(matrix, angle_deg):
    h, w = len(matrix), len(matrix[0])
    angle = math.radians(angle_deg)
    ca, sa = math.cos(angle), math.sin(angle)
    result = [[0.0]*w for _ in range(h)]
    cx, cy = w/2, h/2
    for i in range(h):
        for j in range(w):
            x, y = j-cx, i-cy
            sx = x*ca + y*sa + cx
            sy = -x*sa + y*ca + cy
            si, sj = int(round(sy)), int(round(sx))
            if 0 <= si < h and 0 <= sj < w:
                result[i][j] = matrix[si][sj]
    return result

def symmetric_kernel_variance(matrix, radius=1):
    h, w = len(matrix), len(matrix[0])
    result = [[0.0]*w for _ in range(h)]
    for i in range(h):
        for j in range(w):
            vals = []
            for di in range(-radius, radius+1):
                for dj in range(-radius, radius+1):
                    if di*di+dj*dj <= radius*radius:
                        ni, nj = i+di, j+dj
                        if 0 <= ni < h and 0 <= nj < w:
                            vals.append(matrix[ni][nj])
            if vals:
                m = sum(vals)/len(vals)
                result[i][j] = sum((v-m)**2 for v in vals)/len(vals)
    return result

# ============================================================
# Feedback-driven contrast point extractor
# ============================================================
class FeedbackContrastExtractor:
    """Extract contrast points via feedback, not hardcoded threshold.

    Method:
    1. Compute symmetric kernel variance (information density map)
    2. Rank all pixels by variance, take top-k percentile (data-driven, not fixed threshold)
    3. During training, validate each point's contribution via matching feedback
    4. Prune points that don't contribute to discrimination (low match contribution)

    Mathematical meaning: variance = local information content.
    Points with high variance = high information = good contrast points.
    Feedback validates: does this point actually help discriminate?
    """
    def __init__(self, percentile=70, min_points=4, max_points=20):
        self.percentile = percentile  # data-driven: top 30% by variance
        self.min_points = min_points
        self.max_points = max_points
        self.point_contribution = defaultdict(float)  # (i,j) -> cumulative contribution
        self.match_count = 0

    def extract_candidates(self, matrix):
        """Extract candidate contrast points by variance percentile (no hardcoded threshold)."""
        h, w = len(matrix), len(matrix[0])
        sk = symmetric_kernel_variance(matrix, 1)
        # Flatten and sort by variance (descending)
        scored = []
        for i in range(h):
            for j in range(w):
                scored.append((sk[i][j], i, j))
        scored.sort(reverse=True)
        # Take top percentile (data-driven threshold)
        n_take = max(self.min_points, min(self.max_points, int(len(scored) * (100 - self.percentile) / 100)))
        points = [(i, j) for _, i, j in scored[:n_take]]
        return points, sk

    def extract(self, matrix):
        """Extract contrast points (candidates, to be refined by feedback)."""
        points, _ = self.extract_candidates(matrix)
        return points

    def record_feedback(self, points, match_score, is_correct):
        """Record contribution of each point based on match outcome.

        Mathematical meaning: contribution = match_score if correct, -match_score if incorrect.
        Points that appear in correct matches accumulate positive contribution.
        Points that appear in incorrect matches accumulate negative contribution.
        """
        self.match_count += 1
        for p in points:
            self.point_contribution[p] += match_score if is_correct else -match_score

    def get_refined_points(self, matrix):
        """After feedback, extract points weighted by historical contribution.

        No arbitrary weighting: we simply re-rank candidates by
        (variance * (1 + normalized_contribution)).
        The contribution factor has clear meaning: points proven useful are prioritized.
        """
        candidates, sk = self.extract_candidates(matrix)
        if self.match_count == 0:
            return candidates  # no feedback yet, use raw variance ranking
        # Re-rank by variance * proven usefulness
        max_contrib = max(abs(v) for v in self.point_contribution.values()) or 1.0
        scored = []
        for (i, j) in candidates:
            variance = sk[i][j]
            contrib = self.point_contribution.get((i, j), 0.0) / max_contrib  # normalized to [-1, 1]
            # usefulness factor: [0, 2], mean=1 for unproven points
            usefulness = 1.0 + contrib * 0.5
            scored.append((variance * usefulness, i, j))
        scored.sort(reverse=True)
        return [(i, j) for _, i, j in scored[:len(candidates)]]

# ============================================================
# Pattern-based shift matching (no weighting, pure point-set overlap)
# ============================================================
def point_pattern_similarity(points_a, points_b, max_shift=2):
    """Match two point sets by finding best translation (shift invariance).

    Method: For each possible (dx, dy), count how many points in B align with A.
    Best shift = maximum overlap. Similarity = overlap / min(|A|, |B|).

    No weighting: pure count of aligned points. A point aligns if within 1 pixel
    (to account for rotation discretization).

    This is shift-invariant by construction: we search over all translations.
    """
    best_overlap = 0
    best_shift = (0, 0)
    set_a = set(points_a)
    for dx in range(-max_shift, max_shift + 1):
        for dy in range(-max_shift, max_shift + 1):
            shifted_b = set((i + dx, j + dy) for (i, j) in points_b)
            # Count overlap (within 1 pixel for robustness)
            overlap = 0
            for (ai, aj) in set_a:
                for di in range(-1, 2):
                    for dj in range(-1, 2):
                        if (ai + di, aj + dj) in shifted_b:
                            overlap += 1
                            break
                    else:
                        continue
                    break
            if overlap > best_overlap:
                best_overlap = overlap
                best_shift = (dx, dy)
    denom = min(len(points_a), len(points_b))
    similarity = best_overlap / denom if denom > 0 else 0.0
    return similarity, best_shift, best_overlap

def pattern_match_with_rotation(img_a, img_b, extractor, angles=(0, 30, 45, 60, 90, 120, 135, 180, 225, 270)):
    """Rotation + shift invariant matching via contrast point patterns.

    1. Extract contrast points from A
    2. For each rotation of B: extract points, find best shift alignment
    3. Score = pattern similarity (point overlap ratio)
    4. Also compute pixel cosine at best alignment for combined score

    Combined score: 0.5 * pattern_sim + 0.5 * pixel_cos_at_best_alignment
    Both components have clear meaning: pattern_sim = structural agreement,
    pixel_cos = intensity agreement. No arbitrary weighting beyond equal fusion.
    """
    points_a = extractor.extract(img_a)
    best_score = -1
    best_angle = 0
    best_shift = (0, 0)
    best_pat_sim = 0
    best_pix_cos = 0
    h, w = len(img_a), len(img_a[0])

    for angle in angles:
        rotated_b = rotate_2d(img_b, angle)
        points_b = extractor.extract(rotated_b)
        pat_sim, shift, overlap = point_pattern_similarity(points_a, points_b, max_shift=2)
        # Pixel cosine at best shift alignment
        dx, dy = shift
        aligned_flat = []
        input_flat = []
        for i in range(h):
            for j in range(w):
                bi, bj = i - dx, j - dy
                if 0 <= bi < h and 0 <= bj < w:
                    aligned_flat.append(rotated_b[bi][bj])
                    input_flat.append(img_a[i][j])
        if len(aligned_flat) > 0:
            try: pix_cos = cos(input_flat, aligned_flat)
            except: pix_cos = 0.0
        else:
            pix_cos = 0.0
        # Equal fusion: both components equally meaningful
        score = 0.5 * pat_sim + 0.5 * pix_cos
        if score > best_score:
            best_score = score
            best_angle = angle
            best_shift = shift
            best_pat_sim = pat_sim
            best_pix_cos = pix_cos
    return best_score, best_angle, best_shift, best_pat_sim, best_pix_cos

# ============================================================
# Train/Validate separated framework
# ============================================================
class PatternRecognizer:
    """Train (know the world) then validate (discriminate).

    Train phase: store template contrast point patterns + raw templates.
    Validate phase: match input pattern against stored patterns via rotation+shift search.
    Feedback: after validation, record point contributions to refine extraction.
    """
    def __init__(self):
        self.extractor = FeedbackContrastExtractor(percentile=70)
        self.templates = {}  # label -> (matrix, contrast_points)
        self.angles = (0, 30, 45, 60, 90, 120, 135, 180, 225, 270)

    def train(self, label, matrix):
        """Store template pattern (know the world)."""
        points = self.extractor.extract(matrix)
        self.templates[label] = (matrix, points)

    def validate(self, matrix, return_details=False):
        """Match input against all templates (discriminate)."""
        scores = []
        for label, (tpl, _) in self.templates.items():
            score, angle, shift, pat_sim, pix_cos = pattern_match_with_rotation(
                matrix, tpl, self.extractor, self.angles)
            scores.append((label, score, angle, shift, pat_sim, pix_cos))
        scores.sort(key=lambda x: x[1], reverse=True)
        if return_details:
            return scores
        return scores[0][0], scores[0][1]

    def feedback(self, matrix, predicted_label, correct_label):
        """Record feedback to refine contrast point extraction."""
        points = self.extractor.extract(matrix)
        is_correct = (predicted_label == correct_label)
        self.extractor.record_feedback(points, 1.0 if is_correct else 0.5, is_correct)

# ============================================================
# Digit generator
# ============================================================
def make_digit(d, noise=0.15, shift=(0,0), rotation=0):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r+shift[0], c+shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    if rotation != 0: grid = rotate_2d(grid, rotation)
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

# ============================================================
# TASKS
# ============================================================
def task_rotation_shift():
    """Test rotation + shift invariance with feedback pattern matching."""
    recognizer = PatternRecognizer()
    for d in range(6):
        recognizer.train(d, make_digit(d, 0))

    # Phase 1: Initial validation (no feedback)
    print("  Phase 1: No feedback (initial)")
    conditions = [
        ('rot only', 0.1, 'random', (0,0)),
        ('shift only', 0.1, 0, 'random'),
        ('rot+shift', 0.1, 'random', 'random'),
        ('rot+shift+noise0.15', 0.15, 'random', 'random'),
    ]
    results = {}
    for name, noise, rot, shift in conditions:
        correct = 0
        total = 0
        for true_d in range(6):
            for _ in range(5):
                r = random.choice([0,30,45,60,90,120,135,180,225,270]) if rot=='random' else rot
                s = (random.randint(-1,1), random.randint(-1,1)) if shift=='random' else shift
                test = make_digit(true_d, noise=noise, rotation=r, shift=s)
                pred, _ = recognizer.validate(test)
                if pred == true_d: correct += 1
                total += 1
        results[name] = correct / total
        print(f"    {name:25s}: {correct/total:.1%} ({correct}/{total})")

    # Phase 2: Feedback training (know the world through validation)
    print("  Phase 2: With feedback (50 training rounds)")
    for _ in range(50):
        for true_d in range(6):
            r = random.choice([0,30,45,60,90,120,135,180,225,270])
            s = (random.randint(-1,1), random.randint(-1,1))
            test = make_digit(true_d, noise=0.12, rotation=r, shift=s)
            pred, score = recognizer.validate(test)
            recognizer.feedback(test, pred, true_d)

    # Phase 3: Validation after feedback
    print("  Phase 3: After feedback")
    for name, noise, rot, shift in conditions:
        correct = 0
        total = 0
        for true_d in range(6):
            for _ in range(5):
                r = random.choice([0,30,45,60,90,120,135,180,225,270]) if rot=='random' else rot
                s = (random.randint(-1,1), random.randint(-1,1)) if shift=='random' else shift
                test = make_digit(true_d, noise=noise, rotation=r, shift=s)
                pred, _ = recognizer.validate(test)
                if pred == true_d: correct += 1
                total += 1
        results[name + '_after_feedback'] = correct / total
        print(f"    {name:25s}: {correct/total:.1%} ({correct}/{total})")

    return results

def task_contrast_point_analysis():
    """Analyze how feedback refines contrast points."""
    extractor = FeedbackContrastExtractor(percentile=70)
    # Before feedback: points for digit 3
    img3 = make_digit(3, 0)
    points_before = extractor.extract(img3)
    # Simulate feedback: correct matches for digit 3, incorrect for digit 5
    for _ in range(30):
        test = make_digit(3, noise=0.1, rotation=random.choice([0,45,90,180]),
                          shift=(random.randint(-1,1), random.randint(-1,1)))
        pts = extractor.extract(test)
        extractor.record_feedback(pts, 1.0, True)
    for _ in range(20):
        test = make_digit(5, noise=0.1, rotation=random.choice([0,45,90,180]),
                          shift=(random.randint(-1,1), random.randint(-1,1)))
        pts = extractor.extract(test)
        extractor.record_feedback(pts, 0.5, False)
    points_after = extractor.get_refined_points(img3)
    # Compare
    overlap = len(set(points_before) & set(points_after))
    return {
        'points_before': len(points_before),
        'points_after': len(points_after),
        'overlap': overlap,
        'new_points': len(set(points_after) - set(points_before)),
        'pruned_points': len(set(points_before) - set(points_after)),
        'match_count': extractor.match_count,
    }

def task_generation():
    """Generation: use matched template + contrast point overlay (structure-guided)."""
    recognizer = PatternRecognizer()
    for d in range(6):
        recognizer.train(d, make_digit(d, 0))
    # Feedback training
    for _ in range(30):
        for true_d in range(6):
            test = make_digit(true_d, noise=0.1, rotation=random.choice([0,45,90,180]),
                              shift=(random.randint(-1,1), random.randint(-1,1)))
            pred, _ = recognizer.validate(test)
            recognizer.feedback(test, pred, true_d)
    # Generate for rotated+shifted inputs
    gen_sims = []
    for true_d in range(6):
        for angle in [0, 45, 90, 180]:
            test = make_digit(true_d, noise=0.1, rotation=angle, shift=(1, -1))
            details = recognizer.validate(test, return_details=True)
            best = details[0]
            pred_label, score, best_angle, best_shift, pat_sim, pix_cos = best
            # Align template to input orientation
            tpl = recognizer.templates[pred_label][0]
            aligned = rotate_2d(tpl, best_angle)
            dx, dy = best_shift
            h, w = 8, 8
            generated = [[0.0]*w for _ in range(h)]
            for i in range(h):
                for j in range(w):
                    bi, bj = i - dx, j - dy
                    if 0 <= bi < h and 0 <= bj < w:
                        generated[i][j] = aligned[bi][bj]
            # Overlay contrast points from input (selective)
            input_points = recognizer.extractor.extract(test)
            for (ci, cj) in input_points[:6]:
                if 0 <= ci < h and 0 <= cj < w and test[ci][cj] > 0.3:
                    generated[ci][cj] = test[ci][cj]
            gen_sim = cos([x for r in generated for x in r], [x for r in test for x in r])
            gen_sims.append(gen_sim)
    return {'mean_gen_sim': sum(gen_sims)/len(gen_sims), 'min': min(gen_sims), 'max': max(gen_sims)}

# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':
    print("=" * 70)
    print("PGD v7: Feedback Contrast Points + Pattern Shift Invariance")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Rotation + Shift Invariance (train -> feedback -> validate)")
    r = task_rotation_shift()
    results['rotation_shift'] = r

    print("\n[2] Contrast Point Refinement via Feedback")
    r = task_contrast_point_analysis()
    results['contrast_analysis'] = r
    print(f"  Points before: {r['points_before']}")
    print(f"  Points after:  {r['points_after']}")
    print(f"  Overlap: {r['overlap']}, New: {r['new_points']}, Pruned: {r['pruned_points']}")

    print("\n[3] Generation (structure-guided with shift alignment)")
    r = task_generation()
    results['generation'] = r
    print(f"  Mean similarity: {r['mean_gen_sim']:.3f}")
    print(f"  Range: [{r['min']:.3f}, {r['max']:.3f}]")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.2f}s")

    print("\n" + "=" * 70)
    print("v6 -> v7 COMPARISON (hard condition: rot+shift+noise)")
    print("=" * 70)
    v6_hard = 0.433
    v7_hard = results['rotation_shift'].get('rot+shift+noise0.15_after_feedback', 0)
    print(f"  v6 (rotation only, no shift): {v6_hard:.1%}")
    print(f"  v7 (feedback + pattern shift): {v7_hard:.1%}")
    print(f"  Improvement: {(v7_hard - v6_hard)*100:+.1f}pp")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_v7_results.json")
    with open(out, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved: {out}")
    print("\n✅ PGD v7 complete.")
