"""
PGD v4: Rotation Invariance + Hierarchical Template Library + Cross-Modal Mapping
1. Symmetric kernel construction for rotation invariance (multi-angle template matching)
2. Hierarchical template storage with similarity-based compression (deduplicate similar templates)
3. Cross-modal mapping learned from paired data (mapping embodied in correlation)
"""
import os, time, math, json, random
from collections import defaultdict
from cos_comparison.core import cos, local_variance, mean_local, cos_comparison_passive

random.seed(42)

# ============================================================
# 1. ROTATION-INVARIANT MATCHING (Symmetric Kernel Construction)
# ============================================================
def rotate_2d(matrix, angle_deg):
    """Rotate 2D matrix by angle (counterclockwise). Nearest-neighbor for simplicity."""
    h, w = len(matrix), len(matrix[0])
    angle = math.radians(angle_deg)
    cos_a, sin_a = math.cos(angle), math.sin(angle)
    result = [[0.0] * w for _ in range(h)]
    cx, cy = w / 2, h / 2
    for i in range(h):
        for j in range(w):
            # Inverse rotation: find source pixel
            x = j - cx
            y = i - cy
            src_x = x * cos_a + y * sin_a + cx
            src_y = -x * sin_a + y * cos_a + cy
            si, sj = int(round(src_y)), int(round(src_x))
            if 0 <= si < h and 0 <= sj < w:
                result[i][j] = matrix[si][sj]
    return result

def symmetric_kernel_variance(matrix, radius=2):
    """Circular symmetric kernel: compute variance in a ring around each pixel.
    Ring/circular kernel is rotation-invariant by construction."""
    h, w = len(matrix), len(matrix[0])
    result = [[0.0] * w for _ in range(h)]
    for i in range(h):
        for j in range(w):
            vals = []
            for di in range(-radius, radius + 1):
                for dj in range(-radius, radius + 1):
                    if di * di + dj * dj <= radius * radius:  # circular mask
                        ni, nj = i + di, j + dj
                        if 0 <= ni < h and 0 <= nj < w:
                            vals.append(matrix[ni][nj])
            if vals:
                m = sum(vals) / len(vals)
                result[i][j] = sum((v - m) ** 2 for v in vals) / len(vals)
    return result

def rotation_invariant_match(img1, img2, angles=(0, 45, 90, 135, 180, 225, 270, 315)):
    """Match img1 against rotated versions of img2, take max.
    Also use circular symmetric kernel features for additional robustness."""
    best_score = -1
    best_angle = 0
    # Method 1: direct multi-angle matching
    for angle in angles:
        rotated = rotate_2d(img2, angle)
        # Flatten and cosine
        f1 = [x for row in img1 for x in row]
        f2 = [x for row in rotated for x in row]
        try:
            score = cos(f1, f2)
        except Exception:
            score = 0
        if score > best_score:
            best_score = score
            best_angle = angle
    # Method 2: symmetric kernel features (rotation-invariant by construction)
    sk1 = symmetric_kernel_variance(img1, radius=1)
    sk2 = symmetric_kernel_variance(img2, radius=1)
    fsk1 = [x for row in sk1 for x in row]
    fsk2 = [x for row in sk2 for x in row]
    try:
        sk_score = cos(fsk1, fsk2)
    except Exception:
        sk_score = 0
    # Combined: multi-angle (spatial) + symmetric kernel (invariant)
    combined = 0.7 * best_score + 0.3 * sk_score
    return combined, best_angle, sk_score

# ============================================================
# 2. HIERARCHICAL TEMPLATE LIBRARY (Layered, On-Demand, Compressed)
# ============================================================
class HierarchicalTemplateLibrary:
    """Three-level template storage with automatic similarity compression.
    Level 0 (L0): local detail templates (small, high-res)
    Level 1 (L1): structural templates (medium)
    Level 2 (L2): global/abstract templates (large, low-res)
    Similar templates are merged (stored once with reference count).
    """
    def __init__(self, similarity_threshold=0.85):
        self.levels = {0: [], 1: [], 2: []}
        self.ref_counts = {0: [], 1: [], 2: []}
        self.threshold = similarity_threshold
        self.access_count = defaultdict(int)

    def _find_similar(self, template, level):
        """Find index of similar template in given level."""
        flat_t = [x for row in template for x in row] if template and isinstance(template[0], list) else template
        for idx, stored in enumerate(self.levels[level]):
            flat_s = [x for row in stored for x in row] if stored and isinstance(stored[0], list) else stored
            if len(flat_t) == len(flat_s):
                try:
                    sim = cos(flat_t, flat_s)
                    if sim >= self.threshold:
                        return idx
                except Exception:
                    pass
        return -1

    def add(self, template, level=1):
        """Add template to specified level. If similar exists, increment ref count (compression)."""
        idx = self._find_similar(template, level)
        if idx >= 0:
            self.ref_counts[level][idx] += 1
            return idx, True  # merged (compressed)
        else:
            self.levels[level].append(template)
            self.ref_counts[level].append(1)
            return len(self.levels[level]) - 1, False

    def get(self, idx, level=1):
        """Retrieve template, record access."""
        if 0 <= idx < len(self.levels[level]):
            self.access_count[(level, idx)] += 1
            return self.levels[level][idx]
        return None

    def match(self, query, level=1, top_k=1):
        """Find best matching template(s) in level. Uses shift-aware matching for 2D."""
        scores = []
        for idx, tpl in enumerate(self.levels[level]):
            if query and isinstance(query[0], list) and tpl and isinstance(tpl[0], list):
                score, _, _ = rotation_invariant_match(query, tpl, angles=(0, 90, 180, 270))
            else:
                fq = query if isinstance(query, list) else [query]
                ft = tpl if isinstance(tpl, list) else [tpl]
                ml = min(len(fq), len(ft))
                try:
                    score = cos(fq[:ml], ft[:ml])
                except Exception:
                    score = 0
            scores.append((idx, score))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

    def compress(self):
        """Remove rarely-accessed templates (on-demand storage cleanup)."""
        removed = 0
        for level in [0, 1, 2]:
            keep = []
            keep_refs = []
            for idx, tpl in enumerate(self.levels[level]):
                if self.access_count.get((level, idx), 0) > 0 or self.ref_counts[level][idx] > 1:
                    keep.append(tpl)
                    keep_refs.append(self.ref_counts[level][idx])
                else:
                    removed += 1
            self.levels[level] = keep
            self.ref_counts[level] = keep_refs
        return removed

    def stats(self):
        return {
            'L0_count': len(self.levels[0]),
            'L1_count': len(self.levels[1]),
            'L2_count': len(self.levels[2]),
            'total': sum(len(v) for v in self.levels.values()),
            'total_refs': sum(sum(r) for r in self.ref_counts.values()),
            'compression_ratio': sum(sum(r) for r in self.ref_counts.values()) / max(sum(len(v) for v in self.levels.values()), 1),
        }

# ============================================================
# 3. CROSS-MODAL MAPPING (learned from paired data)
# ============================================================
class CrossModalMapper:
    """Learn mapping between modalities from paired data.
    Mapping is embodied in correlation: paired samples share latent structure.
    Uses contrast point alignment: find corresponding high-info regions across modalities.
    """
    def __init__(self):
        self.pairs = []  # (modality_a_features, modality_b_features)
        self.mapping_matrix = None  # learned mapping weights

    def add_pair(self, feat_a, feat_b):
        """Add a paired training example."""
        self.pairs.append((feat_a, feat_b))

    def train(self, n_components=5):
        """Learn mapping from paired data.
        Uses correlation-based projection: find directions where modalities co-vary."""
        if len(self.pairs) < 2:
            return
        # Build feature matrices
        a_dim = len(self.pairs[0][0])
        b_dim = len(self.pairs[0][1])
        # Compute cross-correlation matrix
        cross_corr = [[0.0] * b_dim for _ in range(a_dim)]
        a_mean = [0.0] * a_dim
        b_mean = [0.0] * b_dim
        for fa, fb in self.pairs:
            for i in range(a_dim):
                a_mean[i] += fa[i] / len(self.pairs)
            for j in range(b_dim):
                b_mean[j] += fb[j] / len(self.pairs)
        for fa, fb in self.pairs:
            for i in range(a_dim):
                for j in range(b_dim):
                    cross_corr[i][j] += (fa[i] - a_mean[i]) * (fb[j] - b_mean[j]) / len(self.pairs)
        # Simple mapping: normalized cross-correlation as weights
        self.mapping_matrix = []
        for i in range(a_dim):
            row = []
            for j in range(b_dim):
                row.append(cross_corr[i][j])
            self.mapping_matrix.append(row)
        self.a_mean = a_mean
        self.b_mean = b_mean

    def map_a_to_b(self, feat_a):
        """Map features from modality A to modality B using learned correlation."""
        if self.mapping_matrix is None:
            return None
        b_dim = len(self.mapping_matrix[0])
        result = [0.0] * b_dim
        for j in range(b_dim):
            weighted_sum = 0.0
            weight_sum = 0.0
            for i in range(len(feat_a)):
                w = abs(self.mapping_matrix[i][j])
                weighted_sum += w * feat_a[i]
                weight_sum += w
            result[j] = self.b_mean[j] + (weighted_sum / weight_sum if weight_sum > 0 else 0)
        return result

    def map_b_to_a(self, feat_b):
        """Map features from modality B to modality A."""
        if self.mapping_matrix is None:
            return None
        a_dim = len(self.mapping_matrix)
        result = [0.0] * a_dim
        for i in range(a_dim):
            weighted_sum = 0.0
            weight_sum = 0.0
            for j in range(len(feat_b)):
                w = abs(self.mapping_matrix[i][j])
                weighted_sum += w * feat_b[j]
                weight_sum += w
            result[i] = self.a_mean[i] + (weighted_sum / weight_sum if weight_sum > 0 else 0)
        return result

# ============================================================
# PERCEPTION (enhanced with rotation-invariant features)
# ============================================================
class Perception:
    @staticmethod
    def extract_2d(matrix, window=3):
        h, w = len(matrix), len(matrix[0])
        f = {'raw': matrix, 'flat': [x for row in matrix for x in row], 'shape': (h, w)}
        # Rotation-invariant: circular symmetric kernel
        f['symmetric_kernel'] = symmetric_kernel_variance(matrix, radius=1)
        f['symmetric_flat'] = [x for row in f['symmetric_kernel'] for x in row]
        # Row/col variance
        f['row_variance'] = []
        for row in matrix:
            try: f['row_variance'].append(local_variance(row, local_size=(window,)))
            except: f['row_variance'].append([])
        f['col_variance'] = []
        for j in range(w):
            col = [matrix[i][j] for i in range(h)]
            try: f['col_variance'].append(local_variance(col, local_size=(window,)))
            except: f['col_variance'].append([])
        # Contrast points from symmetric kernel (rotation-invariant)
        sk_flat = f['symmetric_flat']
        if sk_flat:
            vmax = max(sk_flat)
            f['contrast_points'] = [(i // w, i % w) for i, v in enumerate(sk_flat) if v > vmax * 0.3]
        else:
            f['contrast_points'] = []
        return f

    @staticmethod
    def extract_1d(data, window=5):
        f = {'raw': data[:]}
        try: f['variance'] = local_variance(data, local_size=(window,))
        except: f['variance'] = []
        try: f['mean'] = mean_local(data, local_size=(window,))
        except: f['mean'] = []
        if f['variance']:
            vmax = max(f['variance'])
            f['contrast_points'] = [i for i, v in enumerate(f['variance']) if v > vmax * 0.3]
        else:
            f['contrast_points'] = []
        return f

    @staticmethod
    def spatiality_1d(data):
        n = len(data)
        if n < 4: return 1.0
        m = sum(data) / n
        num = sum((data[i] - m) * (data[i+1] - m) for i in range(n-1))
        den = sum((x - m)**2 for x in data)
        return abs(num/den)*5 + 1.0 if den > 1e-10 else 1.0

# ============================================================
# TASKS
# ============================================================
def make_digit(d, noise=0.15, shift=(0,0), rotation=0):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r + shift[0], c + shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    if rotation != 0:
        grid = rotate_2d(grid, rotation)
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

def task_rotation_invariance():
    """Test rotation-invariant matching on rotated digits."""
    templates = {d: make_digit(d, 0) for d in range(6)}
    angles = [0, 30, 45, 60, 90, 135, 180, 225, 270]
    correct_std = 0
    correct_rot = 0
    correct_sk = 0
    total = 0
    for true_d in range(6):
        for angle in angles:
            test = make_digit(true_d, noise=0.1, rotation=angle)
            # Standard: direct cosine (no rotation handling)
            best_d, best_s = -1, -1
            for d, tpl in templates.items():
                s = cos([x for r in test for x in r], [x for r in tpl for x in r])
                if s > best_s: best_s, best_d = s, d
            if best_d == true_d: correct_std += 1
            # Rotation-invariant: multi-angle + symmetric kernel
            best_d, best_s = -1, -1
            for d, tpl in templates.items():
                score, _, sk = rotation_invariant_match(test, tpl)
                if score > best_s: best_s, best_d = score, d
            if best_d == true_d: correct_rot += 1
            # Symmetric kernel only
            best_d, best_s = -1, -1
            for d, tpl in templates.items():
                sk1 = symmetric_kernel_variance(test, 1)
                sk2 = symmetric_kernel_variance(tpl, 1)
                s = cos([x for r in sk1 for x in r], [x for r in sk2 for x in r])
                if s > best_s: best_s, best_s = s, d
            if best_d == true_d: correct_sk += 1
            total += 1
    return {'standard': correct_std/total, 'rotation_invariant': correct_rot/total,
            'symmetric_kernel': correct_sk/total, 'total': total, 'angles_tested': len(angles)}

def task_hierarchical_templates():
    """Test hierarchical template library with compression."""
    lib = HierarchicalTemplateLibrary(similarity_threshold=0.80)
    templates = {d: make_digit(d, 0) for d in range(6)}
    # Add templates at different levels
    # L2: full digit (global structure)
    for d in range(6):
        lib.add(templates[d], level=2)
    # L1: half-digit patches (structural)
    for d in range(6):
        top = [row[:4] for row in templates[d][:4]]
        bottom = [row[4:] for row in templates[d][4:]]
        lib.add(top, level=1)
        lib.add(bottom, level=1)
    # L0: 3x3 local patches (detail)
    for d in range(6):
        for i in range(0, 6, 3):
            for j in range(0, 6, 3):
                patch = [templates[d][i+di][j:j+3] for di in range(3)]
                lib.add(patch, level=0)
    # Add duplicates to test compression
    for d in range(6):
        lib.add(templates[d], level=2)  # duplicate, should merge
    # Match a rotated digit against library
    test = make_digit(3, noise=0.1, rotation=45)
    matches_l2 = lib.match(test, level=2, top_k=3)
    matches_l1 = lib.match([row[:4] for row in test[:4]], level=1, top_k=3)
    # Compress (remove unused)
    removed = lib.compress()
    stats = lib.stats()
    return {'stats': stats, 'removed_on_compress': removed,
            'l2_top_match': matches_l2[0] if matches_l2 else None,
            'l1_top_match': matches_l1[0] if matches_l1 else None,
            'compression_ratio': stats['compression_ratio']}

def task_cross_modal_mapping():
    """Test cross-modal mapping: image features -> text description features.
    Mapping learned from paired data (image + its description)."""
    mapper = CrossModalMapper()
    # Create paired data: digit image features + "description" frequency vectors
    # Description is a synthetic "text" vector where certain dimensions correlate with digit shape
    vocab = 20
    descriptions = {
        0: [1,0,1,0,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0],  # round, closed
        1: [0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0],  # vertical, straight
        2: [1,0,0,1,0,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1],  # curved top, diagonal
        3: [1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,0,0,1,0],  # curved both sides
        4: [0,1,1,0,0,1,1,0,0,1,0,0,1,0,0,1,1,0,0,1],  # vertical + horizontal
        5: [1,0,0,1,1,0,0,1,0,1,0,0,1,0,0,1,0,0,1,1],  # curved top, straight bottom
    }
    templates = {d: make_digit(d, 0) for d in range(6)}
    # Train on paired data (multiple noisy copies)
    for _ in range(30):
        d = random.randint(0, 5)
        img = make_digit(d, noise=random.uniform(0.05, 0.2))
        feat = Perception.extract_2d(img)
        img_feat = feat['symmetric_flat'][:40]  # use first 40 symmetric kernel values
        # Pad/truncate to fixed size
        img_feat = (img_feat + [0.0]*40)[:40]
        text_feat = descriptions[d][:]
        # Add noise to text
        text_feat = [max(0, v + random.gauss(0, 0.05)) for v in text_feat]
        mapper.add_pair(img_feat, text_feat)
    mapper.train()
    # Test: map new image features to text, classify by closest description
    correct = 0
    total = 0
    for true_d in range(6):
        for _ in range(5):
            img = make_digit(true_d, noise=random.uniform(0.05, 0.15),
                             rotation=random.choice([0, 0, 0, 45, 90]))
            feat = Perception.extract_2d(img)
            img_feat = (feat['symmetric_flat'][:40] + [0.0]*40)[:40]
            pred_text = mapper.map_a_to_b(img_feat)
            if pred_text is None:
                continue
            # Find closest description
            best_d, best_s = -1, -1
            for d, desc in descriptions.items():
                s = cos(pred_text, desc)
                if s > best_s: best_s, best_d = s, d
            if best_d == true_d: correct += 1
            total += 1
    # Also test reverse: text -> image feature reconstruction quality
    text_to_img = mapper.map_b_to_a(descriptions[3])
    img3_feat = (Perception.extract_2d(templates[3])['symmetric_flat'][:40] + [0.0]*40)[:40]
    recon_sim = cos(text_to_img, img3_feat) if text_to_img else 0
    return {'mapping_accuracy': correct/total if total else 0, 'total': total,
            'reverse_recon_similarity': recon_sim, 'n_pairs': len(mapper.pairs)}

def task_full_chain_with_rotation():
    """Full PGD chain with rotation invariance + hierarchical templates."""
    lib = HierarchicalTemplateLibrary(similarity_threshold=0.80)
    templates = {d: make_digit(d, 0) for d in range(6)}
    for d in range(6):
        lib.add(templates[d], level=2)
    # Perceive rotated+shifted digit
    test = make_digit(3, noise=0.15, shift=(1, -1), rotation=45)
    feat = Perception.extract_2d(test)
    # Decide via library matching (rotation-invariant)
    matches = lib.match(test, level=2, top_k=3)
    predicted = matches[0][0] if matches else -1
    # Generate: reconstruct from matched template + contrast points
    matched_tpl = lib.get(matches[0][0], level=2) if matches else None
    generated = None
    if matched_tpl:
        # Structure-guided generation
        h, w = 8, 8
        generated = [row[:] for row in matched_tpl]
        # Overlay contrast regions from test
        for (ci, cj) in feat['contrast_points'][:8]:
            if 0 <= ci < h and 0 <= cj < w:
                generated[ci][cj] = test[ci][cj]
    gen_sim = 0
    if generated:
        gen_sim = cos([x for r in generated for x in r], [x for r in test for x in r])
    return {'predicted': predicted, 'actual': 3, 'correct': predicted == 3,
            'top_matches': [(idx, round(s, 3)) for idx, s in matches],
            'generation_similarity': gen_sim,
            'contrast_points_used': len(feat['contrast_points']),
            'library_stats': lib.stats()}

# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':
    print("=" * 70)
    print("PGD v4: Rotation Invariance + Hierarchical Templates + Cross-Modal Mapping")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[Task 1] Rotation Invariance (9 angles: 0-270°)")
    r = task_rotation_invariance()
    results['rotation'] = r
    print(f"  Standard (no rot): {r['standard']:.1%}")
    print(f"  Rotation-invariant: {r['rotation_invariant']:.1%}")
    print(f"  Symmetric kernel only: {r['symmetric_kernel']:.1%}")
    print(f"  Angles tested: {r['angles_tested']}")

    print("\n[Task 2] Hierarchical Template Library (with compression)")
    r = task_hierarchical_templates()
    results['templates'] = r
    print(f"  Library stats: {r['stats']}")
    print(f"  Compression ratio: {r['compression_ratio']:.2f}x")
    print(f"  Removed on compress: {r['removed_on_compress']}")
    print(f"  L2 top match (rotated 3): idx={r['l2_top_match'][0]}, score={r['l2_top_match'][1]:.3f}")

    print("\n[Task 3] Cross-Modal Mapping (image -> text features)")
    r = task_cross_modal_mapping()
    results['cross_modal'] = r
    print(f"  Mapping accuracy: {r['mapping_accuracy']:.1%} ({r['total']} tests)")
    print(f"  Reverse recon similarity: {r['reverse_recon_similarity']:.3f}")
    print(f"  Training pairs: {r['n_pairs']}")

    print("\n[Task 4] Full Chain (rotated digit -> perceive -> library -> generate)")
    r = task_full_chain_with_rotation()
    results['full_chain'] = r
    print(f"  Predicted: {r['predicted']}, Actual: {r['actual']}, Correct: {r['correct']}")
    print(f"  Top matches: {r['top_matches']}")
    print(f"  Generation similarity: {r['generation_similarity']:.3f}")
    print(f"  Contrast points used: {r['contrast_points_used']}")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.2f}s")

    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"  Rotation invariance: {results['rotation']['standard']:.1%} -> {results['rotation']['rotation_invariant']:.1%} "
          f"(+{results['rotation']['rotation_invariant']-results['rotation']['standard']:.1%})")
    print(f"  Template compression: {results['templates']['compression_ratio']:.2f}x "
          f"({results['templates']['stats']['total']} unique templates for {results['templates']['stats']['total_refs']} refs)")
    print(f"  Cross-modal accuracy: {results['cross_modal']['mapping_accuracy']:.1%}")
    print(f"  Full chain (rotated): {'PASS' if results['full_chain']['correct'] else 'FAIL'}")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_v4_results.json")
    with open(out, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved: {out}")
    print("\n✅ PGD v4 complete.")
