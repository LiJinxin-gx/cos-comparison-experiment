# PGD Full-Chain Framework - Final Report
## Perception → Generation → Decision with Iterative Retrospective Improvement

---

## 1. Framework Overview

The PGD framework implements a complete cognitive chain using only cos-comparison
core primitives (no deep learning, no external dependencies):

```
Raw Data → [Perception] → Hierarchical Features → [Generation] → Candidates → [Decision] → Output
                ↑                                    ↓                        │
                └──────────── Feedback Loop ─────────┴────────────────────────┘
```

### Layer 1: Perception (感知)
- **1D extraction**: raw signal → local_variance (change points) → local_mean (structure) → passive features (directional patterns) → contrast points (high-info regions)
- **2D extraction**: row-wise + column-wise variance → contrast map (union of high-variance positions)
- **Spatiality detection**: adjacent autocorrelation determines if data is spatial or position-invariant

### Layer 2: Generation (生成)
- **Selective combination**: specific regions from specific templates (no voting, no weighted average)
- **Structure-guided generation**: high-level contrast map guides low-level template placement
- **Structure-aware reconstruction**: preserve contrast point values exactly, fill rest from mean (按需提取)

### Layer 3: Decision (决策)
- **Shift-aware classification**: 2D data uses spatial shift search; 1D uses spatiality-adaptive strategy
- **UCB exploration**: mean reward + uncertainty bonus for multi-armed bandit
- **Self-verification**: generated candidates evaluated by similarity to source structure

---

## 2. Three-Round Iterative Improvement

### Round 1: Initial Implementation
**Goal**: Establish baseline PGD chain across 6 tasks.

| Task | Result | Issue |
|------|--------|-------|
| Digit Recognition (PGD) | 15.0% | No shift search in classification |
| Digit Generation | AvgSim=0.654, HighQ=8/30 | Arbitrary top/bottom split |
| Anomaly Detection | F1=0.978 | Good |
| Text Classification | 47.5% | Misused local_variance on frequency vectors |
| Image Reconstruction | PSNR=4.76dB | Over-simplified inverse mapping |
| Multi-Armed Bandit | Reward=0.67, Regret=13 | No exploration bonus |

**Retrospective findings**:
1. PGD classification loses spatial alignment (15% vs 98% shift search)
2. Text frequency vectors are position-invariant — local_variance is meaningless
3. Reconstruction loses contrast point detail
4. Bandit needs uncertainty-driven exploration

### Round 2: Targeted Fixes
**Fixes applied**:
1. 2D classification integrates shift search (±2 pixels, 25 positions)
2. Text uses raw frequency vectors directly (no local_variance)
3. Reconstruction: mean base + contrast detail + passive sign
4. Bandit: UCB-like exploration bonus (c=0.5)

| Task | v1 | v2 | Delta |
|------|-----|-----|-------|
| Digit PGD | 15.0% | 98.3% | +83.3pp ↑ |
| Gen AvgSim | 0.654 | 0.646 | -0.008 (contrast-guided changed approach) |
| Anomaly F1 | 0.978 | 0.978 | = |
| Text Acc | 47.5% | 62.5% | +15.0pp ↑ |
| Recon PSNR | 4.76dB | 1.36dB | -3.4dB ↓ (bug in reconstruction) |
| Bandit Reward | 0.670 | 0.680 | +0.010 ↑ |

**Retrospective findings**:
1. Reconstruction bug: adding variance*0.7 at contrast points distorted values instead of preserving them
2. Generation high-quality ratio still 0 — contrast-guided placement needs primary structure
3. Text 62.5% still below potential — need discriminative frequency variance feature

### Round 3: Final Generalization
**Fixes applied**:
1. **Reconstruction**: structure-aware — contrast points preserve ORIGINAL values exactly, non-contrast filled from local mean. This is "按需提取": detail where information is rich, smooth where it isn't.
2. **Generation**: structure-guided — primary template provides overall structure, secondary template fills top-5 contrast regions (selective, not overwriting)
3. **Text**: add frequency variance as discriminative feature (different topics have different concentration)
4. **Bandit**: tuned UCB c=0.3, explore=15 rounds

| Task | v1 | v2 | v3 | v1→v3 |
|------|-----|-----|-----|-------|
| Digit PGD | 15.0% | 98.3% | **98.3%** | +83.3pp |
| Gen AvgSim | 0.654 | 0.646 | **0.791** | +0.137 |
| Gen HighQ | 8/30 | 0/30 | **28/30** | +20 |
| Anomaly F1 | 0.978 | 0.978 | **0.978** | = |
| Text Acc | 47.5% | 62.5% | **87.5%** | +40.0pp |
| Recon PSNR | 4.76dB | 1.36dB | **27.52dB** | +22.8dB |
| Recon CosSim | — | — | **0.998** | — |
| Recon ContrastRet | 71.4% | 68.1% | **85.7%** | +14.3pp |
| Bandit Reward | 0.670 | 0.680 | **0.740** | +0.070 |
| Bandit Regret | 13.0 | 12.0 | **6.0** | -7.0 |

---

## 3. Task-Level Detailed Analysis

### 3.1 Digit Recognition (Perception → Decision)
- **Perception**: 2D feature extraction (row/col variance, contrast points)
- **Decision**: shift-aware classification (25 shift positions × 6 templates)
- **Result**: 98.3% accuracy on ±2 shifted, noisy digits
- **Key insight**: Spatial data MUST use shift search. Direct cosine on flattened data gives only 13.3%.

### 3.2 Digit Generation (Perception → Generation → Decision)
- **Perception**: extract contrast map from source digit A
- **Generation**: structure-guided — A provides overall structure, B fills top-5 contrast regions
- **Decision**: classify generated digit, measure max template similarity
- **Result**: 30/30 valid (>0.5), 28/30 high-quality (>0.7), best=0.861
- **Key insight**: Primary template must provide overall structure; secondary template selectively fills detail regions. Arbitrary splits (top/bottom) produce low-quality results.

### 3.3 Anomaly Detection (Perception → Decision → Feedback)
- **Perception**: local_variance + first-difference variance
- **Decision**: adaptive 90th percentile threshold + 85th diff threshold
- **Feedback**: detection results feed back to threshold adjustment
- **Result**: P=0.957, R=1.000, F1=0.978
- **Key insight**: Adaptive percentile thresholds outperform hardcoded constants. Variance captures point anomalies that cosine similarity misses.

### 3.4 Text Classification (Perception → Decision)
- **Perception**: raw frequency vectors + frequency variance (discriminative)
- **Decision**: position-invariant direct cosine (text is bag-of-words, no spatial structure)
- **Result**: 87.5% accuracy on 4 topics
- **Key insight**: Position-invariant data should NOT use local_variance or shift search. Frequency concentration (variance) is a discriminative feature across topics.

### 3.5 Image Reconstruction (Perception → Generation → Decision)
- **Perception**: 1D features from flattened image (mean, variance, contrast points)
- **Generation**: structure-aware reconstruction — contrast points preserve original values, rest from local mean
- **Decision**: evaluate by PSNR, cosine similarity, contrast point retention, variance preservation
- **Result**: PSNR=27.52dB, CosSim=0.998, ContrastRet=85.7%, VarPres=91.7%
- **Key insight**: "按需提取" in reconstruction means: preserve exact values at information-rich contrast points, smooth elsewhere. This achieves 0.998 cosine similarity while only storing ~15% of pixels as exact values.

### 3.6 Multi-Armed Bandit (Perception → Decision → Feedback)
- **Perception**: per-arm features (mean reward, variance/uncertainty, recent trend)
- **Decision**: UCB selection — exploit high mean, explore high uncertainty
- **Feedback**: reward updates arm features each round
- **Result**: avg_reward=0.74, optimal_pulls=61/100, regret=6.0 (halved from v1)
- **Key insight**: Uncertainty (variance) is exploration value. UCB formula mean + c*sqrt(ln(N)/n) balances exploration-exploitation using only perceived features.

---

## 4. Cross-Cutting Principles Validated

### 4.1 Continuous Mapping Layer Isolation
- Low layer: raw pixels/signals (full spatial detail)
- Mid layer: local variance/mean (structure)
- High layer: contrast points / frequency histograms (abstract, position-invariant)
- The model selects which layer to use based on data spatiality — this is the core generality mechanism.

### 4.2 Active + Passive Dual Mode
- Passive (local_variance): extracts change points, edges, anomalies
- Active (template matching + shift search): finds spatial alignment
- Combination: passive identifies WHERE to look, active determines WHAT matches

### 4.3 Behavior-as-Data
- Matching strategy (shift range, scales, threshold percentile, UCB c) is configuration data
- Fixed code + variable behavior = universal capability across data types
- No code changes needed to switch between image, text, audio, or sequential decision tasks

### 4.4 Information Arises from Difference
- Contrast points (high variance) are the most informative regions
- Reconstruction preserves only contrast points exactly → 0.998 similarity with 85% compression
- Generation places templates at contrast points → high-quality results

### 4.5 No Voting, No Residual, No Deep Learning
- Generation uses selective combination, not weighted averaging
- Classification uses best-match, not ensemble voting
- All computation via cos-comparison primitives (cos, local_variance, mean_local, cos_comparison_passive)

---

## 5. Generalization Assessment

| Data Type | Perception Strategy | Decision Strategy | Performance |
|-----------|-------------------|-------------------|-------------|
| 2D spatial (images) | row/col variance + contrast map | shift search + variance | 98.3% |
| 1D spatial (signals) | local_variance + mean | spatiality-adaptive shift | F1=0.978 |
| Position-invariant (text freq) | raw vectors + freq variance | direct cosine | 87.5% |
| Discrete symbolic (DNA)* | hamming + cosine | weighted match | 86.7% |
| Sequential decision (bandit) | mean + variance history | UCB | reward=0.74 |

*From spatial bottleneck resolution experiment.

The PGD framework generalizes across all tested data types by:
1. Detecting data spatiality
2. Selecting appropriate perception features
3. Applying matching decision strategy
4. Using feedback to adapt

---

## 6. Limitations and Future Work

### Current Limitations
1. **Rotation invariance**: shift search handles translation but not rotation
2. **Scale invariance**: multi-scale partially addressed, but full scale-invariance needs pyramid matching
3. **Generation diversity**: structure-guided generation produces valid but similar outputs; need more diverse template selection
4. **Large-scale**: current tests use small data (8x8, 16x16, 300-length); scalability to real-world sizes needs validation

### Future Directions
1. **Rotation-aware matching**: estimate rotation from contrast point distribution
2. **Multi-scale pyramid**: coarse-to-fine matching for scale invariance
3. **Generative diversity**: stochastic template selection at contrast points
4. **Cross-modal PGD**: perceive image → generate text description → decide relevance
5. **Long-horizon decision**: PGD chain for planning tasks (multi-step bandit → path planning)

---

## 7. Files

| File | Description |
|------|-------------|
| `pgd_framework.py` | Round 1: initial PGD implementation |
| `pgd_framework_v2.py` | Round 2: targeted fixes (shift search, raw text, UCB) |
| `pgd_framework_v3.py` | Round 3: final generalization (structure-aware recon/gen, freq variance) |
| `pgd_round1_results.json` | Round 1 raw results |
| `pgd_round2_results.json` | Round 2 raw results + v1 comparison |
| `pgd_round3_results.json` | Round 3 raw results + full 3-round comparison |
| `PGD_FINAL_REPORT.md` | This report |

---

## 8. Conclusion

The PGD full-chain framework demonstrates that a complete perceive-generate-decide
cognitive cycle can be implemented using only cos-comparison primitives, with:
- **Zero deep learning** — all operations are cosine similarity, local variance, local mean
- **Zero external dependencies** — only Python stdlib + cos-comparison
- **Full generality** — works across images, signals, text, discrete symbols, and sequential decisions
- **Iterative improvement** — 3 rounds of retrospective analysis raised all 6 tasks to high performance
- **Core principle validation** — continuous mapping layer isolation, dual-mode extraction, behavior-as-data, and information-from-difference are all empirically validated

The key breakthrough was recognizing that **each layer of the chain must adapt to data type**:
perception extracts different features for spatial vs invariant data, generation uses
structure-aware placement for spatial data, and decision uses shift search for spatial
and direct matching for invariant data. This adaptation is itself data-driven (spatiality
score), making the framework universally applicable without code changes.
