# Multi-Task Generality Test Report
## Enhanced Principles (Direction + Strength + Synthesis) Across 8 Domains

---

## Results Summary

| Task | Domain | Standard | Enhanced | Gain | Status |
|------|--------|----------|----------|------|--------|
| Digit Recognition | Image/Pattern | 22.0% | 100.0% | +78.0pp | ✅ Major |
| Anomaly Detection | Time Series | 0.000 F1 | 1.000 F1 | +1.000 | ✅ Major |
| Audio Recognition | Signal | 71.1% | 82.2% | +11.1pp | ✅ Moderate |
| Sensor Event | IoT/Multi-ch | 0.326 F1 | 0.857 F1 | +0.531 | ✅ Major |
| Text Classification | NLP | 90.0% | 90.0% | 0.0pp | ➖ Saturated |
| Recommendation | Recommender | 72.0% | 69.3% | -2.7pp | ❌ Minor |
| Compression | Image/Codec | 29.25dB | 26.28dB | -2.97dB | ❌ Minor |
| DNA Motif | Bioinformatics | 80.0% | 53.3% | -26.7pp | ❌ Major |

**Average gain: +25.3% (normalized)**
**Improved: 4/8 | Unchanged: 1/8 | Degraded: 3/8**

---

## Per-Task Analysis

### 1. Digit Recognition (+78.0pp)
**Enhancement used**: Direction (multi-shift search)
**Why it works**: Digit patterns are spatially shifted. Standard cosine requires perfect alignment. Enhanced method searches 9 spatial offsets, finding the best alignment.
**Key insight**: Direction enhancement is critical for any task with spatial/temporal misalignment.

### 2. Anomaly Detection (+1.0 F1)
**Enhancement used**: Strength (variance + difference + adaptive threshold)
**Why it works**: Cosine similarity of windows is insensitive to point anomalies. Local variance and first-difference directly measure local volatility.
**Key insight**: For anomaly detection, difference features outperform similarity features.

### 3. Audio Recognition (+11.1pp)
**Enhancement used**: Synthesis (multi-scale fusion: 5, 10, 20 window sizes)
**Why it works**: Different frequencies respond best to different window sizes. Averaging across scales captures both low and high frequency content.
**Key insight**: Multi-scale synthesis benefits frequency-domain tasks.

### 4. Sensor Event Detection (+0.531 F1)
**Enhancement used**: Synthesis (cross-channel correlation + adaptive per-channel threshold)
**Why it works**: Independent thresholding produces 195 false positives. Requiring ≥3/4 channels to simultaneously exceed threshold reduces to 4 detections.
**Key insight**: Multi-channel tasks require coordination, not independent analysis.

### 5. Text Classification (0.0pp)
**Enhancement used**: Direction (frequency-space shift search)
**Why no gain**: Topic classification already at 90% with standard method. Frequency vectors are already position-invariant (bag-of-characters), so shift search provides no benefit.
**Key insight**: Direction enhancement only helps when position matters.

### 6. Recommendation (-2.7pp)
**Enhancement used**: Direction (partial view search) + Synthesis (top-3 ensemble)
**Why degraded**: Ensemble of top-3 similar users introduces noise from less-similar users. Partial view search may find spurious correlations in short segments.
**Key insight**: Ensemble methods can hurt when base similarities are already reliable.

### 7. Compression (-2.97dB)
**Enhancement used**: Strength (adaptive quantization: fine in high-variance, coarse in low-variance)
**Why degraded**: The test image has relatively uniform variance distribution. Adaptive quantization wastes levels on already-detailed regions while under-quantizing smooth regions.
**Key insight**: Adaptive methods require genuine heterogeneity in the data.

### 8. DNA Motif Detection (-26.7pp)
**Enhancement used**: Synthesis (cos + active mode combined, lower threshold)
**Why degraded**: Active mode output scale differs from cosine. Combining with max() and lowering threshold to 0.90 increases false positives. The standard method's 0.95 threshold on pure cosine was better calibrated.
**Key insight**: Multi-algorithm fusion requires proper normalization before combination.

---

## Principle-Task Matching Matrix

| Enhancement | Best For | Avoid For | Reason |
|-------------|----------|-----------|--------|
| **Direction** (shift search) | Spatial patterns, shifted data | Position-invariant data (bag-of-words) | Only helps when alignment matters |
| **Strength** (variance/diff) | Anomaly detection, edge detection | Smooth data, similarity tasks | Difference features capture change |
| **Synthesis** (multi-scale) | Frequency, multi-resolution | Single-scale sufficient tasks | Averaging can dilute strong signals |
| **Synthesis** (cross-channel) | Multi-sensor, multi-modal | Single-channel data | Coordination reduces false positives |
| **Synthesis** (multi-algorithm) | When algorithms have different biases | When output scales differ | Requires normalization before fusion |

---

## General Principles for Applying Enhancements

### 1. Match Enhancement to Task Structure
- **Spatial misalignment** → Direction (shift search)
- **Point anomalies** → Strength (variance, difference)
- **Multi-frequency** → Synthesis (multi-scale)
- **Multi-channel** → Synthesis (cross-channel correlation)
- **Position-invariant** → Skip Direction
- **Already high accuracy** → Be cautious with ensemble (may add noise)

### 2. Normalization Before Fusion
When combining multiple algorithms (cos + active + mod), always normalize outputs to comparable scales before max/avg fusion. Mismatched scales cause threshold calibration failures (as seen in DNA task).

### 3. Adaptive Methods Need Heterogeneity
Adaptive strength (variance-guided quantization/amplification) only helps when data has genuine regional differences. In uniform data, uniform methods perform better.

### 4. Ensemble Can Hurt
Ensembling top-k candidates (recommendation task) introduces noise from less-similar candidates. Use ensemble only when individual predictions are unreliable.

---

## Overall Generality Assessment

The enhanced principles demonstrate **strong generality across pattern/signal/sensor tasks** (4 major improvements), but **require careful matching to task characteristics**. The same enhancement that gives +78pp on digit recognition gives -26.7pp on DNA motif detection when applied without proper normalization.

**The core value of the cos-comparison architecture**: its separation of accumulation (direction) → preprocessing (strength) → normalization (synthesis) allows independent tuning of each dimension for different task types. This is a genuine architectural advantage over monolithic similarity measures.

---

## Files
- `generality_test.py` - 8-task test implementation
- `generality_results.json` - Raw results
- `GENERALITY_REPORT.md` - This report
