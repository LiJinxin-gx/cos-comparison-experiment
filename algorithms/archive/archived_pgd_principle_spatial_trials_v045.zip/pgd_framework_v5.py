"""
PGD v5: Fix cross-modal mapping and full-chain rotation.
Retrospective from v4:
1. Cross-modal 16.7%: too few pairs (30), features not discriminative, mapping too simple
2. Full-chain FAIL: template library match scores too close (0.537 vs 0.535), generation 0.543
3. Symmetric kernel alone 0%: needs combination with multi-angle, not standalone

Fixes:
1. Cross-modal: 100+ training pairs, rotation-invariant contrast histogram features,
   k-NN classification after mapping (not direct cosine)
2. Full-chain: use full 8-angle rotation matching in library, structure-guided generation
3. Template library: lower threshold for L2 matching, add rotated template copies
"""
import os, time, math, json, random
from collections import defaultdict, Counter
from cos_comparison.core import cos, local_variance, mean_local

random.seed(42)

# ============================================================
# Utilities (from v4)
# ============================================================
def rotate_2d(matrix, angle_deg):
    h, w = len(matrix), len(matrix[0])
    angle = math.radians(angle_deg)
    cos_a, sin_a = math.cos(angle), math.sin(angle)
    result = [[0.0] * w for _ in range(h)]
    cx, cy = w / 2, h / 2
    for i in range(h):
        for j in range(w):
            x, y = j - cx, i - cy
            src_x = x * cos_a + y * sin_a + cx
            src_y = -x * sin_a + y * cos_a + cy
            si, sj = int(round(src_y)), int(round(src_x))
            if 0 <= si < h and 0 <= sj < w:
                result[i][j] = matrix[si][sj]
    return result

def symmetric_kernel_variance(matrix, radius=1):
    h, w = len(matrix), len(matrix[0])
    result = [[0.0] * w for _ in range(h)]
    for i in range(h):
        for j in range(w):
            vals = []
            for di in range(-radius, radius + 1):
                for dj in range(-radius, radius + 1):
                    if di*di + dj*dj <= radius*radius:
                        ni, nj = i+di, j+dj
                        if 0 <= ni < h and 0 <= nj < w:
                            vals.append(matrix[ni][nj])
            if vals:
                m = sum(vals) / len(vals)
                result[i][j] = sum((v-m)**2 for v in vals) / len(vals)
    return result

def rotation_invariant_match(img1, img2, angles=(0, 45, 90, 135, 180, 225, 270, 315)):
    best_score = -1
    best_angle = 0
    for angle in angles:
        rotated = rotate_2d(img2, angle)
        f1 = [x for row in img1 for x in row]
        f2 = [x for row in rotated for x in row]
        try: score = cos(f1, f2)
        except: score = 0
        if score > best_score:
            best_score = score
            best_angle = angle
    sk1 = symmetric_kernel_variance(img1, 1)
    sk2 = symmetric_kernel_variance(img2, 1)
    try: sk_score = cos([x for r in sk1 for x in r], [x for r in sk2 for x in r])
    except: sk_score = 0
    return 0.7 * best_score + 0.3 * sk_score, best_angle, sk_score

# ============================================================
# IMPROVED: Rotation-invariant contrast histogram (for cross-modal)
# ============================================================
def contrast_histogram_2d(matrix, n_bins=8, radius=1):
    """Rotation-invariant feature: histogram of circular symmetric kernel values.
    Histogram is inherently rotation-invariant (order doesn't matter)."""
    sk = symmetric_kernel_variance(matrix, radius)
    flat = [x for row in sk for x in row]
    vmin, vmax = min(flat), max(flat)
    if vmax - vmin < 1e-10:
        return [0.0] * n_bins
    hist = [0.0] * n_bins
    for v in flat:
        idx = min(int((v - vmin) / (vmax - vmin) * n_bins), n_bins - 1)
        hist[idx] += 1.0
    total = sum(hist)
    return [h / total for h in hist]

def spatial_contrast_distribution(matrix, grid=4):
    """Rotation-robust spatial distribution: divide into grid, count contrast in each cell.
    Less sensitive to rotation than pixel positions, more spatial than global histogram."""
    h, w = len(matrix), len(matrix[0])
    sk = symmetric_kernel_variance(matrix, 1)
    cell_h, cell_w = h // grid, w // grid
    feat = []
    for gi in range(grid):
        for gj in range(grid):
            vals = []
            for i in range(gi*cell_h, min((gi+1)*cell_h, h)):
                for j in range(gj*cell_w, min((gj+1)*cell_w, w)):
                    vals.append(sk[i][j])
            feat.append(sum(vals) / len(vals) if vals else 0)
    return feat

# ============================================================
# IMPROVED: Cross-modal mapper with k-NN
# ============================================================
class CrossModalMapperV2:
    """Improved cross-modal mapping.
    - Uses rotation-invariant contrast histogram + spatial distribution features
    - Trains on 100+ paired examples
    - Maps via correlation weights, classifies via k-NN in target space
    """
    def __init__(self, k=3):
        self.pairs = []
        self.k = k
        self.mapping = None
        self.a_mean = None
        self.b_mean = None

    def add_pair(self, feat_a, feat_b):
        self.pairs.append((feat_a, feat_b))

    def train(self):
        if len(self.pairs) < 5: return
        a_dim = len(self.pairs[0][0])
        b_dim = len(self.pairs[0][1])
        cross = [[0.0]*b_dim for _ in range(a_dim)]
        a_mean = [0.0]*a_dim
        b_mean = [0.0]*b_dim
        for fa, fb in self.pairs:
            for i in range(a_dim): a_mean[i] += fa[i]/len(self.pairs)
            for j in range(b_dim): b_mean[j] += fb[j]/len(self.pairs)
        for fa, fb in self.pairs:
            for i in range(a_dim):
                for j in range(b_dim):
                    cross[i][j] += (fa[i]-a_mean[i])*(fb[j]-b_mean[j])/len(self.pairs)
        self.mapping = cross
        self.a_mean = a_mean
        self.b_mean = b_mean

    def map_a_to_b(self, feat_a):
        if self.mapping is None: return None
        b_dim = len(self.mapping[0])
        result = [0.0]*b_dim
        for j in range(b_dim):
            ws, wsum = 0.0, 0.0
            for i in range(len(feat_a)):
                w = abs(self.mapping[i][j])
                ws += w * feat_a[i]
                wsum += w
            result[j] = self.b_mean[j] + (ws/wsum if wsum > 0 else 0)
        return result

    def classify_knn(self, feat_a, labels):
        """k-NN classification: map to B space, find k nearest training B features."""
        mapped = self.map_a_to_b(feat_a)
        if mapped is None: return None, 0
        dists = []
        for idx, (_, fb) in enumerate(self.pairs):
            d = sum((mapped[j]-fb[j])**2 for j in range(len(fb)))
            dists.append((d, labels[idx]))
        dists.sort()
        top_k = dists[:self.k]
        vote = Counter(label for _, label in top_k)
        pred = vote.most_common(1)[0][0]
        conf = vote.most_common(1)[0][1] / self.k
        return pred, conf

# ============================================================
# Hierarchical Template Library (improved matching)
# ============================================================
class HierarchicalTemplateLibrary:
    def __init__(self, threshold=0.75):
        self.levels = {0: [], 1: [], 2: []}
        self.refs = {0: [], 1: [], 2: []}
        self.threshold = threshold
        self.access = defaultdict(int)

    def _similar(self, t1, t2):
        f1 = [x for r in t1 for x in r] if t1 and isinstance(t1[0], list) else t1
        f2 = [x for r in t2 for x in r] if t2 and isinstance(t2[0], list) else t2
        if len(f1) != len(f2): return False
        try: return cos(f1, f2) >= self.threshold
        except: return False

    def add(self, template, level=1):
        for idx, stored in enumerate(self.levels[level]):
            if self._similar(template, stored):
                self.refs[level][idx] += 1
                return idx, True
        self.levels[level].append(template)
        self.refs[level].append(1)
        return len(self.levels[level])-1, False

    def get(self, idx, level=1):
        if 0 <= idx < len(self.levels[level]):
            self.access[(level, idx)] += 1
            return self.levels[level][idx]
        return None

    def match(self, query, level=1, top_k=3):
        scores = []
        for idx, tpl in enumerate(self.levels[level]):
            if query and isinstance(query[0], list) and tpl and isinstance(tpl[0], list):
                score, _, _ = rotation_invariant_match(query, tpl)
            else:
                fq = query if isinstance(query, list) else [query]
                ft = tpl if isinstance(tpl, list) else [tpl]
                ml = min(len(fq), len(ft))
                try: score = cos(fq[:ml], ft[:ml])
                except: score = 0
            scores.append((idx, score))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

    def stats(self):
        return {
            'L0': len(self.levels[0]), 'L1': len(self.levels[1]), 'L2': len(self.levels[2]),
            'total': sum(len(v) for v in self.levels.values()),
            'refs': sum(sum(r) for r in self.refs.values()),
            'ratio': sum(sum(r) for r in self.refs.values()) / max(sum(len(v) for v in self.levels.values()), 1),
        }

# ============================================================
# Perception
# ============================================================
class Perception:
    @staticmethod
    def extract_2d(matrix, window=3):
        h, w = len(matrix), len(matrix[0])
        f = {'raw': matrix, 'flat': [x for r in matrix for x in r], 'shape': (h,w)}
        f['symmetric_kernel'] = symmetric_kernel_variance(matrix, 1)
        f['contrast_hist'] = contrast_histogram_2d(matrix, n_bins=8)
        f['spatial_dist'] = spatial_contrast_distribution(matrix, grid=4)
        sk_flat = [x for r in f['symmetric_kernel'] for x in r]
        vmax = max(sk_flat) if sk_flat else 1
        f['contrast_points'] = [(i//w, i%w) for i,v in enumerate(sk_flat) if v > vmax*0.3]
        return f

    @staticmethod
    def extract_1d(data, window=5):
        f = {'raw': data[:]}
        try: f['variance'] = local_variance(data, local_size=(window,))
        except: f['variance'] = []
        try: f['mean'] = mean_local(data, local_size=(window,))
        except: f['mean'] = []
        if f['variance']:
            vmax = max(f['variance'])
            f['contrast_points'] = [i for i,v in enumerate(f['variance']) if v > vmax*0.3]
        else: f['contrast_points'] = []
        return f

# ============================================================
# Digit generator
# ============================================================
def make_digit(d, noise=0.15, shift=(0,0), rotation=0):
    grid = [[0.0]*8 for _ in range(8)]
    patterns = {
        0: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,6),(5,1),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        1: [(1,3),(1,4),(2,2),(2,3),(2,4),(2,5),(3,4),(4,4),(5,4),(6,3),(6,4),(6,5)],
        2: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,5),(4,4),(5,3),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        3: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,6),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
        4: [(1,1),(1,6),(2,1),(2,6),(3,1),(3,6),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(5,6),(6,6)],
        5: [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(3,1),(3,2),(3,3),(3,4),(3,5),(4,6),(5,6),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6)],
    }
    for r, c in patterns.get(d, []):
        nr, nc = r+shift[0], c+shift[1]
        if 0 <= nr < 8 and 0 <= nc < 8: grid[nr][nc] = 1.0
    if rotation != 0: grid = rotate_2d(grid, rotation)
    for i in range(8):
        for j in range(8):
            grid[i][j] = max(0, min(1, grid[i][j] + random.gauss(0, noise)))
    return grid

# ============================================================
# TASKS (v5)
# ============================================================
def task_rotation():
    templates = {d: make_digit(d, 0) for d in range(6)}
    angles = [0, 15, 30, 45, 60, 75, 90, 120, 135, 180, 225, 270]
    c_std = c_rot = c_hist = 0
    total = 0
    for true_d in range(6):
        for angle in angles:
            test = make_digit(true_d, noise=0.1, rotation=angle)
            # Standard
            bd, bs = -1, -1
            for d, t in templates.items():
                s = cos([x for r in test for x in r], [x for r in t for x in r])
                if s > bs: bs, bd = s, d
            if bd == true_d: c_std += 1
            # Rotation-invariant (multi-angle + symmetric kernel)
            bd, bs = -1, -1
            for d, t in templates.items():
                s, _, _ = rotation_invariant_match(test, t)
                if s > bs: bs, bd = s, d
            if bd == true_d: c_rot += 1
            # Contrast histogram (rotation-invariant by construction)
            bd, bs = -1, -1
            for d, t in templates.items():
                h1 = contrast_histogram_2d(test)
                h2 = contrast_histogram_2d(t)
                s = cos(h1, h2)
                if s > bs: bs, bd = s, d
            if bd == true_d: c_hist += 1
            total += 1
    return {'standard': c_std/total, 'rotation_invariant': c_rot/total,
            'contrast_histogram': c_hist/total, 'angles': len(angles)}

def task_cross_modal_v2():
    """Improved cross-modal: 120 training pairs, contrast histogram + spatial dist, k-NN."""
    mapper = CrossModalMapperV2(k=3)
    vocab = 20
    descriptions = {
        0: [1,0,1,0,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0],
        1: [0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0],
        2: [1,0,0,1,0,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1],
        3: [1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,0,0,1,0],
        4: [0,1,1,0,0,1,1,0,0,1,0,0,1,0,0,1,1,0,0,1],
        5: [1,0,0,1,1,0,0,1,0,1,0,0,1,0,0,1,0,0,1,1],
    }
    train_labels = []
    # Train: 120 pairs (20 per digit)
    for _ in range(120):
        d = random.randint(0, 5)
        img = make_digit(d, noise=random.uniform(0.05, 0.2),
                         rotation=random.choice([0, 0, 0, 45, 90, 135, 180, 270]))
        feat = Perception.extract_2d(img)
        # Feature: contrast histogram (8) + spatial distribution (16) = 24 dims
        img_feat = feat['contrast_hist'] + feat['spatial_dist']
        text_feat = [max(0, v + random.gauss(0, 0.03)) for v in descriptions[d]]
        mapper.add_pair(img_feat, text_feat)
        train_labels.append(d)
    mapper.train()
    # Test: 30 unseen pairs
    correct = 0
    total = 0
    for true_d in range(6):
        for _ in range(5):
            img = make_digit(true_d, noise=random.uniform(0.05, 0.15),
                             rotation=random.choice([0, 30, 60, 90, 120, 180, 225, 270]))
            feat = Perception.extract_2d(img)
            img_feat = feat['contrast_hist'] + feat['spatial_dist']
            pred, conf = mapper.classify_knn(img_feat, train_labels)
            if pred == true_d: correct += 1
            total += 1
    # Reverse mapping quality
    text_to_img = mapper.map_a_to_b(
        Perception.extract_2d(make_digit(3, 0))['contrast_hist'] +
        Perception.extract_2d(make_digit(3, 0))['spatial_dist'])
    return {'accuracy': correct/total, 'total': total, 'train_pairs': len(mapper.pairs),
            'feature_dim': len(mapper.pairs[0][0]), 'k': mapper.k}

def task_template_library_v2():
    """Improved template library: lower threshold, rotation-invariant matching."""
    lib = HierarchicalTemplateLibrary(threshold=0.70)
    templates = {d: make_digit(d, 0) for d in range(6)}
    # L2: full digits + rotated copies
    for d in range(6):
        lib.add(templates[d], level=2)
        for angle in [45, 90, 180]:
            lib.add(rotate_2d(templates[d], angle), level=2)
    # L1: half-patches
    for d in range(6):
        lib.add([row[:4] for row in templates[d][:4]], level=1)
        lib.add([row[4:] for row in templates[d][4:]], level=1)
    # L0: 3x3 patches
    for d in range(6):
        for i in range(0, 6, 3):
            for j in range(0, 6, 3):
                lib.add([templates[d][i+di][j:j+3] for di in range(3)], level=0)
    # Test matching on rotated digit
    test = make_digit(3, noise=0.1, rotation=45)
    matches = lib.match(test, level=2, top_k=3)
    stats = lib.stats()
    return {'stats': stats, 'top_matches': [(idx, round(s,3)) for idx,s in matches],
            'correct_idx': 3, 'match_correct': matches[0][0] == 3 if matches else False}

def task_full_chain_v5():
    """Full chain with rotation: perceive -> library match -> structure-guided generate."""
    lib = HierarchicalTemplateLibrary(threshold=0.70)
    templates = {d: make_digit(d, 0) for d in range(6)}
    for d in range(6):
        lib.add(templates[d], level=2)
        for angle in [45, 90, 180, 270]:
            lib.add(rotate_2d(templates[d], angle), level=2)
    # Input: rotated + shifted digit
    test = make_digit(3, noise=0.15, shift=(1, -1), rotation=45)
    feat = Perception.extract_2d(test)
    # Decision: library match (rotation-invariant)
    matches = lib.match(test, level=2, top_k=3)
    predicted_idx = matches[0][0] if matches else -1
    # Map library index to digit label (first 6 are original digits 0-5)
    predicted_digit = predicted_idx % 6 if predicted_idx < 18 else -1
    # Generation: structure-guided from matched template + test contrast
    matched = lib.get(predicted_idx, level=2)
    generated = None
    gen_sim = 0
    if matched:
        h, w = 8, 8
        generated = [row[:] for row in matched[:h]]
        while len(generated) < h: generated.append([0.0]*w)
        for row in generated:
            while len(row) < w: row.append(0.0)
        # Overlay top contrast points from test
        for (ci, cj) in feat['contrast_points'][:10]:
            if 0 <= ci < h and 0 <= cj < w and test[ci][cj] > 0:
                generated[ci][cj] = test[ci][cj]
        gen_sim = cos([x for r in generated for x in r], [x for r in test for x in r])
    return {'predicted': predicted_digit, 'actual': 3, 'correct': predicted_digit == 3,
            'top_matches': [(idx, round(s,3)) for idx,s in matches],
            'generation_similarity': gen_sim,
            'contrast_points': len(feat['contrast_points']),
            'library_size': lib.stats()['total']}

# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':
    print("=" * 70)
    print("PGD v5: Improved Cross-Modal + Full-Chain Rotation")
    print("=" * 70)
    results = {}
    t0 = time.time()

    print("\n[1] Rotation Invariance (12 angles: 0-270°)")
    r = task_rotation()
    results['rotation'] = r
    print(f"  Standard: {r['standard']:.1%}")
    print(f"  Multi-angle+symkernel: {r['rotation_invariant']:.1%}")
    print(f"  Contrast histogram: {r['contrast_histogram']:.1%}")

    print("\n[2] Cross-Modal Mapping v2 (120 train pairs, k-NN=3)")
    r = task_cross_modal_v2()
    results['cross_modal'] = r
    print(f"  Accuracy: {r['accuracy']:.1%} ({r['total']} tests)")
    print(f"  Train pairs: {r['train_pairs']}, Feature dim: {r['feature_dim']}")

    print("\n[3] Hierarchical Template Library v2")
    r = task_template_library_v2()
    results['templates'] = r
    print(f"  Stats: {r['stats']}")
    print(f"  Top matches: {r['top_matches']}")
    print(f"  Match correct (digit 3): {r['match_correct']}")

    print("\n[4] Full Chain (rotated 45° + shifted -> perceive -> library -> generate)")
    r = task_full_chain_v5()
    results['full_chain'] = r
    print(f"  Predicted: {r['predicted']}, Actual: {r['actual']}, Correct: {r['correct']}")
    print(f"  Top matches: {r['top_matches']}")
    print(f"  Generation similarity: {r['generation_similarity']:.3f}")
    print(f"  Library size: {r['library_size']}")

    elapsed = time.time() - t0
    results['_time'] = elapsed
    print(f"\nTotal: {elapsed:.2f}s")

    print("\n" + "=" * 70)
    print("v4 -> v5 COMPARISON")
    print("=" * 70)
    print(f"  Rotation: v4=92.6% -> v5={results['rotation']['rotation_invariant']:.1%}")
    print(f"  Cross-modal: v4=16.7% -> v5={results['cross_modal']['accuracy']:.1%}")
    print(f"  Full-chain: v4=FAIL -> v5={'PASS' if results['full_chain']['correct'] else 'FAIL'}")
    print(f"  Template compression: {results['templates']['stats']['ratio']:.2f}x")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pgd_v5_results.json")
    with open(out, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved: {out}")
    print("\n✅ PGD v5 complete.")
